# Logika Pemilihan Kendaraan RFID (2 Kategori: Sepeda Motor & Mobil)

## Konsep Utama
Pemilihan kategori kendaraan di gerbang masuk RFID tidak lagi bergantung pada jumlah kendaraan yang terdaftar di profil akun, melainkan langsung dibedakan menjadi **2 kategori utama**: **Sepeda Motor** dan **Mobil**.

## Alur Tap di Gerbang Masuk (OLED + Timer 5 Detik)
1. **Tap ke-1 (Pilih Sepeda Motor):**
   - Layar OLED menampilkan `[1] SEPEDA MOTOR (Rp 2.000/jam)` dan hitung mundur **5 detik**.
   - Instruksi di OLED: *"Tap 1x lagi dalam 5 detik untuk MOBIL"*.
   - **Jika tidak ada tap lagi selama 5 detik:** Sistem otomatis mengonfirmasi kategori **Sepeda Motor**, membuat transaksi parkir, dan membuka palang masuk.
2. **Tap ke-2 dalam 5 detik (Pilih Mobil):**
   - Layar OLED berpindah menjadi `[2] MOBIL (Rp 5.000/jam)` dan mereset hitung mundur **5 detik**.
   - Instruksi di OLED: *"Tap 1x lagi untuk KONFIRMASI MOBIL"*.
3. **Tap Terakhir / Tap ke-3 (Konfirmasi Langsung):**
   - Sistem langsung mengonfirmasi **Mobil** tanpa menunggu sisa timer, mencatat transaksi tarif Mobil, dan membuka palang masuk.

## Aturan Denda Salah Jenis Kendaraan
- Jika pengguna membawa **Mobil** tetapi memilih kategori **Sepeda Motor** (1x tap) agar mendapat tarif lebih murah, pengelola dapat menandai pelanggaran **Salah Jenis Kendaraan** pada dashboard admin.
- Sistem otomatis mengenakan **Denda Rp 15.000**, menyesuaikan tarif ke kategori **Mobil**, dan menampilkan pemberitahuan merah di akun pengguna serta merincinya pada struk parkir.
