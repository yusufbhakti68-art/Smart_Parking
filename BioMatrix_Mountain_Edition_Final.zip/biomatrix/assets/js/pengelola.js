// BioMatrix Menu Pengelola Engine (Full IoT Control + Full CMS Control + Account Manager)
let dashChart = null, fullChart = null;
let mqttClient = null;
let dbHistoryCache = [];
let liveSoil = null, liveTemp = null, liveHum = null;

function showToast(msg, type = 'success') {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    const bg = type === 'error' ? 'bg-[#FDECEC] border-[#F8B4B4] text-[#B91C1C]' : 'bg-[#17332A] border-[#234E3F] text-white';
    el.className = `px-4 py-3 rounded-lg border text-xs font-semibold ${bg}`;
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(() => el.remove(), 3200);
}

async function handlePengelolaLogin(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;

    try {
        const res = await fetch('/api/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (res.ok && data.ok) {
            sessionStorage.setItem('bm_pengelola_logged', 'true');
            sessionStorage.setItem('bm_pengelola_name', data.user.nama_lengkap || username);
            sessionStorage.setItem('bm_pengelola_id', data.user.id_user || 1);
            openDashboard();
            showToast('Berhasil masuk ke Menu Pengelola.');
            return;
        }
    } catch (err) {}

    if ((username === 'pengelola' || username === 'admin') && (password === 'pengelola' || password === 'admin' || password === 'biomatrix123')) {
        sessionStorage.setItem('bm_pengelola_logged', 'true');
        sessionStorage.setItem('bm_pengelola_name', 'Pengelola');
        openDashboard();
        showToast('Berhasil masuk ke Menu Pengelola.');
    } else {
        showToast('Username atau kata sandi salah!', 'error');
    }
}

function openDashboard() {
    document.getElementById('loginScreen').classList.add('hidden');
    document.getElementById('pengelolaApp').classList.remove('hidden');
    document.getElementById('topbar-username').textContent = sessionStorage.getItem('bm_pengelola_name') || 'Pengelola';
    fetchState();
    loadCmsEditor();
    loadUsers();
}

function logoutPengelola() {
    sessionStorage.removeItem('bm_pengelola_logged');
    location.reload();
}

function switchTab(tabId) {
    document.querySelectorAll('.page-content').forEach(el => el.classList.add('hidden'));
    document.getElementById(`page-${tabId}`)?.classList.remove('hidden');
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('is-active'));
    document.querySelector(`.nav-btn[data-tab="${tabId}"]`)?.classList.add('is-active');
}

function updateActuatorUI(type, state) {
    document.querySelectorAll(`.toggle-${type}-input`).forEach(i => i.checked = state);
    document.querySelectorAll(`.card-${type}-text`).forEach(t => t.textContent = state ? 'Aktif (ON)' : 'Mati');
    document.querySelectorAll(`.card-${type}-badge`).forEach(b => {
        b.textContent = state ? 'ON' : 'OFF';
        b.className = state
            ? `inline-block mt-2 text-[10px] font-bold px-2 py-0.5 rounded bg-[#17332A] text-white card-${type}-badge`
            : `inline-block mt-2 text-[10px] font-bold px-2 py-0.5 rounded bg-[#E2E8F0] text-[#475569] card-${type}-badge`;
    });
}

async function toggleActuator(type, state) {
    const cmd = state ? 'ON' : 'OFF';
    if (mqttClient && mqttClient.connected) {
        mqttClient.publish(type === 'kipas' ? 'biomatrix/kipas/control' : 'biomatrix/pompa/control', cmd);
    }
    try {
        await fetch('/api/actuator.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ aktuator: type, status: cmd, id_user: sessionStorage.getItem('bm_pengelola_id') || 1 })
        });
    } catch (e) {}
    updateActuatorUI(type, state);
    showToast(`${type === 'kipas' ? 'Kipas' : 'Pompa'} diubah menjadi ${cmd}`);
}

async function fetchState() {
    try {
        const res = await fetch('/api/state.php', { cache: 'no-store' });
        if (!res.ok) return;
        const data = await res.json();
        if (!data.ok) return;

        if (data.actuators) {
            if (data.actuators.kipas) updateActuatorUI('kipas', data.actuators.kipas.status_aktuator === 'ON');
            if (data.actuators.pompa) updateActuatorUI('pompa', data.actuators.pompa.status_aktuator === 'ON');
        }
        if (data.device) {
            const elN = document.getElementById('setting-nama-perangkat');
            const elM = document.getElementById('setting-mode-sistem');
            const elI = document.getElementById('setting-interval');
            if (elN && document.activeElement !== elN) elN.value = data.device.nama_perangkat;
            if (elM && document.activeElement !== elM) elM.value = data.device.mode_sistem || 'Otomatis';
            if (elI && document.activeElement !== elI) elI.value = data.device.interval_update || 5;
        }
        if (data.settings) {
            const elS = document.getElementById('setting-suhu-maks');
            const elT = document.getElementById('setting-tanah-min');
            if (elS && document.activeElement !== elS) elS.value = data.settings.suhu_maks;
            if (elT && document.activeElement !== elT) elT.value = data.settings.kelembapan_tanah_min;
        }
        if (Array.isArray(data.history)) {
            dbHistoryCache = data.history;
            const tbody = document.getElementById('riwayat-table-body');
            if (tbody) {
                tbody.innerHTML = data.history.map((r, i) => `
                    <tr class="hover:bg-[#F3F7F5]">
                        <td class="p-3.5">${i + 1}</td>
                        <td class="p-3.5 font-mono text-[#234E3F]">${r.waktu_format}</td>
                        <td class="p-3.5 font-bold">${r.suhu ?? '--'} °C</td>
                        <td class="p-3.5 font-bold">${r.kelembapan_udara ?? '--'}%</td>
                        <td class="p-3.5 font-bold">${r.kelembapan_tanah ?? '--'}%</td>
                    </tr>
                `).join('');
            }
        }
    } catch (e) {}
}

async function saveSettings() {
    const payload = {
        nama_perangkat: document.getElementById('setting-nama-perangkat').value,
        mode_sistem: document.getElementById('setting-mode-sistem').value,
        interval_update: parseInt(document.getElementById('setting-interval').value || 5),
        suhu_maks: parseFloat(document.getElementById('setting-suhu-maks').value || 30),
        kelembapan_tanah_min: parseFloat(document.getElementById('setting-tanah-min').value || 40)
    };
    if (mqttClient && mqttClient.connected) {
        mqttClient.publish('biomatrix/config', JSON.stringify(payload));
    }
    try {
        const res = await fetch('/api/settings.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const d = await res.json();
        if (d.ok) showToast('Pengaturan perangkat & ambang batas tersimpan!');
    } catch (e) {
        showToast('Gagal menyimpan pengaturan', 'error');
    }
}

async function loadCmsEditor() {
    const container = document.getElementById('cms-editor-list');
    if (!container) return;
    try {
        const res = await fetch('/api/cms.php', { cache: 'no-store' });
        const data = await res.json();
        if (!data.ok || !Array.isArray(data.konten_list)) return;

        container.innerHTML = data.konten_list.map(k => `
            <div class="bm-card p-5 space-y-3">
                <div class="flex items-center justify-between border-b border-[#E5EFEA] pb-2">
                    <span class="font-bold text-sm text-[#17332A] uppercase">Bagian: ${k.kunci_bagian}</span>
                    <span class="text-[10px] text-[#4F6A60]">ID #${k.id_konten}</span>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-[#4F6A60] mb-1">Judul</label>
                    <input type="text" id="cms-edit-judul-${k.kunci_bagian}" value="${(k.judul || '').replace(/"/g, '&quot;')}" class="w-full px-3 py-2 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-sm">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-[#4F6A60] mb-1">Subjudul</label>
                    <input type="text" id="cms-edit-sub-${k.kunci_bagian}" value="${(k.subjudul || '').replace(/"/g, '&quot;')}" class="w-full px-3 py-2 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-sm">
                </div>
                <div>
                    <label class="block text-xs font-semibold text-[#4F6A60] mb-1">Deskripsi</label>
                    <textarea rows="2" id="cms-edit-desc-${k.kunci_bagian}" class="w-full px-3 py-2 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs">${k.deskripsi || ''}</textarea>
                </div>
                <div>
                    <label class="block text-xs font-semibold text-[#4F6A60] mb-1">URL Gambar</label>
                    <input type="text" id="cms-edit-img-${k.kunci_bagian}" value="${(k.url_gambar || '').replace(/"/g, '&quot;')}" placeholder="https://..." class="w-full px-3 py-2 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                </div>
                <button onclick="saveCmsSection('${k.kunci_bagian}')" class="px-4 py-2 rounded-lg bg-[#17332A] hover:bg-[#234E3F] text-white text-xs font-bold">
                    Simpan Perubahan Bagian Ini
                </button>
            </div>
        `).join('');
    } catch (e) {}
}

async function saveCmsSection(kunci) {
    const payload = {
        kunci_bagian: kunci,
        judul: document.getElementById(`cms-edit-judul-${kunci}`).value,
        subjudul: document.getElementById(`cms-edit-sub-${kunci}`).value,
        deskripsi: document.getElementById(`cms-edit-desc-${kunci}`).value,
        url_gambar: document.getElementById(`cms-edit-img-${kunci}`).value,
        id_user: sessionStorage.getItem('bm_pengelola_id') || 1
    };
    try {
        const res = await fetch('/api/cms.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const d = await res.json();
        if (d.ok) showToast(d.message);
        else showToast(d.error || 'Gagal menyimpan', 'error');
    } catch (e) {
        showToast('Gagal terhubung ke server CMS', 'error');
    }
}

async function loadUsers() {
    const tbody = document.getElementById('users-table-body');
    if (!tbody) return;
    try {
        const res = await fetch('/api/users.php');
        const data = await res.json();
        if (data.ok && Array.isArray(data.users)) {
            tbody.innerHTML = data.users.map(u => `
                <tr>
                    <td class="p-3.5 font-bold text-[#17332A]">${u.username}</td>
                    <td class="p-3.5">${u.nama_lengkap}</td>
                    <td class="p-3.5 font-mono text-[#4F6A60]">${u.last_login || 'Belum pernah'}</td>
                </tr>
            `).join('');
        }
    } catch (e) {}
}

async function addPengelolaAccount(e) {
    e.preventDefault();
    const payload = {
        nama_lengkap: document.getElementById('new-user-nama').value,
        username: document.getElementById('new-user-username').value,
        password: document.getElementById('new-user-pass').value
    };
    try {
        const res = await fetch('/api/users.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const d = await res.json();
        if (d.ok) {
            showToast(d.message);
            e.target.reset();
            loadUsers();
        } else {
            showToast(d.error || 'Gagal menambah akun', 'error');
        }
    } catch (err) {
        showToast('Server tidak merespons', 'error');
    }
}

function exportToCSV() {
    const rows = [["No", "Waktu", "Suhu (C)", "Kelembapan Udara (%)", "Kelembapan Tanah (%)"]];
    dbHistoryCache.forEach((r, i) => rows.push([i + 1, r.waktu_format, r.suhu, r.kelembapan_udara, r.kelembapan_tanah]));
    const link = document.createElement("a");
    link.href = encodeURI("data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n"));
    link.download = "riwayat_biomatrix.csv";
    link.click();
}

function pushCharts() {
    const label = new Date().toTimeString().slice(0, 8);
    [dashChart, fullChart].forEach(ch => {
        if (!ch) return;
        ch.data.labels.push(label);
        ch.data.datasets[0].data.push(liveSoil ?? 0);
        ch.data.datasets[1].data.push(liveTemp ?? 0);
        ch.data.datasets[2].data.push(liveHum ?? 0);
        if (ch.data.labels.length > 20) {
            ch.data.labels.shift();
            ch.data.datasets.forEach(d => d.data.shift());
        }
        ch.update('none');
    });
}

function initMqttPengelola() {
    const host = window.location.hostname || '127.0.0.1';
    mqttClient = mqtt.connect(`ws://${host}:9001`, { reconnectPeriod: 3000, clean: true });

    mqttClient.on('connect', () => {
        document.getElementById('mqtt-dot').className = 'w-2 h-2 rounded-full bg-[#234E3F]';
        document.getElementById('mqtt-text').textContent = 'ESP32 & MQTT Online';
        mqttClient.subscribe('biomatrix/sensor/tanah');
        mqttClient.subscribe('biomatrix/sensor/dht11');
        mqttClient.subscribe('biomatrix/kipas');
        mqttClient.subscribe('biomatrix/pompa');
    });

    mqttClient.on('message', (topic, msg) => {
        const val = msg.toString().trim();
        if (topic === 'biomatrix/sensor/tanah') {
            liveSoil = parseFloat(val);
            document.getElementById('val-soil').textContent = `${liveSoil}%`;
            document.querySelectorAll('.sensor-soil-val').forEach(el => el.textContent = `${liveSoil}%`);
            pushCharts();
        } else if (topic === 'biomatrix/sensor/dht11') {
            try {
                const d = JSON.parse(val);
                liveTemp = parseFloat(d.suhu);
                liveHum = parseFloat(d.kelembapan);
                document.getElementById('val-temp').textContent = `${liveTemp}°C`;
                document.getElementById('val-hum').textContent = `${liveHum}%`;
                document.querySelectorAll('.sensor-temp-val').forEach(el => el.textContent = `${liveTemp}°C`);
                document.querySelectorAll('.sensor-hum-val').forEach(el => el.textContent = `${liveHum}%`);
                pushCharts();
            } catch (e) {}
        } else if (topic === 'biomatrix/kipas') {
            updateActuatorUI('kipas', val.toUpperCase() === 'ON');
        } else if (topic === 'biomatrix/pompa') {
            updateActuatorUI('pompa', val.toUpperCase() === 'ON');
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('menu-toggle')?.addEventListener('click', () => {
        document.getElementById('sidebar')?.classList.toggle('hidden');
    });

    const chartCfg = {
        type: 'line',
        data: {
            labels: [],
            datasets: [
                { label: 'Tanah (%)', data: [], borderColor: '#234E3F', borderWidth: 2, tension: 0.3, pointRadius: 2 },
                { label: 'Suhu (°C)', data: [], borderColor: '#B45309', borderWidth: 2, tension: 0.3, pointRadius: 2 },
                { label: 'Udara (%)', data: [], borderColor: '#1D6F8A', borderWidth: 2, tension: 0.3, pointRadius: 2 }
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            scales: { x: { grid: { color: '#E5EFEA' } }, y: { grid: { color: '#E5EFEA' } } }
        }
    };

    const c1 = document.getElementById('dashChart')?.getContext('2d');
    if (c1) dashChart = new Chart(c1, JSON.parse(JSON.stringify(chartCfg)));
    const c2 = document.getElementById('fullChart')?.getContext('2d');
    if (c2) fullChart = new Chart(c2, JSON.parse(JSON.stringify(chartCfg)));

    setInterval(() => {
        const el = document.getElementById('current-datetime');
        if (el) el.textContent = new Date().toLocaleString('id-ID', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' WIB';
    }, 1000);

    if (sessionStorage.getItem('bm_pengelola_logged') === 'true') {
        openDashboard();
    }
    initMqttPengelola();
    setInterval(() => {
        if (sessionStorage.getItem('bm_pengelola_logged') === 'true') fetchState();
    }, 5000);
});
