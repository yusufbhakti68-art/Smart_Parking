-- ============================================================================
-- DATABASE SCHEMA: BIOMATRIX SMART GREENHOUSE (3NF + CMS FULL CONTROL)
-- Berdasarkan Struktur_Tabel_dan_Field_Database_BioMatrix.pdf (16 Tabel + 1 VIEW)
-- Ditambah 2 Tabel: konten_website & paket_komponen untuk Full Control Pengelola
-- ============================================================================
DROP DATABASE IF EXISTS biomatrix;
CREATE DATABASE biomatrix CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE biomatrix;

-- 1. Tabel users (Pengelola)
CREATE TABLE users (
    id_user BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    nama_lengkap VARCHAR(100) NOT NULL DEFAULT 'Pengelola BioMatrix',
    password_hash VARCHAR(255) NOT NULL,
    last_login DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Tabel perangkat
CREATE TABLE perangkat (
    id_perangkat BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode_perangkat VARCHAR(50) NOT NULL UNIQUE,
    nama_perangkat VARCHAR(100) NOT NULL,
    versi_firmware VARCHAR(30) NULL,
    ip_address VARCHAR(45) NULL,
    status_koneksi ENUM('online', 'offline') NOT NULL DEFAULT 'offline',
    last_seen DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Tabel pengaturan_perangkat
CREATE TABLE pengaturan_perangkat (
    id_pengaturan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_perangkat BIGINT UNSIGNED NOT NULL UNIQUE,
    mode_sistem ENUM('Otomatis', 'Manual') NOT NULL DEFAULT 'Otomatis',
    interval_update INT UNSIGNED NOT NULL DEFAULT 5,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_pengaturan_perangkat FOREIGN KEY (id_perangkat)
        REFERENCES perangkat(id_perangkat) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Tabel jenis_sensor
CREATE TABLE jenis_sensor (
    id_jenis_sensor INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode_sensor VARCHAR(30) NOT NULL UNIQUE,
    nama_sensor VARCHAR(100) NOT NULL,
    satuan VARCHAR(20) NOT NULL,
    deskripsi TEXT NULL
) ENGINE=InnoDB;

-- 5. Tabel sensor_perangkat
CREATE TABLE sensor_perangkat (
    id_sensor_perangkat BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_perangkat BIGINT UNSIGNED NOT NULL,
    id_jenis_sensor INT UNSIGNED NOT NULL,
    kode_instalasi VARCHAR(50) NOT NULL UNIQUE,
    status_sensor ENUM('Aktif', 'Nonaktif') NOT NULL DEFAULT 'Aktif',
    tanggal_pemasangan DATE NULL,
    CONSTRAINT fk_sp_perangkat FOREIGN KEY (id_perangkat)
        REFERENCES perangkat(id_perangkat) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_sp_jenis FOREIGN KEY (id_jenis_sensor)
        REFERENCES jenis_sensor(id_jenis_sensor) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 6. Tabel pembacaan_sensor
CREATE TABLE pembacaan_sensor (
    id_pembacaan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_sensor_perangkat BIGINT UNSIGNED NOT NULL,
    nilai_sensor DECIMAL(10,2) NOT NULL,
    waktu_pencatatan DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_sp_waktu (id_sensor_perangkat, waktu_pencatatan),
    CONSTRAINT fk_ps_sensor FOREIGN KEY (id_sensor_perangkat)
        REFERENCES sensor_perangkat(id_sensor_perangkat) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. Tabel jenis_aktuator
CREATE TABLE jenis_aktuator (
    id_jenis_aktuator INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode_aktuator VARCHAR(30) NOT NULL UNIQUE,
    nama_aktuator VARCHAR(100) NOT NULL,
    deskripsi TEXT NULL
) ENGINE=InnoDB;

-- 8. Tabel aktuator_perangkat
CREATE TABLE aktuator_perangkat (
    id_aktuator BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_perangkat BIGINT UNSIGNED NOT NULL,
    id_jenis_aktuator INT UNSIGNED NOT NULL,
    status_aktuator ENUM('ON', 'OFF') NOT NULL DEFAULT 'OFF',
    mode_kontrol ENUM('Otomatis', 'Manual', 'Jadwal') NOT NULL DEFAULT 'Otomatis',
    terakhir_diubah DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ap_perangkat FOREIGN KEY (id_perangkat)
        REFERENCES perangkat(id_perangkat) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_ap_jenis FOREIGN KEY (id_jenis_aktuator)
        REFERENCES jenis_aktuator(id_jenis_aktuator) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- 9. Tabel riwayat_aktuator
CREATE TABLE riwayat_aktuator (
    id_riwayat BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_aktuator BIGINT UNSIGNED NOT NULL,
    id_user BIGINT UNSIGNED NULL,
    status_sebelumnya ENUM('ON', 'OFF') NOT NULL,
    status_baru ENUM('ON', 'OFF') NOT NULL,
    sumber_perintah ENUM('Manual', 'Otomatis', 'Jadwal', 'Sistem') NOT NULL DEFAULT 'Sistem',
    waktu_perubahan DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_ra_aktuator FOREIGN KEY (id_aktuator)
        REFERENCES aktuator_perangkat(id_aktuator) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_ra_user FOREIGN KEY (id_user)
        REFERENCES users(id_user) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- 10. Tabel aturan_otomatis
CREATE TABLE aturan_otomatis (
    id_aturan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_sensor_perangkat BIGINT UNSIGNED NOT NULL,
    id_aktuator BIGINT UNSIGNED NOT NULL,
    nama_aturan VARCHAR(100) NOT NULL,
    operator_kondisi ENUM('>', '<', '>=', '<=', '=') NOT NULL,
    nilai_ambang DECIMAL(10,2) NOT NULL,
    status_tujuan ENUM('ON', 'OFF') NOT NULL,
    aktif BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ao_sensor FOREIGN KEY (id_sensor_perangkat)
        REFERENCES sensor_perangkat(id_sensor_perangkat) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_ao_aktuator FOREIGN KEY (id_aktuator)
        REFERENCES aktuator_perangkat(id_aktuator) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 11. Tabel jadwal_aktuator
CREATE TABLE jadwal_aktuator (
    id_jadwal BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_aktuator BIGINT UNSIGNED NOT NULL,
    nama_jadwal VARCHAR(100) NOT NULL,
    waktu_mulai TIME NOT NULL,
    durasi_menit INT UNSIGNED NOT NULL,
    mode_pengulangan ENUM('Sekali', 'Harian', 'Mingguan') NOT NULL DEFAULT 'Harian',
    tanggal_mulai DATE NOT NULL,
    tanggal_selesai DATE NULL,
    zona_waktu VARCHAR(50) NOT NULL DEFAULT 'Asia/Jakarta',
    aktif BOOLEAN NOT NULL DEFAULT TRUE,
    created_by BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ja_aktuator FOREIGN KEY (id_aktuator)
        REFERENCES aktuator_perangkat(id_aktuator) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_ja_user FOREIGN KEY (created_by)
        REFERENCES users(id_user) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- 12. Tabel jadwal_hari
CREATE TABLE jadwal_hari (
    id_jadwal BIGINT UNSIGNED NOT NULL,
    hari TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (id_jadwal, hari),
    CONSTRAINT fk_jh_jadwal FOREIGN KEY (id_jadwal)
        REFERENCES jadwal_aktuator(id_jadwal) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 13. Tabel eksekusi_jadwal
CREATE TABLE eksekusi_jadwal (
    id_eksekusi BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_jadwal BIGINT UNSIGNED NOT NULL,
    waktu_jadwal DATETIME NOT NULL,
    mulai_aktual DATETIME NULL,
    selesai_aktual DATETIME NULL,
    status_eksekusi ENUM('Menunggu', 'Berjalan', 'Selesai', 'Gagal', 'Dilewati') NOT NULL DEFAULT 'Menunggu',
    pesan_error VARCHAR(500) NULL,
    CONSTRAINT fk_ej_jadwal FOREIGN KEY (id_jadwal)
        REFERENCES jadwal_aktuator(id_jadwal) ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- 14. Tabel log_aktivitas
CREATE TABLE log_aktivitas (
    id_aktivitas BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_user BIGINT UNSIGNED NULL,
    jenis_aktivitas VARCHAR(50) NOT NULL,
    deskripsi TEXT NOT NULL,
    waktu_aktivitas DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_la_user FOREIGN KEY (id_user)
        REFERENCES users(id_user) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- 15. Tabel kontak
CREATE TABLE kontak (
    id_kontak BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 16. Tabel pesan_kontak
CREATE TABLE pesan_kontak (
    id_pesan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_kontak BIGINT UNSIGNED NOT NULL,
    isi_pesan TEXT NOT NULL,
    status_baca ENUM('belum_dibaca', 'sudah_dibaca') NOT NULL DEFAULT 'belum_dibaca',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_pk_kontak FOREIGN KEY (id_kontak)
        REFERENCES kontak(id_kontak) ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ============================================================================
-- TABEL TAMBAHAN (17 & 18) UNTUK FULL CONTROL TAMPILAN WEBSITE & PAKET KIT
-- ============================================================================

-- 17. Tabel konten_website (Pengelola bisa ubah Judul, Subjudul, Deskripsi, & URL Gambar)
CREATE TABLE konten_website (
    id_konten INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kunci_bagian VARCHAR(50) NOT NULL UNIQUE,
    judul VARCHAR(150) NOT NULL,
    subjudul VARCHAR(200) NULL,
    deskripsi TEXT NULL,
    url_gambar VARCHAR(500) NULL,
    updated_by BIGINT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_kw_user FOREIGN KEY (updated_by)
        REFERENCES users(id_user) ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- 18. Tabel paket_komponen (Daftar isi paket perangkat keras BioMatrix yang ditawarkan)
CREATE TABLE paket_komponen (
    id_komponen INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nama_komponen VARCHAR(120) NOT NULL,
    jumlah VARCHAR(30) NOT NULL DEFAULT '1 Unit',
    keterangan VARCHAR(255) NULL,
    ikon VARCHAR(60) NOT NULL DEFAULT 'fa-microchip',
    urutan TINYINT UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB;

-- ============================================================================
-- VIEW: v_sensor_terakhir (Sesuai PDF)
-- ============================================================================
CREATE OR REPLACE VIEW v_sensor_terakhir AS
SELECT
    sp.id_sensor_perangkat,
    sp.id_perangkat,
    js.kode_sensor,
    js.nama_sensor,
    js.satuan,
    ps.nilai_sensor,
    ps.waktu_pencatatan
FROM sensor_perangkat sp
JOIN jenis_sensor js ON js.id_jenis_sensor = sp.id_jenis_sensor
LEFT JOIN pembacaan_sensor ps ON ps.id_pembacaan = (
    SELECT MAX(ps2.id_pembacaan)
    FROM pembacaan_sensor ps2
    WHERE ps2.id_sensor_perangkat = sp.id_sensor_perangkat
);

-- ============================================================================
-- DATA AWAL (SEEDER)
-- ============================================================================
INSERT INTO users (username, nama_lengkap, password_hash) VALUES
('pengelola', 'Yusuf Pengelola', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi'),
('admin', 'Pengelola Utama', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

INSERT INTO perangkat (id_perangkat, kode_perangkat, nama_perangkat, versi_firmware, ip_address, status_koneksi, last_seen) VALUES
(1, 'BG-001', 'BioMatrix Greenhouse', 'v1.2.0', '10.15.42.1', 'online', NOW());

INSERT INTO pengaturan_perangkat (id_perangkat, mode_sistem, interval_update) VALUES
(1, 'Otomatis', 5);

INSERT INTO jenis_sensor (id_jenis_sensor, kode_sensor, nama_sensor, satuan, deskripsi) VALUES
(1, 'SOIL', 'Kelembapan Tanah', '%', 'Sensor kelembapan media tanam ADC'),
(2, 'TEMP', 'Suhu Udara (DHT11)', '°C', 'Sensor suhu ruang greenhouse DHT11'),
(3, 'HUM', 'Kelembapan Udara (DHT11)', '%', 'Sensor kelembapan relatif udara DHT11');

INSERT INTO sensor_perangkat (id_sensor_perangkat, id_perangkat, id_jenis_sensor, kode_instalasi, status_sensor, tanggal_pemasangan) VALUES
(1, 1, 1, 'BG001-SOIL-01', 'Aktif', CURDATE()),
(2, 1, 2, 'BG001-TEMP-01', 'Aktif', CURDATE()),
(3, 1, 3, 'BG001-HUM-01', 'Aktif', CURDATE());

INSERT INTO jenis_aktuator (id_jenis_aktuator, kode_aktuator, nama_aktuator, deskripsi) VALUES
(1, 'kipas', 'Kipas Sirkulasi', 'Kipas pendingin suhu greenhouse'),
(2, 'pompa', 'Pompa Irigasi DC 12V', 'Pompa penyiraman otomatis & terjadwal');

INSERT INTO aktuator_perangkat (id_aktuator, id_perangkat, id_jenis_aktuator, status_aktuator, mode_kontrol) VALUES
(1, 1, 1, 'OFF', 'Otomatis'),
(2, 1, 2, 'OFF', 'Otomatis');

INSERT INTO aturan_otomatis (id_sensor_perangkat, id_aktuator, nama_aturan, operator_kondisi, nilai_ambang, status_tujuan, aktif) VALUES
(2, 1, 'Kipas ON Suhu Tinggi', '>', 30.00, 'ON', TRUE),
(1, 2, 'Pompa ON Tanah Kering', '<', 40.00, 'ON', TRUE);

INSERT INTO jadwal_aktuator (id_aktuator, nama_jadwal, waktu_mulai, durasi_menit, mode_pengulangan, tanggal_mulai, aktif, created_by) VALUES
(2, 'Penyiraman Rutin 2 Jam Sekali', '06:00:00', 2, 'Harian', CURDATE(), TRUE, 1);

INSERT INTO konten_website (kunci_bagian, judul, subjudul, deskripsi, url_gambar) VALUES
('hero', 'BIOMATRIX SMART GREEN HOUSE', 'Pertanian Cerdas Berbasis Internet of Things', 'Sistem pemantauan dan pengendalian iklim mikro greenhouse otomatis yang menghadirkan kesejukan dan presisi alam pegunungan ke dalam ruang budidaya modern.', 'https://images.unsplash.com/photo-1511497584788-876760111969?auto=format&fit=crop&q=85&w=1920'),
('inovasi', 'SMART GREEN HOUSE', 'Transformasi Digital Pertanian Berkelanjutan', 'Mengintegrasikan sensor lingkungan presisi dengan aktuator otomatis untuk menghemat air, energi, dan menjaga kesegaran tanaman sepanjang hari.', 'https://i.ibb.co.com/YFFkbq2N/greenhouse.png'),
('paket', 'PAKET PERANGKAT BIOMATRIX', 'Kit Lengkap Siap Pasang untuk Greenhouse Modern', 'Dapatkan satu set perangkat keras lengkap mulai dari mikrokontroler ESP32, sensor lingkungan, sistem irigasi pompa DC 12V, hingga miniatur rumah greenhouse siap uji.', 'https://i.ibb.co.com/tMDKPwPb/Natural-Ventilation-2-11zon-1024x685.jpg'),
('monitoring', 'Pantau Kondisi Greenhouse Secara Real-Time', 'LIVE MONITORING', 'Amati grafik suhu, kelembapan udara, kelembapan tanah, serta status hidup/mati sensor dan perangkat langsung dari ruang budidaya.', 'https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?auto=format&fit=crop&q=85&w=1000'),
('kontak', 'Konsultasi Sistem BioMatrix', 'KONTAK PENGELOLA', 'Tertarik menerapkan sistem Smart Greenhouse atau memesan paket perangkat lengkap? Hubungi tim pengelola kami.', '');

INSERT INTO paket_komponen (nama_komponen, jumlah, keterangan, ikon, urutan) VALUES
('Mikrokontroler ESP32', '1 Unit', 'Otak pemrosesan IoT dengan Wi-Fi terintegrasi untuk transmisi data MQTT real-time.', 'fa-microchip', 1),
('Sensor DHT11', '1 Unit', 'Sensor presisi untuk memantau suhu dan kelembapan udara di dalam greenhouse.', 'fa-temperature-half', 2),
('Sensor Kelembapan Tanah', '1 Unit', 'Sensor probe ADC untuk mendeteksi kadar air media tanam secara akurat.', 'fa-seedling', 3),
('Pompa Air DC 12V', '1 Unit', 'Pompa penyiraman otomatis untuk sistem irigasi tetes dan jadwal rutin 2 jam sekali.', 'fa-faucet-drip', 4),
('Adaptor Daya 10V', '1 Unit', 'Catu daya stabil untuk mengoperasikan sistem kontrol dan aktuator greenhouse.', 'fa-plug', 5),
('Box Pelindung ESP32', '1 Unit', 'Kotak pelindung rangkaian elektronik agar aman dari cipratan air dan kelembapan.', 'fa-box', 6),
('Miniatur Rumah Greenhouse', '1 Unit', 'Prototipe miniatur rumah-rumahan greenhouse siap pakai untuk simulasi dan pembelajaran.', 'fa-house', 7);
