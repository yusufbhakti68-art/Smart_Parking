<?php
declare(strict_types=1);
return [
    'db_host' => '127.0.0.1',
    'db_name' => 'biomatrix',
    'db_user' => 'biomatrix',
    'db_pass' => 'biomatrix123',
];
