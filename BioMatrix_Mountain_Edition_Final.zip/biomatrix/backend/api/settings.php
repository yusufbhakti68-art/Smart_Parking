<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

try {
    require __DIR__ . '/../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $namaPerangkat = trim((string)($input['nama_perangkat'] ?? 'BioMatrix Greenhouse'));
        $modeSistem = in_array($input['mode_sistem'] ?? '', ['Otomatis', 'Manual']) ? $input['mode_sistem'] : 'Otomatis';
        $intervalUpdate = max(1, (int)($input['interval_update'] ?? 5));
        $suhuMaks = (float)($input['suhu_maks'] ?? 30.0);
        $tanahMin = (float)($input['kelembapan_tanah_min'] ?? 40.0);

        $pdo->prepare("UPDATE perangkat SET nama_perangkat = ? WHERE id_perangkat = 1")->execute([$namaPerangkat]);
        $pdo->prepare("UPDATE pengaturan_perangkat SET mode_sistem = ?, interval_update = ? WHERE id_perangkat = 1")
            ->execute([$modeSistem, $intervalUpdate]);
        $pdo->prepare("UPDATE aturan_otomatis SET nilai_ambang = ? WHERE id_sensor_perangkat = 2")->execute([$suhuMaks]);
        $pdo->prepare("UPDATE aturan_otomatis SET nilai_ambang = ? WHERE id_sensor_perangkat = 1")->execute([$tanahMin]);

        echo json_encode(['ok' => true, 'message' => 'Pengaturan perangkat dan ambang batas berhasil disimpan']);
        exit;
    }

    $device = $pdo->query("SELECT p.*, pp.mode_sistem, pp.interval_update FROM perangkat p LEFT JOIN pengaturan_perangkat pp ON pp.id_perangkat = p.id_perangkat WHERE p.id_perangkat = 1")->fetch();
    echo json_encode(['ok' => true, 'device' => $device]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
