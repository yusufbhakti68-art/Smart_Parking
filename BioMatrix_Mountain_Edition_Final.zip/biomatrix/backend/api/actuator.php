<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

try {
    require __DIR__ . '/../config/database.php';
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $kode = strtolower(trim((string)($input['aktuator'] ?? '')));
    $status = strtoupper(trim((string)($input['status'] ?? 'OFF')));
    $idUser = isset($input['id_user']) ? (int)$input['id_user'] : 1;

    if (!in_array($kode, ['kipas', 'pompa']) || !in_array($status, ['ON', 'OFF'])) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Parameter aktuator tidak valid']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT ap.id_aktuator, ap.status_aktuator FROM aktuator_perangkat ap
                           JOIN jenis_aktuator ja ON ja.id_jenis_aktuator = ap.id_jenis_aktuator
                           WHERE ja.kode_aktuator = ? AND ap.id_perangkat = 1 LIMIT 1");
    $stmt->execute([$kode]);
    $akt = $stmt->fetch();

    if ($akt) {
        $prev = $akt['status_aktuator'];
        $pdo->prepare("UPDATE aktuator_perangkat SET status_aktuator = ?, mode_kontrol = 'Manual', terakhir_diubah = NOW() WHERE id_aktuator = ?")
            ->execute([$status, $akt['id_aktuator']]);
        $pdo->prepare("INSERT INTO riwayat_aktuator (id_aktuator, id_user, status_sebelumnya, status_baru, sumber_perintah) VALUES (?, ?, ?, ?, 'Manual')")
            ->execute([$akt['id_aktuator'], $idUser, $prev, $status]);
        $pdo->prepare("INSERT INTO log_aktivitas (id_user, jenis_aktivitas, deskripsi) VALUES (?, 'KONTROL_AKTUATOR', ?)")
            ->execute([$idUser, "Mengubah status {$kode} dari {$prev} menjadi {$status}"]);
    }

    echo json_encode(['ok' => true, 'aktuator' => $kode, 'status' => $status]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
