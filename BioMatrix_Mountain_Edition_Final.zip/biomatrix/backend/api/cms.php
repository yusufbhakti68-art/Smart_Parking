<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
    require __DIR__ . '/../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $kunci = trim((string)($input['kunci_bagian'] ?? ''));
        $judul = trim((string)($input['judul'] ?? ''));
        $subjudul = trim((string)($input['subjudul'] ?? ''));
        $deskripsi = trim((string)($input['deskripsi'] ?? ''));
        $urlGambar = trim((string)($input['url_gambar'] ?? ''));
        $idUser = isset($input['id_user']) ? (int)$input['id_user'] : 1;

        if ($kunci === '' || $judul === '') {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'Kunci bagian dan judul wajib diisi']);
            exit;
        }

        $stmt = $pdo->prepare("UPDATE konten_website SET judul = ?, subjudul = ?, deskripsi = ?, url_gambar = ?, updated_by = ? WHERE kunci_bagian = ?");
        $stmt->execute([$judul, $subjudul, $deskripsi, $urlGambar, $idUser, $kunci]);

        $pdo->prepare("INSERT INTO log_aktivitas (id_user, jenis_aktivitas, deskripsi) VALUES (?, 'UPDATE_CMS', ?)")
            ->execute([$idUser, "Memperbarui tampilan bagian website: {$kunci}"]);

        echo json_encode(['ok' => true, 'message' => "Tampilan bagian '{$kunci}' berhasil diperbarui!"]);
        exit;
    }

    $kontenRows = $pdo->query("SELECT * FROM konten_website ORDER BY id_konten ASC")->fetchAll();
    $kontenMap = [];
    foreach ($kontenRows as $k) {
        $kontenMap[$k['kunci_bagian']] = $k;
    }
    $paketRows = $pdo->query("SELECT * FROM paket_komponen ORDER BY urutan ASC")->fetchAll();

    echo json_encode([
        'ok' => true,
        'konten' => $kontenMap,
        'konten_list' => $kontenRows,
        'paket' => $paketRows
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
