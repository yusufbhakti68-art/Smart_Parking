<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

try {
    require __DIR__ . '/../config/database.php';
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $nama = trim((string)($input['nama'] ?? ''));
    $email = trim((string)($input['email'] ?? ''));
    $pesan = trim((string)($input['pesan'] ?? ''));

    if ($nama === '' || $email === '' || $pesan === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Semua kolom wajib diisi']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT id_kontak FROM kontak WHERE email = ? LIMIT 1");
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    if ($row) {
        $idKontak = (int)$row['id_kontak'];
    } else {
        $pdo->prepare("INSERT INTO kontak (nama_lengkap, email) VALUES (?, ?)")->execute([$nama, $email]);
        $idKontak = (int)$pdo->lastInsertId();
    }

    $pdo->prepare("INSERT INTO pesan_kontak (id_kontak, isi_pesan) VALUES (?, ?)")->execute([$idKontak, $pesan]);
    echo json_encode(['ok' => true, 'message' => 'Pesan berhasil dikirim ke pengelola']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
