<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

try {
    require __DIR__ . '/../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $username = trim((string)($input['username'] ?? ''));
        $nama = trim((string)($input['nama_lengkap'] ?? 'Pengelola Baru'));
        $password = (string)($input['password'] ?? '');

        if ($username === '' || strlen($password) < 4) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'Username wajib diisi dan password minimal 4 karakter']);
            exit;
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);
        $pdo->prepare("INSERT INTO users (username, nama_lengkap, password_hash) VALUES (?, ?, ?)")
            ->execute([$username, $nama, $hash]);

        echo json_encode(['ok' => true, 'message' => "Akun pengelola '{$username}' berhasil ditambahkan"]);
        exit;
    }

    $users = $pdo->query("SELECT id_user, username, nama_lengkap, last_login, created_at FROM users ORDER BY id_user ASC")->fetchAll();
    echo json_encode(['ok' => true, 'users' => $users]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
