#!/bin/bash
set -e
mkdir -p /var/www/biomatrix
cp -r ./* /var/www/biomatrix/
chown -R www-data:www-data /var/www/biomatrix

mysql -u biomatrix -pbiomatrix123 < /var/www/biomatrix/database/biomatrix_3nf_cms.sql

PHP_SOCK=$(find /run/php/ -name "php*-fpm.sock" | head -n 1)
cat << EOF > /etc/nginx/sites-available/biomatrix.conf
server {
    listen 8080;
    server_name _;

    root /var/www/biomatrix;
    index index.html index.php;

    location = /admin {
        return 301 /admin/;
    }

    location /admin/ {
        try_files \$uri \$uri/ /admin/index.html;
    }

    location ^~ /api/ {
        rewrite ^/api/(.*)$ /backend/api/\$1 last;
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:$PHP_SOCK;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }
}
EOF

ln -sf /etc/nginx/sites-available/biomatrix.conf /etc/nginx/sites-enabled/biomatrix.conf
nginx -t && systemctl reload nginx
systemctl restart biomatrix-mqtt.service
echo "DEPLOY BIOMATRIX FINAL (/admin + Login Dashboard Pengelola) SELESAI!"
