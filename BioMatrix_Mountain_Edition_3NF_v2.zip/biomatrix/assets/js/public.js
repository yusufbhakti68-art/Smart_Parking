// BioMatrix Public Page Engine (CMS Loader + Paket Kit + Read-Only MQTT)
let publicChart = null;
let liveSoil = null, liveTemp = null, liveHum = null;

const DEFAULT_PAKET = [
    { nama_komponen: 'Mikrokontroler ESP32', jumlah: '1 Unit', keterangan: 'Otak pemrosesan IoT dengan Wi-Fi terintegrasi.', ikon: 'fa-microchip' },
    { nama_komponen: 'Sensor DHT11', jumlah: '1 Unit', keterangan: 'Memantau suhu dan kelembapan udara ruang greenhouse.', ikon: 'fa-temperature-half' },
    { nama_komponen: 'Sensor Kelembapan Tanah', jumlah: '1 Unit', keterangan: 'Mendeteksi kadar air media tanam secara akurat.', ikon: 'fa-seedling' },
    { nama_komponen: 'Pompa Air DC 12V', jumlah: '1 Unit', keterangan: 'Pompa penyiraman otomatis & terjadwal 2 jam sekali.', ikon: 'fa-faucet-drip' },
    { nama_komponen: 'Adaptor Daya 10V', jumlah: '1 Unit', keterangan: 'Catu daya stabil untuk mengoperasikan sistem kontrol.', ikon: 'fa-plug' },
    { nama_komponen: 'Box Pelindung ESP32', jumlah: '1 Unit', keterangan: 'Kotak pelindung rangkaian dari cipratan air.', ikon: 'fa-box' },
    { nama_komponen: 'Miniatur Rumah Greenhouse', jumlah: '1 Unit', keterangan: 'Prototipe miniatur rumah-rumahan greenhouse siap pakai.', ikon: 'fa-house' }
];

function renderPaket(items) {
    const container = document.getElementById('paket-komponen-list');
    if (!container) return;
    container.innerHTML = items.map(it => `
        <div class="bg-white border border-[#D6E2DC] rounded-xl p-4 flex items-start gap-3">
            <div class="w-9 h-9 rounded-lg bg-[#E5EFEA] text-[#17332A] flex items-center justify-center shrink-0">
                <i class="fa-solid ${it.ikon || 'fa-cube'}"></i>
            </div>
            <div>
                <div class="flex items-center gap-2">
                    <span class="font-bold text-sm text-[#12241E]">${it.nama_komponen}</span>
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A]">${it.jumlah}</span>
                </div>
                <p class="text-xs text-[#4F6A60] mt-1 leading-relaxed">${it.keterangan || ''}</p>
            </div>
        </div>
    `).join('');
}

async function loadCmsContent() {
    renderPaket(DEFAULT_PAKET);
    try {
        const res = await fetch('/api/cms.php', { cache: 'no-store' });
        if (!res.ok) return;
        const data = await res.json();
        if (!data.ok) return;

        const k = data.konten || {};
        ['hero', 'inovasi', 'paket', 'monitoring', 'kontak'].forEach(key => {
            if (!k[key]) return;
            const elJ = document.getElementById(`cms-${key}-judul`);
            const elS = document.getElementById(`cms-${key}-subjudul`);
            const elD = document.getElementById(`cms-${key}-deskripsi`);
            const elI = document.getElementById(`cms-${key}-img`);
            if (elJ && k[key].judul) elJ.textContent = k[key].judul;
            if (elS && k[key].subjudul) elS.textContent = k[key].subjudul;
            if (elD && k[key].deskripsi) elD.textContent = k[key].deskripsi;
            if (elI && k[key].url_gambar) elI.src = k[key].url_gambar;
        });

        if (Array.isArray(data.paket) && data.paket.length > 0) {
            renderPaket(data.paket);
        }
    } catch (e) {
        console.warn('CMS offline fallback:', e.message);
    }
}

function setPublicBadge(id, isOn) {
    const el = document.getElementById(id);
    if (!el) return;
    if (isOn) {
        el.className = 'px-2.5 py-1 rounded-md text-[10px] font-bold bg-[#17332A] text-white';
        el.textContent = 'HIDUP';
    } else {
        el.className = 'px-2.5 py-1 rounded-md text-[10px] font-bold bg-[#E2E8F0] text-[#475569]';
        el.textContent = 'MATI';
    }
}

function pushChartPoint() {
    if (!publicChart) return;
    const label = new Date().toTimeString().slice(0, 8);
    publicChart.data.labels.push(label);
    publicChart.data.datasets[0].data.push(liveSoil ?? 0);
    publicChart.data.datasets[1].data.push(liveTemp ?? 0);
    publicChart.data.datasets[2].data.push(liveHum ?? 0);
    if (publicChart.data.labels.length > 15) {
        publicChart.data.labels.shift();
        publicChart.data.datasets.forEach(ds => ds.data.shift());
    }
    publicChart.update('none');
}

function initMqttPublic() {
    const host = window.location.hostname || '127.0.0.1';
    const client = mqtt.connect(`ws://${host}:9001`, { reconnectPeriod: 3000, clean: true });

    client.on('connect', () => {
        const pill = document.getElementById('public-mqtt-pill');
        if (pill) pill.innerHTML = '<span class="w-2 h-2 rounded-full bg-[#234E3F]"></span><span>ESP32 Terhubung</span>';
        const st = document.getElementById('hero-status');
        if (st) st.textContent = 'Online';
        setPublicBadge('public-sensor-badge', true);

        client.subscribe('biomatrix/sensor/tanah');
        client.subscribe('biomatrix/sensor/dht11');
        client.subscribe('biomatrix/kipas');
        client.subscribe('biomatrix/pompa');
    });

    client.on('offline', () => {
        setPublicBadge('public-sensor-badge', false);
        const st = document.getElementById('hero-status');
        if (st) st.textContent = 'Offline';
    });

    client.on('message', (topic, msg) => {
        const val = msg.toString().trim();
        setPublicBadge('public-sensor-badge', true);

        if (topic === 'biomatrix/sensor/tanah') {
            const soil = parseFloat(val);
            if (!isNaN(soil)) {
                liveSoil = soil;
                document.getElementById('hero-soil').textContent = `${soil}%`;
                document.getElementById('dash-soil').textContent = `${soil}%`;
                pushChartPoint();
            }
        } else if (topic === 'biomatrix/sensor/dht11') {
            try {
                const d = JSON.parse(val);
                liveTemp = parseFloat(d.suhu);
                liveHum = parseFloat(d.kelembapan);
                document.getElementById('hero-temp').textContent = `${liveTemp}°C`;
                document.getElementById('hero-hum').textContent = `${liveHum}%`;
                document.getElementById('dash-temp').textContent = `${liveTemp}°C`;
                document.getElementById('dash-hum').textContent = `${liveHum}%`;
                pushChartPoint();
            } catch (e) {}
        } else if (topic === 'biomatrix/kipas') {
            const on = val.toUpperCase() === 'ON';
            setPublicBadge('public-fan-badge', on);
            document.getElementById('public-fan-icon')?.classList.toggle('fa-spin', on);
        } else if (topic === 'biomatrix/pompa') {
            setPublicBadge('public-pump-badge', val.toUpperCase() === 'ON');
        }
    });
}

async function handleContactSubmit(e) {
    e.preventDefault();
    const nama = document.getElementById('contact-nama').value;
    const email = document.getElementById('contact-email').value;
    const pesan = document.getElementById('contact-pesan').value;
    try {
        await fetch('/api/contact.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nama, email, pesan })
        });
    } catch (err) {}
    document.getElementById('form-feedback').classList.remove('hidden');
    document.getElementById('contact-form').reset();
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('mobile-menu-btn')?.addEventListener('click', () => {
        document.getElementById('mobile-menu')?.classList.toggle('hidden');
    });

    const ctx = document.getElementById('publicChart')?.getContext('2d');
    if (ctx) {
        publicChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    { label: 'Tanah (%)', data: [], borderColor: '#234E3F', borderWidth: 2, tension: 0.3, pointRadius: 2 },
                    { label: 'Suhu (°C)', data: [], borderColor: '#B45309', borderWidth: 2, tension: 0.3, pointRadius: 2 },
                    { label: 'Udara (%)', data: [], borderColor: '#1D6F8A', borderWidth: 2, tension: 0.3, pointRadius: 2 }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { labels: { color: '#12241E', font: { size: 11 } } } },
                scales: {
                    x: { ticks: { color: '#4F6A60' }, grid: { color: '#E5EFEA' } },
                    y: { ticks: { color: '#4F6A60' }, grid: { color: '#E5EFEA' } }
                }
            }
        });
    }

    loadCmsContent();
    initMqttPublic();
});
