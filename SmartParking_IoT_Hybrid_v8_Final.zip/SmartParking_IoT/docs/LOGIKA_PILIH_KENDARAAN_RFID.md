# Perubahan Menu Pengguna dan Rancangan Pemilihan Kendaraan RFID

## Perubahan pada dashboard
- Profil & Pengaturan kini menyediakan form untuk mengubah nama akun, email login, dan nomor HP.
- Kendaraan Saya kini mendukung tambah kendaraan, kategori `motor` atau `mobil`, merek/warna opsional, menetapkan kendaraan utama, dan menghapus kendaraan.
- Nomor polisi diperiksa agar tidak duplikat pada data lokal dashboard.
- Kendaraan yang sedang memiliki sesi parkir aktif tidak dapat dihapus.
- Data akun lama dimigrasikan di browser dari field `plate` dan `vehicle` menjadi array `vehicles` agar data demo lama tetap terbaca.

## Batasan versi ini
Form dashboard saat ini menyimpan perubahan pada `localStorage` browser (mode demo/prototipe). Belum ada endpoint API autentikasi untuk menyimpan perubahan profil/kendaraan ke MariaDB. Jangan anggap perubahan pada browser sebagai perubahan database server. Database yang disertakan sudah memiliki `Kendaraan_tbl` dengan kategori `motor`/`mobil` dan `Transaksi_tbl.id_kendaraan`, sehingga backend dapat dikembangkan tanpa membuat tabel kendaraan duplikat.

## Rekomendasi alur RFID multi-kendaraan

### Jika akun hanya memiliki satu kendaraan
1. Kartu RFID dibaca di gerbang masuk.
2. Server memvalidasi kartu, status akun, dan kendaraan aktif.
3. OLED/LCD menampilkan nama akun singkat, `1/1`, kategori, dan nomor polisi.
4. Sistem membuat transaksi dengan `id_kendaraan` tersebut, lalu mengirim perintah buka gerbang.

### Jika akun memiliki lebih dari satu kendaraan
Gunakan *multi-tap dengan jeda konfirmasi*, bukan langsung membuka gerbang pada tap pertama:
1. Tap pertama memulai sesi pemilihan dan memilih kendaraan nomor 1.
2. OLED/LCD menampilkan nama akun, jumlah kendaraan, nomor pilihan, kategori, dan plat yang dipilih.
3. Setiap tap ulang kartu yang sama dalam jendela pemilihan (misalnya 2,5 detik) memindahkan pilihan ke kendaraan berikutnya. Pilihan berputar kembali ke nomor 1 setelah kendaraan terakhir.
4. Jika tidak ada tap baru selama 2,5 detik, server mengunci pilihan terakhir.
5. Server memvalidasi ulang bahwa kendaraan masih aktif dan tidak sedang memiliki transaksi parkir berjalan, memilih slot yang tersedia, menyimpan `id_kendaraan` pada transaksi, baru kemudian membuka palang.
6. Jika kartu tidak ditap ulang, pilihan pertama otomatis dikonfirmasi setelah jeda. Dengan demikian 1 tap = kendaraan pertama, 2 tap = kendaraan kedua, 3 tap = kendaraan ketiga.

### Perlindungan yang wajib
- Jangan membuka palang sebelum pilihan kendaraan dikunci dan transaksi berhasil disimpan.
- Tap ulang hanya dihitung jika kartu terdeteksi terlepas lalu ditempel kembali; kartu yang dibiarkan menempel tidak boleh menambah hitungan.
- Abaikan tap dari UID lain selama sesi pemilihan berlangsung, atau batalkan sesi dan minta mulai ulang.
- Batalkan pilihan jika waktu pemilihan habis terlalu lama, koneksi server/MQTT putus, kartu diblokir, atau kendaraan tidak lagi valid.
- Tampilkan pesan gagal di layar; jangan membuka palang jika data kendaraan ambigu.
- Gunakan `id_kendaraan` sebagai identitas transaksi, bukan hanya nomor polisi atau field kendaraan utama akun.
- Di gerbang keluar, gunakan kendaraan yang tercatat pada transaksi aktif; jangan meminta pemilihan ulang.

## Contoh tampilan 16x2
Baris 1: `BUDI SANTOSO 2/3`
Baris 2: `MOBIL N1234AB`
Nama panjang harus dipotong dengan aman. Jika perangkat yang dipakai benar-benar OLED grafis, layout dapat menampilkan daftar lebih lengkap.

## Catatan perangkat
Firmware ZIP saat ini menggunakan `LiquidCrystal_I2C` untuk LCD 16x2 alamat 0x27, bukan library OLED grafis. Jika perangkat fisik yang digunakan adalah OLED, jenis dan resolusinya perlu dipastikan sebelum firmware layar ditulis ulang.

## Status implementasi
Perubahan menu Profil dan Kendaraan telah dibuat pada dashboard prototipe. Alur multi-tap di atas adalah rancangan logika; firmware ESP32 dan worker MQTT belum diubah untuk menjalankannya. Integrasi perangkat perlu dilakukan sebagai tahap terpisah dan diuji dengan palang dalam mode aman terlebih dahulu.
