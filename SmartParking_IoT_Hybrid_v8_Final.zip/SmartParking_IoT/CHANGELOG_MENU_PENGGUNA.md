# Changelog — Menu Pengguna & Kendaraan Multi-Akun

- Menambahkan pengaturan nama akun, email login, dan nomor HP.
- Menambahkan daftar multi-kendaraan per akun.
- Menambahkan form kendaraan: nomor polisi, kategori motor/mobil, merek, dan warna.
- Menambahkan aksi jadikan kendaraan utama dan hapus kendaraan (diblokir jika kendaraan sedang parkir).
- Menambahkan migrasi data demo lama dari satu kendaraan menjadi daftar kendaraan.
- Rancangan multi-tap RFID didokumentasikan di `docs/LOGIKA_PILIH_KENDARAAN_RFID.md`.

Catatan: form saat ini menyimpan ke localStorage untuk prototipe. Endpoint API MariaDB belum dibuat. Logika multi-tap masih berupa rancangan dan belum diaktifkan di firmware ESP32/worker MQTT.
