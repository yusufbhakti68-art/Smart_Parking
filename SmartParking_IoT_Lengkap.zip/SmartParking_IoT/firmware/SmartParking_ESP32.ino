/* SmartParking Island - ESP32-WROOM
 * RFID default RC522 (SPI), 5x HC-SR04 (4 slot + 1 gate), 2 servo, LCD 16x2 I2C.
 * Ganti WIFI_SSID, WIFI_PASSWORD, MQTT_HOST sesuai jaringan/server.
 */
#include <WiFi.h>
#include <PubSubClient.h>
#include <SPI.h>
#include <MFRC522.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

const char* WIFI_SSID = "NAMA_WIFI";
const char* WIFI_PASSWORD = "PASSWORD_WIFI";
const char* MQTT_HOST = "192.168.1.10"; // IP server Linux, bukan localhost
const uint16_t MQTT_PORT = 1883;
const char* MQTT_USER = "smartparking";
const char* MQTT_PASS = "GANTI_PASSWORD_MQTT";

// RC522 SPI: SCK=18, MISO=19, MOSI=23, SDA/SS=5, RST=27
#define RFID_SS 5
#define RFID_RST 27
MFRC522 rfid(RFID_SS, RFID_RST);

// LCD I2C: SDA=21, SCL=22. Alamat umum 0x27; coba 0x3F bila blank.
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Servo: gunakan supply 5V eksternal terpisah, GND disatukan.
const int SERVO_ENTRY_PIN = 25;
const int SERVO_EXIT_PIN = 26;
Servo servoEntry, servoExit;
const int SERVO_CLOSED = 0;
const int SERVO_OPEN = 90;

// Empat sensor slot + satu sensor pemicu kendaraan di gerbang.
const int TRIG[5] = {13, 14, 16, 17, 4};
const int ECHO[5] = {34, 35, 32, 33, 36}; // input-only pins cocok untuk ECHO
const char* SLOT_ID[4] = {"A1", "A2", "B1", "B2"};
const char* TOPIC_SENSOR[4] = {
 "smartparking/sensor/L1/A1", "smartparking/sensor/L1/A2",
 "smartparking/sensor/L2/B1", "smartparking/sensor/L2/B2"
};
const char* TOPIC_RFID = "smartparking/rfid/scan";
const char* TOPIC_GATE_SENSOR = "smartparking/sensor/gate";
const char* TOPIC_STATUS = "smartparking/esp32/status";
const char* TOPIC_ENTRY_CMD = "smartparking/gate/entry/cmd";
const char* TOPIC_EXIT_CMD = "smartparking/gate/exit/cmd";
const char* TOPIC_LCD_CMD = "smartparking/lcd/cmd";

WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);
unsigned long lastSensorPublish = 0;
unsigned long lastGatePublish = 0;
unsigned long lastStatusPublish = 0;

float readDistance(int index) {
  digitalWrite(TRIG[index], LOW); delayMicroseconds(3);
  digitalWrite(TRIG[index], HIGH); delayMicroseconds(10);
  digitalWrite(TRIG[index], LOW);
  unsigned long duration = pulseIn(ECHO[index], HIGH, 30000);
  if (duration == 0) return -1.0;
  return duration * 0.0343f / 2.0f;
}

void publishDistance(const char* topic, float cm, const char* label) {
  char payload[160];
  bool occupied = (cm > 0 && cm < 15.0); // kalibrasi jarak sesuai pemasangan
  snprintf(payload, sizeof(payload),
    "{\"sensor\":\"%s\",\"distance_cm\":%.1f,\"occupied\":%s,\"valid\":%s}",
    label, cm, occupied ? "true" : "false", cm > 0 ? "true" : "false");
  mqtt.publish(topic, payload, false);
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message;
  for (unsigned int i = 0; i < length; i++) message += (char)payload[i];
  String t(topic);
  if (t == TOPIC_ENTRY_CMD) {
    if (message.indexOf("open") >= 0) { servoEntry.write(SERVO_OPEN); lcd.clear(); lcd.print("Silakan Masuk"); }
    else { servoEntry.write(SERVO_CLOSED); }
  } else if (t == TOPIC_EXIT_CMD) {
    if (message.indexOf("open") >= 0) { servoExit.write(SERVO_OPEN); lcd.clear(); lcd.print("Terima Kasih"); }
    else { servoExit.write(SERVO_CLOSED); }
  } else if (t == TOPIC_LCD_CMD) {
    lcd.clear(); lcd.setCursor(0,0); lcd.print(message.substring(0,16));
  }
}

void connectWiFi() {
  WiFi.mode(WIFI_STA); WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  lcd.clear(); lcd.print("Menghubungkan");
  while (WiFi.status() != WL_CONNECTED) { delay(500); }
  lcd.clear(); lcd.print("WiFi Terhubung");
  lcd.setCursor(0,1); lcd.print(WiFi.localIP());
}

void connectMQTT() {
  while (!mqtt.connected()) {
    String clientId = "SmartParking-" + String((uint32_t)ESP.getEfuseMac(), HEX);
    if (mqtt.connect(clientId.c_str(), MQTT_USER, MQTT_PASS,
                     TOPIC_STATUS, 1, true, "{\"status\":\"offline\"}")) {
      mqtt.subscribe(TOPIC_ENTRY_CMD); mqtt.subscribe(TOPIC_EXIT_CMD); mqtt.subscribe(TOPIC_LCD_CMD);
      mqtt.publish(TOPIC_STATUS, "{\"status\":\"online\",\"device\":\"ESP32-WROOM\"}", true);
    } else delay(2500);
  }
}

void publishRFID() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return;
  String uid;
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uid += "0";
    uid += String(rfid.uid.uidByte[i], HEX);
  }
  uid.toUpperCase();
  String payload = "{\"uid\":\"" + uid + "\",\"reader\":\"RC522\"}";
  mqtt.publish(TOPIC_RFID, payload.c_str());
  lcd.clear(); lcd.print("Kartu terbaca:"); lcd.setCursor(0,1); lcd.print(uid.substring(0,16));
  rfid.PICC_HaltA(); rfid.PCD_StopCrypto1();
}

void setup() {
  Serial.begin(115200);
  for (int i=0;i<5;i++) { pinMode(TRIG[i], OUTPUT); pinMode(ECHO[i], INPUT); digitalWrite(TRIG[i], LOW); }
  Wire.begin(21,22); lcd.init(); lcd.backlight(); lcd.print("SmartParking");
  SPI.begin(18,19,23,RFID_SS); rfid.PCD_Init();
  ESP32PWM::allocateTimer(0); ESP32PWM::allocateTimer(1);
  servoEntry.setPeriodHertz(50); servoExit.setPeriodHertz(50);
  servoEntry.attach(SERVO_ENTRY_PIN, 500, 2400); servoExit.attach(SERVO_EXIT_PIN, 500, 2400);
  servoEntry.write(SERVO_CLOSED); servoExit.write(SERVO_CLOSED);
  connectWiFi(); mqtt.setServer(MQTT_HOST, MQTT_PORT); mqtt.setCallback(mqttCallback); mqtt.setBufferSize(512);
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) connectMQTT();
  mqtt.loop();
  publishRFID();
  unsigned long now = millis();
  if (now - lastSensorPublish >= 2000) {
    lastSensorPublish = now;
    for (int i=0;i<4;i++) publishDistance(TOPIC_SENSOR[i], readDistance(i), SLOT_ID[i]);
  }
  if (now - lastGatePublish >= 500) {
    lastGatePublish = now;
    float cm = readDistance(4);
    if (cm > 0 && cm < 20) publishDistance(TOPIC_GATE_SENSOR, cm, "ENTRY_GATE");
  }
  if (now - lastStatusPublish >= 10000) {
    lastStatusPublish = now;
    mqtt.publish(TOPIC_STATUS, "{\"status\":\"online\",\"device\":\"ESP32-WROOM\"}", true);
  }
}
