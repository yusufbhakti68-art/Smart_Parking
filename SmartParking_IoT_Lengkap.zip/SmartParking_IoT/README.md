# SmartParking Island — Starter Project IoT

Paket awal integrasi dashboard `Smart_Parking.html`, ESP32-WROOM, MQTT Mosquitto, PHP API, MariaDB, dan firmware Arduino.

## Isi paket

- `dashboard/index.html` — dashboard asli yang diberikan, sudah ditambahkan MQTT.js dan adapter integrasi.
- `dashboard/integration.js` — menerima data MQTT dan sinkronisasi status slot melalui API.
- `firmware/SmartParking_ESP32.ino` — firmware ESP32-WROOM; asumsi RFID RC522, 5 ultrasonik, 2 servo, LCD 16x2 I2C.
- `docs/BLUEPRINT_PINOUT.md` — blueprint pinout, skema pembagi tegangan, dan catatan catu daya.
- `database/smartparking.sql` — database awal dan tabel yang dibutuhkan.
- `backend/api/` — endpoint status dan health check.
- `backend/mqtt/worker.py` — penghubung MQTT ke MariaDB, proses RFID masuk/keluar dan perintah palang.
- `mosquitto/` — contoh konfigurasi broker.
- `nginx/` — contoh virtual host Nginx.

## Penting sebelum dirakit

1. Tipe RFID belum diketahui. Firmware memakai RC522 sebagai **asumsi sementara**, bukan kepastian. Pastikan tulisan pada modul RFID sebelum menyalakan rangkaian.
2. Dashboard menunjukkan empat slot (A1, A2, B1, B2), jadi rancangan menyediakan empat sensor slot + satu sensor pemicu gerbang. Total lima HC-SR04.
3. ECHO HC-SR04 adalah 5V. Turunkan ke 3.3V menggunakan pembagi tegangan pada setiap pin ECHO sebelum masuk ke ESP32.
4. Servo menggunakan supply 5V eksternal. Satukan GND supply dengan GND ESP32. Jangan memberi daya servo dari pin 3V3.
5. Ganti semua placeholder password dan IP. Jangan expose MQTT tanpa password ke internet.

## A. Persiapan server Ubuntu/Debian

Contoh instalasi:

```bash
sudo apt update
sudo apt install nginx mariadb-server php-fpm php-mysql mosquitto mosquitto-clients python3-venv python3-pip -y
```

Salin folder proyek ke `/var/www/smartparking` (atau sesuaikan root Nginx):

```bash
sudo mkdir -p /var/www/smartparking
sudo cp -r . /var/www/smartparking/
sudo chown -R www-data:www-data /var/www/smartparking
```

Import database:

```bash
sudo mysql < /var/www/smartparking/database/smartparking.sql
```

Buat user DB dengan password sendiri:

```sql
CREATE USER 'smartparking_app'@'localhost' IDENTIFIED BY 'PASSWORD_DATABASE_KUAT';
GRANT SELECT, INSERT, UPDATE, DELETE ON smartparking.* TO 'smartparking_app'@'localhost';
FLUSH PRIVILEGES;
```

Salin dan edit konfigurasi PHP:

```bash
cd /var/www/smartparking/backend/config
sudo cp config.php config.local.php
sudo nano config.local.php
```

Isi `db_pass` dengan password DB yang dibuat. Batasi izin file:

```bash
sudo chown root:www-data config.local.php
sudo chmod 640 config.local.php
```

## B. Mosquitto MQTT

Buat user MQTT (gunakan password berbeda dari database):

```bash
sudo mosquitto_passwd -c /etc/mosquitto/passwd smartparking
```

Salin konfigurasi contoh:

```bash
sudo cp /var/www/smartparking/mosquitto/mosquitto.conf /etc/mosquitto/conf.d/smartparking.conf
sudo systemctl restart mosquitto
sudo systemctl enable mosquitto
```

Catat username dan password MQTT. Masukkan password yang sama di firmware, `dashboard/index.html`, dan service worker. Port 1883 untuk ESP32/backend; port 9001 WebSocket untuk dashboard browser. Firewall LAN:

```bash
sudo ufw allow 80/tcp
sudo ufw allow 1883/tcp
sudo ufw allow 9001/tcp
```

Jangan buka port MQTT ke internet publik. Untuk penggunaan di luar LAN, gunakan TLS/VPN dan ACL topic.

## C. Python MQTT worker

Edit `backend/mqtt/worker.py` hanya jika nama database/tabel/topic diubah. Siapkan environment:

```bash
cd /var/www/smartparking/backend/mqtt
sudo python3 -m venv venv
sudo ./venv/bin/pip install -r requirements.txt
```

Uji manual (ganti password sesuai konfigurasi):

```bash
DB_PASS='PASSWORD_DATABASE_KUAT' MQTT_PASS='PASSWORD_MQTT_KUAT' ./venv/bin/python worker.py
```

Untuk service otomatis, salin `smartparking-mqtt.service` ke `/etc/systemd/system/`, edit semua `GANTI_...`, lalu:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now smartparking-mqtt
sudo systemctl status smartparking-mqtt
```

## D. Nginx dan PHP-FPM

Salin `nginx/smartparking.conf` ke `/etc/nginx/sites-available/smartparking`. Sesuaikan socket PHP-FPM, misalnya `/run/php/php8.3-fpm.sock` berdasarkan versi yang terpasang. Aktifkan:

```bash
sudo ln -s /etc/nginx/sites-available/smartparking /etc/nginx/sites-enabled/smartparking
sudo nginx -t
sudo systemctl reload nginx
```

Nonaktifkan site default jika bentrok `server_name`/port 80. Endpoint tes: `http://IP_SERVER/api/health.php`.

## E. Set IP server dan upload firmware

Cari IP LAN server:

```bash
hostname -I
```

Edit `MQTT_HOST` pada `firmware/SmartParking_ESP32.ino` dengan IP tersebut (contoh `192.168.1.10`). Edit SSID/password Wi-Fi. Edit password MQTT. Di `dashboard/index.html`, konfigurasi `mqttPassword` harus sama dengan user MQTT. Dashboard otomatis memakai hostname/IP yang sama untuk WebSocket.

Arduino IDE: pasang board package ESP32, lalu Library Manager:

- PubSubClient
- MFRC522
- ESP32Servo
- LiquidCrystal_I2C

Pilih board ESP32 Dev Module / ESP32-WROOM DevKit dan port yang sesuai, lalu upload.

## F. Daftarkan kartu RFID

Baca UID melalui serial monitor atau LCD. Tambahkan ke database:

```sql
INSERT INTO Kartu_tbl(nomor_kartu,status_kartu) VALUES ('UID_KARTU_KAPITAL','aktif');
```

Kartu yang tidak terdaftar atau tidak aktif ditolak. Tap pertama membuka transaksi masuk dan memilih slot kosong; tap kartu yang sama ketika transaksi masih berjalan menutup transaksi dan membuka gerbang keluar.

## G. Uji bertahap

1. Pastikan ESP32 tersambung Wi-Fi dan MQTT.
2. Jalankan `sudo journalctl -u smartparking-mqtt -f` untuk log worker.
3. Buka `http://IP_SERVER/` dari browser di jaringan yang sama.
4. Cek `http://IP_SERVER/api/health.php` dan `http://IP_SERVER/api/state.php`.
5. Uji satu sensor ultrasonik dulu, kalibrasi ambang 15 cm, baru pasang semua sensor.
6. Uji servo tanpa palang mekanik terlebih dahulu.
7. Daftarkan UID RFID, lalu uji tap masuk dan tap keluar.

## Batasan versi starter ini

- Login pada HTML asli masih berupa simulasi sisi browser. Endpoint autentikasi aman belum dibuat; jangan gunakan sebagai sistem produksi atau untuk data akun nyata sebelum autentikasi PHP berbasis `password_hash()`/`password_verify()`, session, CSRF protection, dan pembatasan akses ditambahkan.
- Endpoint state hanya untuk monitoring; transaksi masuk/keluar dibuat oleh worker MQTT saat UID RFID diterima.
- Perhitungan tarif, pembayaran, booking, denda, dan manajemen user di dashboard asli masih membutuhkan integrasi backend lanjutan. Struktur tabel awal sudah disediakan tetapi belum seluruh alur bisnis diaktifkan.
- Worker memakai asumsi bahwa tap RFID pertama adalah masuk dan tap berikutnya dari UID yang sama adalah keluar. Untuk instalasi dengan reader masuk dan keluar terpisah, gunakan topic reader terpisah dan aturan arah yang eksplisit.
- Sensor gerbang hanya dipublikasikan sebagai pemicu/pencatatan; pembukaan palang tetap diputuskan backend berdasarkan kartu dan slot tersedia.

## Topic MQTT

- `smartparking/esp32/status`
- `smartparking/sensor/L1/A1`, `.../A2`, `smartparking/sensor/L2/B1`, `.../B2`
- `smartparking/sensor/gate`
- `smartparking/rfid/scan`
- `smartparking/gate/entry/cmd`, `smartparking/gate/exit/cmd`
- `smartparking/lcd/cmd`
- `smartparking/notification`
