#!/usr/bin/env python3
"""MQTT bridge: sensor logging, RFID entry/exit, slot status and gate commands."""
import json, os, time
import pymysql
import paho.mqtt.client as mqtt

DB = dict(host=os.getenv('DB_HOST','127.0.0.1'), user=os.getenv('DB_USER','smartparking_app'),
          password=os.getenv('DB_PASS','GANTI_PASSWORD_DATABASE'), database=os.getenv('DB_NAME','smartparking'),
          charset='utf8mb4', autocommit=False, cursorclass=pymysql.cursors.DictCursor)
MQTT_HOST=os.getenv('MQTT_HOST','127.0.0.1'); MQTT_PORT=int(os.getenv('MQTT_PORT','1883'))
MQTT_USER=os.getenv('MQTT_USER','smartparking'); MQTT_PASS=os.getenv('MQTT_PASS','GANTI_PASSWORD_MQTT')
TOPIC_RFID='smartparking/rfid/scan'; TOPIC_STATUS='smartparking/esp32/status'

def db(): return pymysql.connect(**DB)
def publish(client, topic, payload): client.publish(topic, json.dumps(payload) if isinstance(payload,dict) else payload, qos=1)

def on_connect(client, userdata, flags, reason_code, properties):
    print('MQTT connected:', reason_code)
    client.subscribe([('smartparking/sensor/+',0),('smartparking/sensor/+/+',0),(TOPIC_RFID,1),(TOPIC_STATUS,1)])

def on_message(client, userdata, msg):
    try: data=json.loads(msg.payload.decode())
    except Exception: print('Payload JSON tidak valid:',msg.topic); return
    try:
      con=db()
      with con.cursor() as cur:
        if msg.topic.startswith('smartparking/sensor/'):
          parts=msg.topic.split('/')
          slot=parts[-1] if len(parts)>=4 else ('gate' if len(parts)==3 and parts[-1]=='gate' else None)
          cm=data.get('distance_cm'); valid=data.get('valid', cm is not None and cm>0)
          occupied=bool(data.get('occupied')) if valid else None
          if slot in ('A1','A2','B1','B2') and valid:
            status='terisi' if occupied else 'kosong'
            cur.execute('UPDATE Slot_tbl SET status_slot=%s WHERE nomor_slot=%s AND status_slot<>\'maintenance\'',(status,slot))
            cur.execute('INSERT INTO Log_sensor_tbl(nomor_slot,jarak_cm,status_terdeteksi,payload) VALUES(%s,%s,%s,%s)',(slot,cm,status,json.dumps(data)))
          elif slot=='gate':
            cur.execute("INSERT INTO Log_sensor_tbl(nomor_slot,jarak_cm,status_terdeteksi,payload) VALUES(NULL,%s,'gerbang_aktif',%s)",(cm,json.dumps(data)))
        elif msg.topic==TOPIC_STATUS:
          online=data.get('status')=='online'
          cur.execute("UPDATE Perangkat_tbl SET status_perangkat=%s,last_seen=NOW() WHERE id_perangkat=1",('online' if online else 'offline',))
        elif msg.topic==TOPIC_RFID:
          uid=str(data.get('uid','')).upper().strip()
          if not uid: con.rollback(); con.close(); return
          cur.execute("SELECT id_kartu,status_kartu FROM Kartu_tbl WHERE nomor_kartu=%s",(uid,)); card=cur.fetchone()
          if not card or card['status_kartu']!='aktif':
            publish(client,'smartparking/lcd/cmd','Kartu tidak aktif'); publish(client,'smartparking/notification',{'type':'error','message':'RFID tidak terdaftar/aktif','uid':uid})
          else:
            cur.execute("SELECT t.id_transaksi,d.id_slot,s.nomor_slot FROM Transaksi_tbl t JOIN Detail_transaksi_tbl d ON d.id_transaksi=t.id_transaksi JOIN Slot_tbl s ON s.id_slot=d.id_slot WHERE t.id_kartu=%s AND t.status_transaksi='berjalan' ORDER BY t.waktu_masuk DESC LIMIT 1",(card['id_kartu'],)); active=cur.fetchone()
            if active:
              cur.execute("UPDATE Transaksi_tbl SET waktu_keluar=NOW(),total_durasi=TIMESTAMPDIFF(MINUTE,waktu_masuk,NOW()),status_transaksi='selesai' WHERE id_transaksi=%s",(active['id_transaksi'],))
              cur.execute("UPDATE Detail_transaksi_tbl SET status_transaksi='menunggu_bayar' WHERE id_transaksi=%s",(active['id_transaksi'],))
              cur.execute("UPDATE Slot_tbl SET status_slot='kosong' WHERE id_slot=%s",(active['id_slot'],))
              publish(client,'smartparking/gate/exit/cmd',{'action':'open'}); publish(client,'smartparking/lcd/cmd','Silakan keluar')
              cur.execute("INSERT INTO Log_aktivitas_tbl(aktivitas,keterangan) VALUES('Kendaraan keluar',%s)",(f"UID {uid}, slot {active['nomor_slot']}",))
            else:
              cur.execute("SELECT id_slot,nomor_slot FROM Slot_tbl WHERE status_slot='kosong' ORDER BY id_slot LIMIT 1 FOR UPDATE"); slot=cur.fetchone()
              if not slot:
                publish(client,'smartparking/lcd/cmd','Parkir penuh'); publish(client,'smartparking/notification',{'type':'warning','message':'Slot parkir penuh'})
              else:
                cur.execute("INSERT INTO Transaksi_tbl(id_kartu,tanggal,waktu_masuk,status_transaksi) VALUES(%s,CURDATE(),NOW(),'berjalan')",(card['id_kartu'],)); tx=cur.lastrowid
                cur.execute("INSERT INTO Detail_transaksi_tbl(id_transaksi,id_slot,id_tarif,status_transaksi) VALUES(%s,%s,1,'berjalan')",(tx,slot['id_slot']))
                cur.execute("UPDATE Slot_tbl SET status_slot='terisi' WHERE id_slot=%s",(slot['id_slot'],))
                publish(client,'smartparking/gate/entry/cmd',{'action':'open'}); publish(client,'smartparking/lcd/cmd',f"Masuk slot {slot['nomor_slot']}")
                cur.execute("INSERT INTO Log_aktivitas_tbl(aktivitas,keterangan) VALUES('Kendaraan masuk',%s)",(f"UID {uid}, slot {slot['nomor_slot']}",))
      con.commit(); con.close()
    except Exception as e:
      print('DB/MQTT processing error:',repr(e))
      try: con.rollback(); con.close()
      except Exception: pass

client=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id='smartparking-backend')
client.username_pw_set(MQTT_USER,MQTT_PASS)
client.on_connect=on_connect; client.on_message=on_message
client.connect(MQTT_HOST,MQTT_PORT,60)
client.loop_forever()
