<?php
// Salin file ini menjadi config.local.php dan ubah kredensial untuk server Anda.
return [
  'db_host' => '127.0.0.1', 'db_name' => 'smartparking',
  'db_user' => 'smartparking_app', 'db_pass' => 'GANTI_PASSWORD_DATABASE',
];
