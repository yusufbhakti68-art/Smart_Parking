<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
require_once __DIR__ . '/../config/database.php';
try {
 $slots = $pdo->query("SELECT s.nomor_slot AS id, l.nama_lantai AS lantai, s.status_slot AS status FROM Slot_tbl s JOIN Lantai_tbl l ON l.id_lantai=s.id_lantai ORDER BY s.id_slot")->fetchAll();
 $active = $pdo->query("SELECT t.id_transaksi, k.nomor_kartu, s.nomor_slot, t.waktu_masuk FROM Transaksi_tbl t JOIN Kartu_tbl k ON k.id_kartu=t.id_kartu JOIN Detail_transaksi_tbl d ON d.id_transaksi=t.id_transaksi JOIN Slot_tbl s ON s.id_slot=d.id_slot WHERE t.status_transaksi='berjalan' ORDER BY t.waktu_masuk DESC")->fetchAll();
 $device = $pdo->query("SELECT nama_perangkat,status_perangkat,last_seen FROM Perangkat_tbl WHERE id_perangkat=1")->fetch();
 echo json_encode(['ok'=>true,'slots'=>$slots,'active'=>$active,'device'=>$device,'server_time'=>date(DATE_ATOM)]);
} catch(Throwable $e) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Gagal mengambil status. Periksa konfigurasi database.']); }
