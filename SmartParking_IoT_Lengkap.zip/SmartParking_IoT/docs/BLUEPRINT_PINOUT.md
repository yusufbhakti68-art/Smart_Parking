# BLUEPRINT PINOUT SMARTPARKING — ESP32-WROOM

## Gambaran sistem

ESP32-WROOM menjadi pengendali. RFID membaca UID kartu. Lima HC-SR04 dipakai sebagai empat sensor okupansi slot (A1, A2, B1, B2) dan satu sensor pemicu kendaraan di gerbang masuk. Dua servo menggerakkan palang masuk/keluar. LCD 16x2 menampilkan pesan. Data dikirim ke broker Mosquitto melalui Wi-Fi.

> Catatan: dashboard yang diberikan menampilkan empat slot. Karena itu blueprint menyediakan empat sensor slot ditambah satu sensor gerbang (total 5 ultrasonik). Jika maksud “sensor gerbang” hanya satu sensor total, empat sensor slot dapat tidak dipasang, tetapi status slot tidak akan otomatis terdeteksi satu per satu.

## Peta pin ESP32-WROOM

| Komponen | Pin modul | Pin ESP32 | Catatan |
|---|---|---:|---|
| RC522 SDA/SS | SDA / SS | GPIO 5 | SPI chip select |
| RC522 SCK | SCK | GPIO 18 | SPI clock |
| RC522 MOSI | MOSI | GPIO 23 | SPI data ke modul |
| RC522 MISO | MISO | GPIO 19 | SPI data dari modul |
| RC522 RST | RST | GPIO 27 | Reset |
| RC522 3.3V | 3.3V | 3V3 | **Jangan 5V** |
| RC522 GND | GND | GND | Ground bersama |
| LCD SDA | SDA | GPIO 21 | I2C |
| LCD SCL | SCL | GPIO 22 | I2C |
| LCD VCC | VCC | 5V sesuai modul | Gunakan level shifter I2C bila pull-up LCD ke 5V |
| LCD GND | GND | GND | Ground bersama |
| Servo gerbang masuk | Signal | GPIO 25 | Supply servo 5V eksternal |
| Servo gerbang keluar | Signal | GPIO 26 | Supply servo 5V eksternal |
| HC-SR04 slot A1 | TRIG / ECHO | GPIO 13 / GPIO 34 | Echo wajib diturunkan ke 3.3V |
| HC-SR04 slot A2 | TRIG / ECHO | GPIO 14 / GPIO 35 | Echo wajib diturunkan ke 3.3V |
| HC-SR04 slot B1 | TRIG / ECHO | GPIO 16 / GPIO 32 | Echo wajib diturunkan ke 3.3V |
| HC-SR04 slot B2 | TRIG / ECHO | GPIO 17 / GPIO 33 | Echo wajib diturunkan ke 3.3V |
| HC-SR04 gerbang | TRIG / ECHO | GPIO 4 / GPIO 36 | Echo wajib diturunkan ke 3.3V |

## Diagram koneksi blok

```text
                 Wi-Fi 2.4 GHz
                       |
                 +-----v------+
                 | ESP32-WROOM|
                 +-----+------+
                       |
      +----------------+-------------------------+
      |                |             |           |
   SPI|             GPIO PWM       GPIO TRIG/   I2C
      |                |             ECHO        |
  +---v---+       +----+----+    +-----+------+  +------+
  | RC522 |       | 2 Servo |    | 5 HC-SR04 |  | LCD  |
  +-------+       +---------+    +------------+  +------+
                       |
             Mosquitto MQTT broker
                       |
           Python worker + MariaDB
                       |
              PHP API + Dashboard
```

## Pembagi tegangan ECHO HC-SR04

Pin ECHO HC-SR04 umumnya menghasilkan 5V, sedangkan GPIO ESP32 hanya aman pada level 3.3V. Pasang pembagi tegangan pada **setiap kabel ECHO**:

```text
HC-SR04 ECHO ----[ 1 kΩ ]----+---- GPIO ESP32 (ECHO)
                            |
                          [ 2 kΩ ]
                            |
                           GND
```

Dengan 1kΩ di atas dan 2kΩ ke GND, tegangan 5V turun kira-kira menjadi 3.3V. Gunakan resistor untuk masing-masing dari lima sensor.

## Catu daya yang benar

- ESP32 diberi daya melalui USB 5V atau regulator yang stabil.
- RC522 memakai 3.3V dari ESP32; jangan sambungkan ke 5V.
- Servo jangan mengambil arus dari pin 3V3 ESP32. Gunakan adaptor/regulator 5V eksternal yang arusnya cukup untuk dua servo (pilih minimal 2A sebagai titik awal; sesuaikan spesifikasi servo).
- Semua GND harus disatukan: ESP32, supply servo, sensor, LCD, dan RFID.
- HC-SR04 biasanya memakai 5V. Satukan GND dan turunkan level ECHO seperti diagram.
- Jika LCD I2C diberi 5V dan modul pull-up SDA/SCL ke 5V, gunakan logic-level shifter I2C dua arah. Alternatifnya pastikan pull-up I2C ke 3.3V.
- Jangan menghubungkan supply 5V servo langsung ke pin 3V3 ESP32.

## Catatan RFID

Tipe RFID belum diketahui. Sketch saat ini memakai **RC522** sebagai asumsi awal (umum, SPI, 3.3V). Jika modul ternyata PN532 atau tipe lain, wiring dan library berbeda dan sketch perlu diganti. UID yang terbaca harus didaftarkan ke `Kartu_tbl.nomor_kartu` dalam format heksadesimal tanpa spasi, huruf kapital. Contoh UID `A1B2C3D4`.

## Kalibrasi

- Ambang deteksi slot pada firmware saat ini: jarak kurang dari 15 cm = terisi. Sesuaikan dengan tinggi sensor dan jarak lantai/kendaraan.
- Ambang sensor gerbang: 20 cm.
- Sudut servo tertutup 0°, terbuka 90°. Sesuaikan mekanik palang; jangan memaksa servo melewati batas geraknya.
- Sensor ultrasonik yang berdekatan dapat saling mengganggu (cross-talk). Pasang mengarah ke bawah/target masing-masing dan pertimbangkan membaca sensor bergiliran dengan jeda jika hasil tidak stabil.
