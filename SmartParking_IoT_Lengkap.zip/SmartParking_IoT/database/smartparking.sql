CREATE DATABASE IF NOT EXISTS smartparking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartparking;

CREATE TABLE IF NOT EXISTS User_tbl (
 id_user INT AUTO_INCREMENT PRIMARY KEY, nama_user VARCHAR(100) NOT NULL,
 email_user VARCHAR(120) NOT NULL UNIQUE, password_user VARCHAR(255) NOT NULL,
 role_user ENUM('admin','driver') NOT NULL DEFAULT 'driver', status_user TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Kartu_tbl (
 id_kartu INT AUTO_INCREMENT PRIMARY KEY, nomor_kartu VARCHAR(32) NOT NULL UNIQUE,
 status_kartu ENUM('aktif','nonaktif','blokir') NOT NULL DEFAULT 'aktif', id_user INT NULL,
 FOREIGN KEY (id_user) REFERENCES User_tbl(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Lantai_tbl (
 id_lantai INT AUTO_INCREMENT PRIMARY KEY, nama_lantai VARCHAR(50) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Slot_tbl (
 id_slot INT AUTO_INCREMENT PRIMARY KEY, id_lantai INT NOT NULL, nomor_slot VARCHAR(12) NOT NULL UNIQUE,
 status_slot ENUM('kosong','terisi','maintenance') NOT NULL DEFAULT 'kosong',
 FOREIGN KEY (id_lantai) REFERENCES Lantai_tbl(id_lantai)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Tarif_tbl (
 id_tarif INT AUTO_INCREMENT PRIMARY KEY, tarif_perjam DECIMAL(12,2) NOT NULL DEFAULT 2000,
 tarif_maksimal DECIMAL(12,2) NOT NULL DEFAULT 20000, status_tarif TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Metode_pembayaran_tbl (
 id_metode INT AUTO_INCREMENT PRIMARY KEY, nama_metode VARCHAR(40) NOT NULL,
 status TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Denda_tbl (
 id_denda INT AUTO_INCREMENT PRIMARY KEY, nama_denda VARCHAR(100) NOT NULL,
 batas_waktu INT NOT NULL DEFAULT 0, jumlah_denda DECIMAL(12,2) NOT NULL DEFAULT 0,
 status_denda TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Transaksi_tbl (
 id_transaksi BIGINT AUTO_INCREMENT PRIMARY KEY, id_kartu INT NOT NULL, id_user INT NULL,
 tanggal DATE NOT NULL, waktu_masuk DATETIME NOT NULL, waktu_keluar DATETIME NULL,
 total_durasi INT NULL, status_transaksi ENUM('berjalan','selesai','dibatalkan') NOT NULL DEFAULT 'berjalan',
 FOREIGN KEY (id_kartu) REFERENCES Kartu_tbl(id_kartu),
 FOREIGN KEY (id_user) REFERENCES User_tbl(id_user) ON DELETE SET NULL,
 INDEX idx_transaksi_status(status_transaksi)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Detail_transaksi_tbl (
 id_detail BIGINT AUTO_INCREMENT PRIMARY KEY, id_transaksi BIGINT NOT NULL,
 id_slot INT NOT NULL, id_tarif INT NULL, id_metode INT NULL, id_denda INT NULL,
 total_tarif DECIMAL(12,2) NOT NULL DEFAULT 0,
 status_transaksi ENUM('berjalan','menunggu_bayar','lunas') NOT NULL DEFAULT 'berjalan',
 FOREIGN KEY (id_transaksi) REFERENCES Transaksi_tbl(id_transaksi),
 FOREIGN KEY (id_slot) REFERENCES Slot_tbl(id_slot),
 FOREIGN KEY (id_tarif) REFERENCES Tarif_tbl(id_tarif) ON DELETE SET NULL,
 FOREIGN KEY (id_metode) REFERENCES Metode_pembayaran_tbl(id_metode) ON DELETE SET NULL,
 FOREIGN KEY (id_denda) REFERENCES Denda_tbl(id_denda) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Log_sensor_tbl (
 id_log BIGINT AUTO_INCREMENT PRIMARY KEY, nomor_slot VARCHAR(12) NULL,
 jarak_cm DECIMAL(7,2) NULL, status_terdeteksi ENUM('kosong','terisi','gerbang_aktif','unknown') NOT NULL,
 payload JSON NULL, waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP, INDEX(waktu)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Perangkat_tbl (
 id_perangkat INT AUTO_INCREMENT PRIMARY KEY, nama_perangkat VARCHAR(80) NOT NULL,
 status_perangkat ENUM('online','offline') NOT NULL DEFAULT 'offline', last_seen DATETIME NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS Log_aktivitas_tbl (
 id_log BIGINT AUTO_INCREMENT PRIMARY KEY, aktivitas VARCHAR(120) NOT NULL,
 keterangan TEXT NULL, waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO Lantai_tbl(id_lantai,nama_lantai) VALUES (1,'Lantai 1'),(2,'Lantai 2');
INSERT IGNORE INTO Slot_tbl(id_lantai,nomor_slot) VALUES (1,'A1'),(1,'A2'),(2,'B1'),(2,'B2');
INSERT INTO Tarif_tbl(id_tarif,tarif_perjam,tarif_maksimal,status_tarif) SELECT 1,2000,20000,1 WHERE NOT EXISTS(SELECT 1 FROM Tarif_tbl WHERE id_tarif=1);
INSERT IGNORE INTO Metode_pembayaran_tbl(id_metode,nama_metode,status) VALUES (1,'Tunai',1),(2,'QRIS',1);
INSERT IGNORE INTO Denda_tbl(id_denda,nama_denda,batas_waktu,jumlah_denda,status_denda) VALUES (1,'Denda keterlambatan',0,0,0);
INSERT IGNORE INTO Perangkat_tbl(id_perangkat,nama_perangkat,status_perangkat) VALUES (1,'ESP32-WROOM Main Controller','offline');
-- Tambahkan kartu setelah mengetahui UID RFID, contoh:
-- INSERT INTO Kartu_tbl(nomor_kartu,status_kartu) VALUES ('A1B2C3D4','aktif');
-- Buat admin dengan password hash melalui PHP password_hash(), jangan simpan password polos.
