# Patch notes — V12.1 V11 compatibility deployment fixes

- Login endpoint: removed duplicate IP rate-limit query and duplicate login-attempt cleanup.
- Deployment: defaults to V11 local/demo database credentials when no env file exists, rather than stopping on first run; still uses protected config outside web root.
- Deployment: migration `USE biomatrix` statements are rewritten to the configured validated DB name, enabling custom database names.
- Deployment: requires an existing database with the `users` table, creates file and SQL backups, preserves existing V11 user passwords, and restarts Nginx/MQTT service.
- Added concise upgrade guide. This patch does not claim hardware or live broker integration testing.
- Deployment: creates the `biomatrix-mqtt.service` systemd unit when missing and checks/installs Debian Python MQTT/MySQL packages if unavailable.
