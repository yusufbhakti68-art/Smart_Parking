# BioMatrix V12.1 — Patch Deploy (V11-compatible)

## Target
Upgrade an existing BioMatrix V11 installation to the V12.1 package while preserving the existing database and V11 account passwords.

## Quick upgrade
1. Copy/extract this package to the server.
2. If `/etc/biomatrix/biomatrix.env` does not exist, the deploy script creates one with local V11 demo credentials (database user `biomatrix`, database `biomatrix`, password `biomatrix123`, MQTT localhost:1883). For a server with different credentials, edit the file first.
3. Run as root:
   `sudo bash deploy_biomatrix.sh`
4. The script backs up the existing website and database, requires an existing database with a `users` table, applies migration SQL in order, updates Nginx and the MQTT service environment, creates the MQTT systemd unit if absent, installs Debian Python dependencies when needed, and restarts services.
5. Visit `http://SERVER-IP:8080/` and `/admin/`. Use the V11 account/password already stored in your database; the upgrade does not reset it.

## Important
- Do NOT import `database/biomatrix_v7_full.sql` on an existing database. It contains database reset/drop statements.
- V11 demo database password is weak. Change it and update `/etc/biomatrix/biomatrix.env`; restrict DB/MQTT access to trusted hosts.
- For MQTT auth, set `BM_MQTT_USER` and `BM_MQTT_PASS` in the env file. ESP32 `esp32/main.py` must be configured with the same broker host/port and credentials before reflashing.
- The Nginx deployment listens on port 8080. Confirm firewall and PHP-FPM service.
- Custom registered sensors/actuators in V12 require compatible firmware topic/GPIO mappings. Existing V11 soil, DHT11, fan and pump topics are retained.
- The static report is not a claim of live integration testing. Verify database, MQTT broker, worker service, and ESP32 after deploying.
