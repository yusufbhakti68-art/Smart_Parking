#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WEB_ROOT="${BM_WEB_ROOT:-/var/www/biomatrix}"
ENV_FILE="${BM_ENV_FILE:-/etc/biomatrix/biomatrix.env}"
BACKUP_DIR="/root/backup_biomatrix_$(date +%Y%m%d_%H%M%S)"

if [[ $EUID -ne 0 ]]; then echo "Jalankan dengan sudo/root."; exit 1; fi

# Default values intentionally match the V11 local/demo setup for easier upgrade.
# Change DB password and MQTT credentials for production.
if [[ ! -f "$ENV_FILE" ]]; then
  install -d -m 0750 "$(dirname "$ENV_FILE")"
  cat > "$ENV_FILE" <<'ENV'
BM_DB_HOST=127.0.0.1
BM_DB_NAME=biomatrix
BM_DB_USER=biomatrix
BM_DB_PASS=biomatrix123
BM_MQTT_HOST=127.0.0.1
BM_MQTT_PORT=1883
BM_MQTT_USER=
BM_MQTT_PASS=
ENV
  chmod 0640 "$ENV_FILE"
  echo "[CONFIG] File konfigurasi dibuat dengan nilai kompatibel V11: $ENV_FILE"
  echo "[PERINGATAN] Password database default V11 dipakai untuk kemudahan upgrade. Ganti setelah deploy/ sebelum akses jaringan luas."
fi
set -a; source "$ENV_FILE"; set +a
: "${BM_DB_HOST:?BM_DB_HOST wajib}"; : "${BM_DB_NAME:?BM_DB_NAME wajib}"; : "${BM_DB_USER:?BM_DB_USER wajib}"; : "${BM_DB_PASS:?BM_DB_PASS wajib}"
if [[ ! "$BM_DB_NAME" =~ ^[A-Za-z0-9_]+$ ]]; then echo "Nama database hanya boleh huruf, angka, dan underscore."; exit 2; fi
install -d -m 0750 /etc/biomatrix
chown root:www-data /etc/biomatrix
php -r '$c=["db_host"=>getenv("BM_DB_HOST"),"db_name"=>getenv("BM_DB_NAME"),"db_user"=>getenv("BM_DB_USER"),"db_pass"=>getenv("BM_DB_PASS"),"mqtt_host"=>getenv("BM_MQTT_HOST")?:"127.0.0.1","mqtt_port"=>(int)(getenv("BM_MQTT_PORT")?:1883),"mqtt_user"=>getenv("BM_MQTT_USER")?:null,"mqtt_pass"=>getenv("BM_MQTT_PASS")?:null]; file_put_contents("/etc/biomatrix/biomatrix.php", "<?php return ".var_export($c,true).";\n");'
chown root:www-data /etc/biomatrix/biomatrix.php; chmod 0640 /etc/biomatrix/biomatrix.php

if [[ -f "$WEB_ROOT/index.html" ]]; then
  mkdir -p "$BACKUP_DIR/files"; cp -a "$WEB_ROOT/." "$BACKUP_DIR/files/"
  echo "[BACKUP] File lama: $BACKUP_DIR/files"
fi

# Database client credentials are kept in a protected temporary file.
MYSQL_CNF=$(mktemp); chmod 0600 "$MYSQL_CNF"
trap 'rm -f "$MYSQL_CNF"' EXIT
cat > "$MYSQL_CNF" <<EOF
[client]
host=$BM_DB_HOST
user=$BM_DB_USER
password=$BM_DB_PASS
EOF

if mysql --defaults-extra-file="$MYSQL_CNF" -N -e "SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME='${BM_DB_NAME}'" | grep -q 1; then
  mkdir -p "$BACKUP_DIR"
  mysqldump --defaults-extra-file="$MYSQL_CNF" --single-transaction --routines --triggers "$BM_DB_NAME" > "$BACKUP_DIR/database.sql"
  echo "[BACKUP] Database: $BACKUP_DIR/database.sql"
else
  echo "Database '$BM_DB_NAME' belum ada. Buat database dan import SQL dasar secara manual dahulu (SQL dasar mengandung DROP DATABASE; jangan jalankan pada DB berisi data)."
  exit 3
fi

TABLES=$(mysql --defaults-extra-file="$MYSQL_CNF" -N -e "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='${BM_DB_NAME}' AND TABLE_NAME='users';" 2>/dev/null || echo 0)
if [[ "$TABLES" == "0" ]]; then echo "Tabel users tidak ditemukan pada database '$BM_DB_NAME'. Pastikan database v11 sudah diimpor."; exit 3; fi

install -d -m 0755 "$WEB_ROOT"
rsync -a --delete --exclude='uploads/media/*' "$ROOT/" "$WEB_ROOT/"
install -d -o www-data -g www-data -m 0750 "$WEB_ROOT/uploads/media"
install -d -o root -g www-data -m 0770 /var/lib/biomatrix
chown -R www-data:www-data "$WEB_ROOT/uploads"

# Migration SQL in this package names the historical DB. Rewrite only the USE statement
# to the validated configured database, so custom BM_DB_NAME is supported.
for f in "$WEB_ROOT"/database/migrations/*.sql; do
  echo "[MIGRATION] $(basename "$f") -> $BM_DB_NAME"
  sed "s/^USE biomatrix;/USE \`$BM_DB_NAME\`;/g" "$f" | mysql --defaults-extra-file="$MYSQL_CNF"
done

# Install Python MQTT worker dependencies if absent; service unit is created if V11 had none.
if ! /usr/bin/python3 -c 'import pymysql, paho.mqtt.client' >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update
    apt-get install -y python3-paho-mqtt python3-pymysql
  else
    echo "Dependency Python MQTT/PyMySQL missing. Install pymysql and paho-mqtt for system Python."
    exit 5
  fi
fi
if [[ ! -f /etc/systemd/system/biomatrix-mqtt.service ]]; then
  cat > /etc/systemd/system/biomatrix-mqtt.service <<EOF
[Unit]
Description=BioMatrix MQTT Worker and Automation Engine
After=network-online.target mariadb.service mosquitto.service
Wants=network-online.target

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=$WEB_ROOT/backend/mqtt
ExecStart=/usr/bin/python3 $WEB_ROOT/backend/mqtt/worker.py
Restart=always
RestartSec=3
EnvironmentFile=-$ENV_FILE

[Install]
WantedBy=multi-user.target
EOF
fi
install -d -m 0755 /etc/systemd/system/biomatrix-mqtt.service.d
cat > /etc/systemd/system/biomatrix-mqtt.service.d/10-biomatrix-env.conf <<EOF
[Service]
EnvironmentFile=$ENV_FILE
EOF
systemctl daemon-reload
systemctl enable biomatrix-mqtt.service

PHP_SOCK=$(find /run/php/ -name 'php*-fpm.sock' | head -n 1)
if [[ -z "$PHP_SOCK" ]]; then echo "PHP-FPM socket tidak ditemukan."; exit 4; fi
cat > /etc/nginx/sites-available/biomatrix.conf <<EOF
server {
 listen 8080;
 server_name _;
 root $WEB_ROOT;
 index index.html index.php;
 client_max_body_size 9m;
 add_header X-Content-Type-Options nosniff always;
 add_header Referrer-Policy strict-origin-when-cross-origin always;
 add_header X-Frame-Options SAMEORIGIN always;
 location ~* ^/(backend/config|database|esp32)/ { deny all; }
 location ~ /\\. { deny all; }
 location ~* \\.(sql|py|log|env|ini|sh)$ { deny all; }
 location ~* ^/uploads/media/.*\\.(php|phtml|phar)$ { deny all; }
 location /uploads/media/ { try_files \$uri =404; }
 location = /maintenance.html { try_files \$uri =404; }
 location = /admin { return 301 /admin/; }
 location /admin/ { try_files \$uri \$uri/ /admin/index.html; }
 location ^~ /api/ { rewrite ^/api/(.*)$ /backend/api/\$1 last; }
 location ~ \\.php$ { include snippets/fastcgi-php.conf; fastcgi_pass unix:$PHP_SOCK; fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name; include fastcgi_params; }
 location / { if (-f /var/lib/biomatrix/maintenance.flag) { rewrite ^ /maintenance.html last; } try_files \$uri \$uri/ /index.html; }
}
EOF
ln -sf /etc/nginx/sites-available/biomatrix.conf /etc/nginx/sites-enabled/biomatrix.conf
nginx -t
systemctl reload nginx
systemctl restart biomatrix-mqtt.service

echo "BioMatrix v12.1 patched deployment completed."
echo "Website: http://IP-SERVER:8080/ | Admin: http://IP-SERVER:8080/admin/"
echo "Akun upgrade V11: password yang sudah ada dipertahankan (tidak di-reset oleh deploy)."
echo "Pastikan MQTT broker aktif, firmware ESP32 memakai host/port/user/password yang sama, dan segera rotasi password DB demo."
