/* Integrasi live dashboard. API dan MQTT harus satu jaringan dengan browser. */
(() => {
  const cfg = window.SMARTPARKING_CONFIG || {
    apiBase: '/api', mqttUrl: `ws://${location.hostname}:9001`,
    mqttUser: 'smartparking-dashboard', mqttPassword: 'GANTI_PASSWORD_DASHBOARD'
  };
  const topicSlots = {
    'A1':'smartparking/sensor/slot/A1','A2':'smartparking/sensor/slot/A2',
    'B1':'smartparking/sensor/slot/B1','B2':'smartparking/sensor/slot/B2'
  };
  function applySlot(id, occupied) {
    if (typeof slots === 'undefined' || !Array.isArray(slots)) return;
    const s = slots.find(x => x.id === id);
    if (s) { s.occupied = !!occupied; if (!occupied) { s.cardNo=null; s.txId=null; s.entryTime=null; } }
    if (typeof window.renderAll === 'function') window.renderAll();
  }
  async function refreshState() {
    try {
      const r = await fetch(`${cfg.apiBase}/state.php`, {cache:'no-store'});
      if (!r.ok) throw new Error('API state error');
      const data = await r.json();
      if (!data.ok) return;
      data.slots.forEach(s => applySlot(s.nomor_slot, Number(s.ada_transaksi) === 1 || s.status_sensor === 'terisi'));
      const badge = document.getElementById('connection-status');
      if (badge) badge.textContent = data.device?.status_perangkat === 'online' ? 'ESP32 ONLINE' : 'ESP32 OFFLINE';
    } catch(e) { console.warn('Status backend belum tersedia:', e.message); }
  }
  function connectMqtt() {
    if (!window.mqtt) { console.warn('MQTT.js tidak termuat'); return; }
    const client = mqtt.connect(cfg.mqttUrl, {
      username: cfg.mqttUser, password: cfg.mqttPassword,
      reconnectPeriod: 3000, connectTimeout: 10000, clean: true
    });
    client.on('connect', () => {
      Object.values(topicSlots).forEach(t => client.subscribe(t));
      client.subscribe('smartparking/notification');
      console.info('SmartParking MQTT connected');
    });
    client.on('message', (topic, bytes) => {
      try {
        const d = JSON.parse(bytes.toString());
        const id = Object.keys(topicSlots).find(k => topicSlots[k] === topic);
        if (id && d.valid !== false) applySlot(id, !!d.occupied);
        if (topic === 'smartparking/notification' && typeof window.showToast === 'function')
          showToast(d.message || 'Pembaruan sistem parkir', d.type === 'error' ? 'error' : 'info');
      } catch(e) { console.warn('Pesan MQTT tidak valid'); }
    });
    client.on('error', e => console.warn('MQTT:', e.message));
  }
  // Simulasi tombol masuk dinonaktifkan agar tidak membuat transaksi palsu.
  window.simulateEntry = function() {
    if (typeof window.showToast === 'function') showToast('Gunakan kartu RFID pada reader untuk transaksi masuk.', 'info');
  };
  window.addEventListener('load', () => { refreshState(); setInterval(refreshState, 4000); connectMqtt(); });
})();
