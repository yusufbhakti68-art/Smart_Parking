<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
    require __DIR__ . '/../config/database.php';

    $device = $pdo->query("SELECT p.*, pp.mode_sistem, pp.interval_update FROM perangkat p LEFT JOIN pengaturan_perangkat pp ON pp.id_perangkat = p.id_perangkat WHERE p.id_perangkat = 1 LIMIT 1")->fetch();

    $sensors = $pdo->query("SELECT sp.id_sensor_perangkat, js.kode_sensor, js.nama_sensor, js.satuan, sp.status_sensor
                            FROM sensor_perangkat sp
                            JOIN jenis_sensor js ON js.id_jenis_sensor = sp.id_jenis_sensor
                            WHERE sp.id_perangkat = 1 ORDER BY sp.id_sensor_perangkat ASC")->fetchAll();

    $latestRows = $pdo->query("SELECT kode_sensor, nilai_sensor, status_sensor, waktu_pencatatan FROM v_sensor_terakhir WHERE id_perangkat = 1")->fetchAll();
    $latest = ['suhu' => null, 'kelembapan_udara' => null, 'kelembapan_tanah' => null, 'waktu_pencatatan' => null];
    foreach ($latestRows as $r) {
        if ($r['status_sensor'] !== 'Aktif') continue;
        if ($r['kode_sensor'] === 'TEMP') { $latest['suhu'] = $r['nilai_sensor']; $latest['waktu_pencatatan'] = $r['waktu_pencatatan']; }
        if ($r['kode_sensor'] === 'HUM')  { $latest['kelembapan_udara'] = $r['nilai_sensor']; }
        if ($r['kode_sensor'] === 'SOIL') { $latest['kelembapan_tanah'] = $r['nilai_sensor']; }
    }

    $actRows = $pdo->query("SELECT ap.id_aktuator, ja.kode_aktuator, ja.nama_aktuator, ap.status_aktuator, ap.mode_kontrol, ap.terakhir_diubah
                            FROM aktuator_perangkat ap JOIN jenis_aktuator ja ON ja.id_jenis_aktuator = ap.id_jenis_aktuator WHERE ap.id_perangkat = 1")->fetchAll();
    $actuators = [];
    foreach ($actRows as $a) { $actuators[$a['kode_aktuator']] = $a; }

    $histRows = $pdo->query("
        SELECT DATE_FORMAT(ps.waktu_pencatatan, '%d-%m-%Y %H:%i:%s') AS waktu_format,
               DATE_FORMAT(ps.waktu_pencatatan, '%H:%i:%s') AS jam_format,
               MAX(CASE WHEN js.kode_sensor = 'TEMP' THEN ps.nilai_sensor END) AS suhu,
               MAX(CASE WHEN js.kode_sensor = 'HUM'  THEN ps.nilai_sensor END) AS kelembapan_udara,
               MAX(CASE WHEN js.kode_sensor = 'SOIL' THEN ps.nilai_sensor END) AS kelembapan_tanah
        FROM pembacaan_sensor ps
        JOIN sensor_perangkat sp ON sp.id_sensor_perangkat = ps.id_sensor_perangkat
        JOIN jenis_sensor js ON js.id_jenis_sensor = sp.id_jenis_sensor
        WHERE sp.id_perangkat = 1
        GROUP BY ps.waktu_pencatatan ORDER BY ps.waktu_pencatatan DESC LIMIT 25
    ")->fetchAll();

    $menus = $pdo->query("SELECT kode_menu, nama_menu, tampil FROM pengaturan_menu_pengelola ORDER BY urutan ASC")->fetchAll();

    echo json_encode([
        'ok' => true,
        'device' => $device,
        'sensors' => $sensors,
        'actuators' => $actuators,
        'latest' => $latest,
        'history' => $histRows,
        'menus' => $menus,
        'server_time' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
