<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

try {
    require __DIR__ . '/../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $username = trim((string)($input['username'] ?? ''));
        $nama = trim((string)($input['nama_lengkap'] ?? 'Pengelola Baru'));
        $password = (string)($input['password'] ?? '');
        $role = in_array($input['role'] ?? '', ['editor', 'read', 'admin']) ? $input['role'] : 'editor';

        if ($username === '' || strlen($password) < 4) {
            http_response_code(400);
            echo json_encode(['ok' => false, 'error' => 'Username wajib diisi dan password minimal 4 karakter']);
            exit;
        }
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $pdo->prepare("INSERT INTO users (username, nama_lengkap, password_hash, role) VALUES (?, ?, ?, ?)")->execute([$username, $nama, $hash, $role]);
        echo json_encode(['ok' => true, 'message' => "Akun pengelola '{$username}' berhasil ditambahkan"]);
        exit;
    }

    $users = $pdo->query("SELECT id_user, username, nama_lengkap, role, last_login, created_at FROM users ORDER BY id_user ASC")->fetchAll();
    $loginHistory = $pdo->query("SELECT id_login, username, ip_address, device_info, DATE_FORMAT(waktu_login, '%d-%m-%Y %H:%i:%s') AS waktu_format FROM riwayat_login ORDER BY id_login DESC LIMIT 30")->fetchAll();
    echo json_encode(['ok' => true, 'users' => $users, 'login_history' => $loginHistory]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
