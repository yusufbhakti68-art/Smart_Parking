<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
    require __DIR__ . '/../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $action = trim((string)($input['action'] ?? 'update_section'));
        $idUser = isset($input['id_user']) ? (int)$input['id_user'] : 1;

        if ($action === 'update_section') {
            $kunci = trim((string)($input['kunci_bagian'] ?? ''));
            $judul = trim((string)($input['judul'] ?? ''));
            $subjudul = trim((string)($input['subjudul'] ?? ''));
            $deskripsi = trim((string)($input['deskripsi'] ?? ''));
            $urlGambar = trim((string)($input['url_gambar'] ?? ''));
            $bgSize = in_array($input['bg_size'] ?? '', ['cover', 'contain', 'auto']) ? $input['bg_size'] : 'cover';
            $bgBlur = max(0, min(20, (int)($input['bg_blur'] ?? 0)));
            $bgDark = max(0, min(90, (int)($input['bg_darkness'] ?? 55)));
            $tampil = !empty($input['tampil']) ? 1 : 0;

            $stmt = $pdo->prepare("UPDATE konten_website SET judul=?, subjudul=?, deskripsi=?, url_gambar=?, bg_size=?, bg_blur=?, bg_darkness=?, tampil=?, updated_by=? WHERE kunci_bagian=?");
            $stmt->execute([$judul, $subjudul, $deskripsi, $urlGambar, $bgSize, $bgBlur, $bgDark, $tampil, $idUser, $kunci]);
            echo json_encode(['ok' => true, 'message' => "Bagian '{$kunci}' berhasil diperbarui!"]);
            exit;
        }

        if ($action === 'add_section') {
            $judul = trim((string)($input['judul'] ?? ''));
            $subjudul = trim((string)($input['subjudul'] ?? 'HALAMAN BARU'));
            $deskripsi = trim((string)($input['deskripsi'] ?? ''));
            $urlGambar = trim((string)($input['url_gambar'] ?? ''));
            $bgSize = in_array($input['bg_size'] ?? '', ['cover', 'contain', 'auto']) ? $input['bg_size'] : 'cover';
            $bgBlur = max(0, min(20, (int)($input['bg_blur'] ?? 0)));
            $bgDark = max(0, min(90, (int)($input['bg_darkness'] ?? 50)));
            if ($judul === '') {
                http_response_code(400);
                echo json_encode(['ok' => false, 'error' => 'Judul halaman baru wajib diisi']);
                exit;
            }
            $kunci = 'custom_' . time();
            $stmt = $pdo->prepare("INSERT INTO konten_website (kunci_bagian, judul, subjudul, deskripsi, url_gambar, bg_size, bg_blur, bg_darkness, tampil, is_custom, urutan, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, 1, 50, ?)");
            $stmt->execute([$kunci, $judul, $subjudul, $deskripsi, $urlGambar, $bgSize, $bgBlur, $bgDark, $idUser]);
            echo json_encode(['ok' => true, 'message' => "Halaman baru '{$judul}' berhasil ditambahkan!"]);
            exit;
        }

        if ($action === 'delete_section') {
            $kunci = trim((string)($input['kunci_bagian'] ?? ''));
            $pdo->prepare("DELETE FROM konten_website WHERE kunci_bagian = ? AND is_custom = 1")->execute([$kunci]);
            echo json_encode(['ok' => true, 'message' => 'Halaman kustom berhasil dihapus']);
            exit;
        }

        if ($action === 'toggle_menu') {
            $kode = trim((string)($input['kode_menu'] ?? ''));
            $tampil = !empty($input['tampil']) ? 1 : 0;
            $pdo->prepare("UPDATE pengaturan_menu_pengelola SET tampil = ? WHERE kode_menu = ?")->execute([$tampil, $kode]);
            echo json_encode(['ok' => true, 'message' => "Visibilitas menu '{$kode}' diperbarui"]);
            exit;
        }

        if ($action === 'toggle_sensor') {
            $idSensor = (int)($input['id_sensor_perangkat'] ?? 0);
            $status = ($input['status_sensor'] ?? '') === 'Aktif' ? 'Aktif' : 'Nonaktif';
            $pdo->prepare("UPDATE sensor_perangkat SET status_sensor = ? WHERE id_sensor_perangkat = ?")->execute([$status, $idSensor]);
            echo json_encode(['ok' => true, 'message' => "Status sensor diperbarui menjadi {$status}"]);
            exit;
        }
    }

    $kontenRows = $pdo->query("SELECT * FROM konten_website ORDER BY urutan ASC, id_konten ASC")->fetchAll();
    $kontenMap = [];
    foreach ($kontenRows as $k) { $kontenMap[$k['kunci_bagian']] = $k; }
    $paketRows = $pdo->query("SELECT * FROM paket_komponen ORDER BY urutan ASC")->fetchAll();
    $menus = $pdo->query("SELECT * FROM pengaturan_menu_pengelola ORDER BY urutan ASC")->fetchAll();
    $sensors = $pdo->query("SELECT sp.id_sensor_perangkat, js.kode_sensor, js.nama_sensor, sp.status_sensor FROM sensor_perangkat sp JOIN jenis_sensor js ON js.id_jenis_sensor = sp.id_jenis_sensor WHERE sp.id_perangkat = 1")->fetchAll();

    echo json_encode([
        'ok' => true,
        'konten' => $kontenMap,
        'konten_list' => $kontenRows,
        'paket' => $paketRows,
        'menus' => $menus,
        'sensors' => $sensors
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
