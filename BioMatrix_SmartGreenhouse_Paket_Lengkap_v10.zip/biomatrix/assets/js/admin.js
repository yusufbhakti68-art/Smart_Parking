// BIOMATRIX ADMIN FULL CONTROL ENGINE (v7)
function showToast(msg, type = 'success') {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    el.className = `px-4 py-3 rounded-lg border text-xs font-semibold ${type === 'error' ? 'bg-[#FDECEC] border-[#F8B4B4] text-[#B91C1C]' : 'bg-[#17332A] border-[#234E3F] text-white'}`;
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(() => el.remove(), 3200);
}

async function handleAdminLogin(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    try {
        const res = await fetch('/api/login.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }) });
        const d = await res.json();
        if (res.ok && d.ok) { sessionStorage.setItem('bm_admin_ok', 'true'); sessionStorage.setItem('bm_admin_name', d.user.nama_lengkap || username); openAdmin(); return; }
    } catch (err) {}
    if (username === 'admin' && (password === 'admin' || password === 'biomatrix123')) {
        sessionStorage.setItem('bm_admin_ok', 'true'); sessionStorage.setItem('bm_admin_name', 'Admin'); openAdmin();
    } else { showToast('Username atau kata sandi salah!', 'error'); }
}

function openAdmin() {
    document.getElementById('adminLoginScreen').classList.add('hidden');
    document.getElementById('adminApp').classList.remove('hidden');
    document.getElementById('topbar-username').textContent = sessionStorage.getItem('bm_admin_name') || 'Admin';
    loadAllCms();
    loadUsersAndHistory();
}

function logoutAdmin() { sessionStorage.removeItem('bm_admin_ok'); location.reload(); }
function switchTab(tab) {
    document.querySelectorAll('.page-content').forEach(el => el.classList.add('hidden'));
    document.getElementById(`page-${tab}`)?.classList.remove('hidden');
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('is-active'));
    document.querySelector(`.nav-btn[data-tab="${tab}"]`)?.classList.add('is-active');
}

async function loadAllCms() {
    try {
        const res = await fetch('/api/cms.php', { cache: 'no-store' });
        const d = await res.json();
        if (!d.ok) return;

        // 1. Render Editor Halaman & Background
        const cmsList = document.getElementById('cms-editor-list');
        if (cmsList && Array.isArray(d.konten_list)) {
            cmsList.innerHTML = d.konten_list.map(k => `
                <div class="bm-card p-5 space-y-3">
                    <div class="flex items-center justify-between border-b border-[#E5EFEA] pb-2">
                        <span class="font-bold text-sm text-[#17332A] uppercase">Bagian: ${k.kunci_bagian}</span>
                        <div class="flex items-center gap-3">
                            <label class="flex items-center gap-1.5 text-xs font-semibold text-[#4B5563] cursor-pointer">
                                <input type="checkbox" id="cms-tampil-${k.kunci_bagian}" ${Number(k.tampil) === 1 ? 'checked' : ''}> Tampilkan
                            </label>
                            ${Number(k.is_custom) === 1 ? `<button onclick="deleteCustomPage('${k.kunci_bagian}')" class="text-xs text-[#B91C1C] font-bold">Hapus</button>` : ''}
                        </div>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div><label class="block text-[11px] font-semibold text-[#6B7280] mb-1">Judul</label><input type="text" id="cms-judul-${k.kunci_bagian}" value="${(k.judul || '').replace(/"/g, '&quot;')}" class="w-full px-3 py-2 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
                        <div><label class="block text-[11px] font-semibold text-[#6B7280] mb-1">Subjudul / Credit</label><input type="text" id="cms-sub-${k.kunci_bagian}" value="${(k.subjudul || '').replace(/"/g, '&quot;')}" class="w-full px-3 py-2 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
                    </div>
                    <div><label class="block text-[11px] font-semibold text-[#6B7280] mb-1">Deskripsi</label><textarea rows="2" id="cms-desc-${k.kunci_bagian}" class="w-full px-3 py-2 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs">${k.deskripsi || ''}</textarea></div>
                    <div><label class="block text-[11px] font-semibold text-[#6B7280] mb-1">URL Gambar Background</label><input type="text" id="cms-img-${k.kunci_bagian}" value="${(k.url_gambar || '').replace(/"/g, '&quot;')}" class="w-full px-3 py-2 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
                    <div class="grid grid-cols-3 gap-2 pt-1">
                        <div>
                            <label class="block text-[10px] font-semibold text-[#6B7280] mb-1">Ukuran BG</label>
                            <select id="cms-size-${k.kunci_bagian}" class="w-full px-2 py-1.5 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                                <option value="cover" ${k.bg_size==='cover'?'selected':''}>Cover</option>
                                <option value="contain" ${k.bg_size==='contain'?'selected':''}>Contain</option>
                                <option value="auto" ${k.bg_size==='auto'?'selected':''}>Auto</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-[10px] font-semibold text-[#6B7280] mb-1">Blur (0-20px)</label>
                            <input type="number" min="0" max="20" id="cms-blur-${k.kunci_bagian}" value="${k.bg_blur ?? 0}" class="w-full px-2 py-1.5 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                        </div>
                        <div>
                            <label class="block text-[10px] font-semibold text-[#6B7280] mb-1">Gelap (0-90%)</label>
                            <input type="number" min="0" max="90" id="cms-dark-${k.kunci_bagian}" value="${k.bg_darkness ?? 55}" class="w-full px-2 py-1.5 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                        </div>
                    </div>
                    <button onclick="saveCmsSection('${k.kunci_bagian}')" class="px-4 py-2 rounded-lg bg-[#17332A] hover:bg-[#234E3F] text-white text-xs font-bold">Simpan Perubahan</button>
                </div>
            `).join('');
        }

        // 2. Render Toggle Sensor
        const sList = document.getElementById('sensor-toggle-list');
        if (sList && Array.isArray(d.sensors)) {
            sList.innerHTML = d.sensors.map(s => `
                <div class="p-3.5 rounded-xl bg-[#F3F7F5] border border-[#D6E2DC] flex items-center justify-between">
                    <div>
                        <div class="font-bold text-sm text-[#111827]">${s.nama_sensor}</div>
                        <div class="text-xs text-[#6B7280]">Kode: ${s.kode_sensor} • Status: <strong>${s.status_sensor}</strong></div>
                    </div>
                    <label class="bm-switch">
                        <input type="checkbox" ${s.status_sensor === 'Aktif' ? 'checked' : ''} onchange="toggleSensor(${s.id_sensor_perangkat}, this.checked)">
                        <span class="bm-slider"></span>
                    </label>
                </div>
            `).join('');
        }

        // 3. Render Toggle Menu Pengelola
        const mList = document.getElementById('menu-toggle-list');
        if (mList && Array.isArray(d.menus)) {
            mList.innerHTML = d.menus.map(m => `
                <div class="p-3 rounded-xl bg-[#F3F7F5] border border-[#D6E2DC] flex items-center justify-between">
                    <span class="text-sm font-semibold text-[#111827]">${m.nama_menu}</span>
                    <label class="bm-switch">
                        <input type="checkbox" ${Number(m.tampil) === 1 ? 'checked' : ''} onchange="toggleMenu('${m.kode_menu}', this.checked)">
                        <span class="bm-slider"></span>
                    </label>
                </div>
            `).join('');
        }
    } catch (e) {}
}

async function saveCmsSection(kunci) {
    const payload = {
        action: 'update_section', kunci_bagian: kunci,
        judul: document.getElementById(`cms-judul-${kunci}`).value,
        subjudul: document.getElementById(`cms-sub-${kunci}`).value,
        deskripsi: document.getElementById(`cms-desc-${kunci}`).value,
        url_gambar: document.getElementById(`cms-img-${kunci}`).value,
        bg_size: document.getElementById(`cms-size-${kunci}`).value,
        bg_blur: parseInt(document.getElementById(`cms-blur-${kunci}`).value || 0),
        bg_darkness: parseInt(document.getElementById(`cms-dark-${kunci}`).value || 55),
        tampil: document.getElementById(`cms-tampil-${kunci}`).checked ? 1 : 0
    };
    const res = await fetch('/api/cms.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const d = await res.json();
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal menyimpan', 'error');
}

async function addCustomPage(e) {
    e.preventDefault();
    const payload = {
        action: 'add_section',
        judul: document.getElementById('new-pg-judul').value,
        subjudul: document.getElementById('new-pg-sub').value,
        url_gambar: document.getElementById('new-pg-img').value,
        bg_size: document.getElementById('new-pg-size').value,
        deskripsi: document.getElementById('new-pg-desc').value
    };
    const res = await fetch('/api/cms.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const d = await res.json();
    if (d.ok) { showToast(d.message); e.target.reset(); document.getElementById('modal-add-page').classList.add('hidden'); loadAllCms(); }
}

async function deleteCustomPage(kunci) {
    if (!confirm('Hapus halaman kustom ini?')) return;
    const res = await fetch('/api/cms.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'delete_section', kunci_bagian: kunci }) });
    const d = await res.json();
    if (d.ok) { showToast(d.message); loadAllCms(); }
}

async function toggleSensor(id, active) {
    const res = await fetch('/api/cms.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'toggle_sensor', id_sensor_perangkat: id, status_sensor: active ? 'Aktif' : 'Nonaktif' }) });
    const d = await res.json();
    if (d.ok) { showToast(d.message); loadAllCms(); }
}

async function toggleMenu(kode, tampil) {
    const res = await fetch('/api/cms.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'toggle_menu', kode_menu: kode, tampil: tampil ? 1 : 0 }) });
    const d = await res.json();
    if (d.ok) showToast(d.message);
}

async function loadUsersAndHistory() {
    try {
        const res = await fetch('/api/users.php', { cache: 'no-store' });
        const d = await res.json();
        if (!d.ok) return;
        const ub = document.getElementById('users-table-body');
        if (ub && Array.isArray(d.users)) {
            ub.innerHTML = d.users.map(u => {
                const roleLabel = u.role === 'read' ? '<span class="px-2 py-0.5 rounded bg-[#E5E7EB] text-[#4B5563] text-[10px] font-bold">Lihat Saja (Read)</span>' : (u.role === 'admin' ? '<span class="px-2 py-0.5 rounded bg-[#17332A] text-white text-[10px] font-bold">Admin</span>' : '<span class="px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A] text-[10px] font-bold">Editor</span>');
                return `<tr><td class="p-3 font-bold text-[#17332A]">${u.username}</td><td class="p-3">${u.nama_lengkap}</td><td class="p-3">${roleLabel}</td><td class="p-3 font-mono text-[#6B7280]">${u.last_login || 'Belum pernah'}</td></tr>`;
            }).join('');
        }
        const lb = document.getElementById('login-history-body');
        if (lb && Array.isArray(d.login_history)) {
            lb.innerHTML = d.login_history.map((r, i) => `
                <tr>
                    <td class="p-3">${i+1}</td>
                    <td class="p-3 font-bold text-[#17332A]">${r.username}</td>
                    <td class="p-3 font-mono text-[#6B7280]">${r.waktu_format}</td>
                    <td class="p-3 font-mono">${r.ip_address || '-'}</td>
                    <td class="p-3 font-semibold text-[#111827]">${r.device_info || '-'}</td>
                </tr>
            `).join('');
        }
    } catch (e) {}
}

async function addPengelolaAccount(e) {
    e.preventDefault();
    const res = await fetch('/api/users.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ nama_lengkap: document.getElementById('new-user-nama').value, username: document.getElementById('new-user-username').value, password: document.getElementById('new-user-pass').value, role: document.getElementById('new-user-role').value }) });
    const d = await res.json();
    if (d.ok) { showToast(d.message); e.target.reset(); loadUsersAndHistory(); } else showToast(d.error || 'Gagal', 'error');
}

document.addEventListener('DOMContentLoaded', () => {
    setInterval(() => { const el = document.getElementById('current-datetime'); if (el) el.textContent = new Date().toLocaleString('id-ID') + ' WIB'; }, 1000);
    if (sessionStorage.getItem('bm_admin_ok') === 'true') openAdmin();
});
