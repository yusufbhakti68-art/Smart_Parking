/* Integrasi live SmartParking IoT (PHP API + MQTT WebSocket).
   Otomatis fallback ke mode simulasi jika dibuka tanpa backend lokal. */
(() => {
  const cfg = window.SMARTPARKING_CONFIG || {
    apiBase: '/api',
    mqttUrl: `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.hostname}:9001`,
    mqttUser: 'smartparking-dashboard',
    mqttPassword: 'GANTI_PASSWORD_DASHBOARD'
  };
  const topicSlots = {
    'A1': 'smartparking/sensor/slot/A1',
    'A2': 'smartparking/sensor/slot/A2',
    'B1': 'smartparking/sensor/slot/B1',
    'B2': 'smartparking/sensor/slot/B2'
  };

  function applySlot(id, occupied, fromSensor = false) {
    if (!Array.isArray(window.slots)) return;
    const s = window.slots.find(x => x.id === id);
    if (!s) return;
    let changed = false;

    if (occupied) {
      if (!s.occupied) {
        s.occupied = true;
        s.method = s.method || 'SENSOR';
        s.plate = s.plate || 'TERDETEKSI';
        s.startTime = s.startTime || Date.now();
        changed = true;
      }
      if (fromSensor && !s.sensorVerified) {
        s.sensorVerified = true;
        changed = true;
      }
    } else if (s.occupied && s.method === 'SENSOR') {
      s.occupied = false;
      s.plate = null; s.ticketId = null; s.method = null; s.userId = null; s.startTime = null;
      s.sensorVerified = false; s.penaltyApplied = false; s.penaltyAmount = 0; s.adminChecked = false;
      changed = true;
    }

    if (changed && typeof window.renderAll === 'function') {
      if (typeof window.saveData === 'function') window.saveData();
      window.renderAll();
    }
  }

  async function refreshState() {
    try {
      const r = await fetch(`${cfg.apiBase}/state.php`, { cache: 'no-store' });
      if (!r.ok) return;
      const data = await r.json();
      if (!data.ok || !Array.isArray(data.slots)) return;
      data.slots.forEach(s => {
        const sensorOcc = s.status_sensor === 'terisi';
        const txOcc = Number(s.ada_transaksi) === 1;
        applySlot(s.nomor_slot, txOcc || sensorOcc, sensorOcc);
      });
      const badge = document.getElementById('connection-status');
      if (badge) {
        const online = data.device?.status_perangkat === 'online';
        badge.innerHTML = `<span class="w-2 h-2 rounded-full ${online ? 'bg-green-500' : 'bg-amber-500'}"></span> ${online ? 'ESP32 ONLINE' : 'SERVER TERHUBUNG'}`;
      }
    } catch (_) {}
  }

  function connectMqtt() {
    if (!window.mqtt || location.hostname.endsWith('web.app') || location.hostname.endsWith('firebaseapp.com')) return;
    try {
      const client = mqtt.connect(cfg.mqttUrl, {
        username: cfg.mqttUser,
        password: cfg.mqttPassword,
        reconnectPeriod: 5000,
        connectTimeout: 5000,
        clean: true
      });
      client.on('connect', () => {
        Object.values(topicSlots).forEach(t => client.subscribe(t));
        client.subscribe('smartparking/notification');
      });
      client.on('message', (topic, bytes) => {
        try {
          const d = JSON.parse(bytes.toString());
          const id = Object.keys(topicSlots).find(k => topicSlots[k] === topic);
          if (id && d.valid !== false) applySlot(id, !!d.occupied, true);
          if (topic === 'smartparking/notification' && typeof window.showToast === 'function') {
            window.showToast(d.message || 'Pembaruan sistem parkir');
          }
        } catch (_) {}
      });
    } catch (_) {}
  }

  window.addEventListener('load', () => {
    refreshState();
    setInterval(refreshState, 5000);
    connectMqtt();
  });
})();
