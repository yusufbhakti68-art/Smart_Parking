<?php
declare(strict_types=1);
require __DIR__ . '/../backend/config/database.php';

$defaults = [
    'admin'     => ['pass' => 'admin',     'role' => 'admin',  'nama' => 'Yusuf Bhakti (Admin)'],
    'pengelola' => ['pass' => 'pengelola', 'role' => 'editor', 'nama' => 'Yusuf Pengelola (Editor)'],
    'viewer'    => ['pass' => 'viewer',    'role' => 'read',   'nama' => 'Pengamat Greenhouse (Lihat Saja)'],
];

foreach ($defaults as $username => $info) {
    $hash = password_hash($info['pass'], PASSWORD_BCRYPT);
    $stmt = $pdo->prepare("SELECT id_user FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    if ($stmt->fetch()) {
        $pdo->prepare("UPDATE users SET password_hash = ?, role = ?, status_akun = 'aktif' WHERE username = ?")
            ->execute([$hash, $info['role'], $username]);
    } else {
        $pdo->prepare("INSERT INTO users (username, nama_lengkap, password_hash, role, status_akun) VALUES (?, ?, ?, ?, 'aktif')")
            ->execute([$username, $info['nama'], $hash, $info['role']]);
    }
}
echo "[SEED] Password bcrypt akun default (admin, pengelola, viewer) berhasil disinkronkan.\n";
