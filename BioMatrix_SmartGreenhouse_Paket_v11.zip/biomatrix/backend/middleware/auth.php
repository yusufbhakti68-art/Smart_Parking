<?php
declare(strict_types=1);

function bm_start_session(): void {
    if (session_status() === PHP_SESSION_NONE) {
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        session_set_cookie_params([
            'lifetime' => 86400,
            'path'     => '/',
            'secure'   => $isHttps,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

function bm_current_user(): ?array {
    bm_start_session();
    return $_SESSION['bm_user'] ?? null;
}

function bm_require_auth(): array {
    $user = bm_current_user();
    if (!$user) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Sesi tidak valid atau belum login.']);
        exit;
    }
    return $user;
}
