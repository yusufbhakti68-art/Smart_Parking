<?php
declare(strict_types=1);

class MqttService {
    public static function publish(string $topic, string $payload): bool {
        $cfg = require __DIR__ . '/../config/config.php';
        $host = escapeshellarg($cfg['mqtt_host']);
        $port = (int)$cfg['mqtt_port'];
        $t = escapeshellarg($topic);
        $m = escapeshellarg($payload);
        $cmd = "mosquitto_pub -h {$host} -p {$port} -t {$t} -m {$m} 2>&1";
        @exec($cmd, $out, $code);
        return $code === 0;
    }
}
