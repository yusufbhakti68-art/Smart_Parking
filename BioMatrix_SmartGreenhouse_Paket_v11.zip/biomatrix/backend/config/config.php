<?php
declare(strict_types=1);
return [
    'db_host'   => getenv('BM_DB_HOST') ?: '127.0.0.1',
    'db_name'   => getenv('BM_DB_NAME') ?: 'biomatrix',
    'db_user'   => getenv('BM_DB_USER') ?: 'biomatrix',
    'db_pass'   => getenv('BM_DB_PASS') ?: 'biomatrix123',
    'mqtt_host' => getenv('BM_MQTT_HOST') ?: '127.0.0.1',
    'mqtt_port' => (int)(getenv('BM_MQTT_PORT') ?: 1883),
];
