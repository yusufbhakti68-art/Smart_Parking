import time
from datetime import datetime

active_runs = {}

def check_schedules(conn, client):
    now = datetime.now()
    now_ts = time.time()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT ja.*, jakt.kode_aktuator
                FROM jadwal_aktuator ja
                JOIN aktuator_perangkat ap ON ap.id_aktuator = ja.id_aktuator
                JOIN jenis_aktuator jakt ON jakt.id_jenis_aktuator = ap.id_jenis_aktuator
                WHERE ja.aktif = 1 AND ja.tanggal_mulai <= CURDATE()
                  AND (ja.tanggal_selesai IS NULL OR ja.tanggal_selesai >= CURDATE())
            """)
            schedules = cur.fetchall()

        # Matikan jadwal yang durasinya sudah habis
        for jid, info in list(active_runs.items()):
            if now_ts >= info["end_ts"]:
                topic = "biomatrix/kipas/control" if info["kode"] == "kipas" else "biomatrix/pompa/control"
                client.publish(topic, "OFF")
                with conn.cursor() as cur:
                    cur.execute("UPDATE eksekusi_jadwal SET selesai_aktual=NOW(), status_eksekusi='Selesai' WHERE id_eksekusi=%s", (info["exec_id"],))
                del active_runs[jid]
                print(f"[SCHEDULER] Jadwal #{jid} selesai -> {topic}=OFF", flush=True)

        # Cek apakah ada jadwal yang waktunya mulai pada menit ini
        cur_hm = now.strftime("%H:%M")
        for s in schedules:
            jid = s["id_jadwal"]
            if jid in active_runs:
                continue
            start_str = str(s["waktu_mulai"])[:5]
            if len(start_str) == 4:
                start_str = "0" + start_str
            if start_str == cur_hm and now.second < 10:
                topic = "biomatrix/kipas/control" if s["kode_aktuator"] == "kipas" else "biomatrix/pompa/control"
                client.publish(topic, "ON")
                dur_sec = max(60, int(s["durasi_menit"]) * 60)
                with conn.cursor() as cur:
                    cur.execute("INSERT INTO eksekusi_jadwal (id_jadwal, waktu_jadwal, mulai_aktual, status_eksekusi) VALUES (%s, NOW(), NOW(), 'Berjalan')", (jid,))
                    exec_id = cur.lastrowid
                active_runs[jid] = {"end_ts": now_ts + dur_sec, "kode": s["kode_aktuator"], "exec_id": exec_id}
                print(f"[SCHEDULER] Jadwal '{s['nama_jadwal']}' berjalan {s['durasi_menit']} menit -> {topic}=ON", flush=True)
    except Exception as e:
        print(f"[SCHEDULER ERROR] {e}", flush=True)
