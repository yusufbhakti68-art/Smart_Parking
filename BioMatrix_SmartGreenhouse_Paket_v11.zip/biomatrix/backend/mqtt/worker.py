#!/usr/bin/env python3
import os, json, time, threading
import pymysql
import paho.mqtt.client as mqtt
from automation import evaluate_rules
from scheduler import check_schedules

DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_NAME = os.getenv("DB_NAME", "biomatrix")
DB_USER = os.getenv("DB_USER", "biomatrix")
DB_PASS = os.getenv("DB_PASS", "biomatrix123")
MQTT_HOST = os.getenv("MQTT_HOST", "127.0.0.1")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))

state = {"suhu": None, "kelembapan_udara": None, "kelembapan_tanah": None, "kipas": "OFF", "pompa": "OFF", "last_db_insert": 0}

def get_db():
    return pymysql.connect(host=DB_HOST, port=DB_PORT, user=DB_USER, password=DB_PASS, database=DB_NAME, charset="utf8mb4", cursorclass=pymysql.cursors.DictCursor, autocommit=True)

def save_readings(client):
    now = time.time()
    if now - state["last_db_insert"] < 5:
        return
    state["last_db_insert"] = now
    try:
        conn = get_db()
        ts = time.strftime('%Y-%m-%d %H:%M:%S')
        with conn.cursor() as cur:
            cur.execute("UPDATE perangkat SET status_koneksi='online', last_seen=%s WHERE id_perangkat=1", (ts,))
            if state["kelembapan_tanah"] is not None:
                cur.execute("INSERT INTO pembacaan_sensor (id_sensor_perangkat, nilai_sensor, waktu_pencatatan) VALUES (1, %s, %s)", (state["kelembapan_tanah"], ts))
            if state["suhu"] is not None:
                cur.execute("INSERT INTO pembacaan_sensor (id_sensor_perangkat, nilai_sensor, waktu_pencatatan) VALUES (2, %s, %s)", (state["suhu"], ts))
            if state["kelembapan_udara"] is not None:
                cur.execute("INSERT INTO pembacaan_sensor (id_sensor_perangkat, nilai_sensor, waktu_pencatatan) VALUES (3, %s, %s)", (state["kelembapan_udara"], ts))
        evaluate_rules(conn, client, state)
        conn.close()
    except Exception as e:
        print(f"[DB ERROR] {e}", flush=True)

def confirm_actuator_db(kode, new_status):
    id_akt = 1 if kode == "kipas" else 2
    prev = state[kode]
    try:
        conn = get_db()
        with conn.cursor() as cur:
            cur.execute("UPDATE aktuator_perangkat SET status_aktuator=%s, status_konfirmasi='dikonfirmasi', terakhir_diubah=NOW() WHERE id_aktuator=%s", (new_status, id_akt))
            cur.execute("UPDATE perintah_perangkat SET status_perintah='dikonfirmasi', dikonfirmasi_pada=NOW() WHERE id_aktuator=%s AND status_perintah='terkirim'", (id_akt,))
            if prev != new_status:
                cur.execute("INSERT INTO riwayat_aktuator (id_aktuator, status_sebelumnya, status_baru, sumber_perintah) VALUES (%s, %s, %s, 'Otomatis')", (id_akt, prev, new_status))
        conn.close()
    except Exception as e:
        print(f"[DB ACTUATOR ERROR] {e}", flush=True)

def background_scheduler_loop(client):
    while True:
        try:
            conn = get_db()
            check_schedules(conn, client)
            # Tandai perangkat offline jika tidak ada heartbeat > 45 detik
            with conn.cursor() as cur:
                cur.execute("UPDATE perangkat SET status_koneksi='offline' WHERE last_seen < DATE_SUB(NOW(), INTERVAL 45 SECOND) AND status_koneksi='online'")
            conn.close()
        except Exception as e:
            print(f"[BG LOOP ERROR] {e}", flush=True)
        time.sleep(5)

def on_connect(client, userdata, flags, rc):
    print(f"[MQTT WORKER v11] Terhubung ke broker: {rc}", flush=True)
    client.subscribe("biomatrix/sensor/tanah")
    client.subscribe("biomatrix/sensor/dht11")
    client.subscribe("biomatrix/kipas")
    client.subscribe("biomatrix/pompa")

def on_message(client, userdata, msg):
    topic = msg.topic
    payload = msg.payload.decode("utf-8", errors="ignore").strip()
    try:
        if topic == "biomatrix/sensor/tanah":
            state["kelembapan_tanah"] = float(payload)
            save_readings(client)
        elif topic == "biomatrix/sensor/dht11":
            d = json.loads(payload)
            state["suhu"] = float(d.get("suhu"))
            state["kelembapan_udara"] = float(d.get("kelembapan"))
            save_readings(client)
        elif topic == "biomatrix/kipas":
            st = "ON" if payload.upper() == "ON" else "OFF"
            confirm_actuator_db("kipas", st)
            state["kipas"] = st
        elif topic == "biomatrix/pompa":
            st = "ON" if payload.upper() == "ON" else "OFF"
            confirm_actuator_db("pompa", st)
            state["pompa"] = st
    except Exception as e:
        print(f"[PARSE ERROR] {topic}: {e}", flush=True)

def main():
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    t = threading.Thread(target=background_scheduler_loop, args=(client,), daemon=True)
    t.start()
    while True:
        try:
            client.connect(MQTT_HOST, MQTT_PORT, 60)
            client.loop_forever()
        except Exception as e:
            print(f"[MQTT RETRY] {e}", flush=True)
            time.sleep(3)

if __name__ == "__main__":
    main()
