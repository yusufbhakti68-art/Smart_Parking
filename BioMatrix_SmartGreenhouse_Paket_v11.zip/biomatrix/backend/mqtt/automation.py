import time

last_rule_fire = {}

def evaluate_rules(conn, client, state):
    now = time.time()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT ao.*, js.kode_sensor, ja.kode_aktuator, ap.status_aktuator, ap.mode_kontrol
                FROM aturan_otomatis ao
                JOIN sensor_perangkat sp ON sp.id_sensor_perangkat = ao.id_sensor_perangkat
                JOIN jenis_sensor js ON js.id_jenis_sensor = sp.id_jenis_sensor
                JOIN aktuator_perangkat ap ON ap.id_aktuator = ao.id_aktuator
                JOIN jenis_aktuator ja ON ja.id_jenis_aktuator = ap.id_jenis_aktuator
                WHERE ao.aktif = 1 AND sp.status_sensor = 'Aktif'
                ORDER BY ao.prioritas ASC
            """)
            rules = cur.fetchall()

        for r in rules:
            if r["mode_kontrol"] == "Manual":
                continue
            code = r["kode_sensor"]
            val = state["kelembapan_tanah"] if code == "SOIL" else (state["suhu"] if code == "TEMP" else state["kelembapan_udara"])
            if val is None:
                continue

            op = r["operator_kondisi"]
            thr = float(r["nilai_ambang"])
            matched = (
                (op == ">" and val > thr) or
                (op == "<" and val < thr) or
                (op == ">=" and val >= thr) or
                (op == "<=" and val <= thr) or
                (op == "=" and val == thr)
            )
            if not matched:
                continue

            rid = r["id_aturan"]
            cd = int(r.get("cooldown_detik") or 30)
            if now - last_rule_fire.get(rid, 0) < cd:
                continue

            target = r["status_tujuan"]
            if r["status_aktuator"] != target:
                last_rule_fire[rid] = now
                topic = "biomatrix/kipas/control" if r["kode_aktuator"] == "kipas" else "biomatrix/pompa/control"
                client.publish(topic, target)
                print(f"[AUTOMATION] Rule '{r['nama_aturan']}' triggered ({val} {op} {thr}) -> {topic}={target}", flush=True)
    except Exception as e:
        print(f"[AUTOMATION ERROR] {e}", flush=True)
