<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        bm_require_roles(['admin', 'editor', 'read']);
        $rows = $pdo->query("SELECT sp.*, js.kode_sensor, js.nama_sensor, js.satuan, p.kode_perangkat, p.nama_perangkat
                             FROM sensor_perangkat sp
                             JOIN jenis_sensor js ON js.id_jenis_sensor=sp.id_jenis_sensor
                             JOIN perangkat p ON p.id_perangkat=sp.id_perangkat
                             ORDER BY sp.id_sensor_perangkat ASC")->fetchAll();
        echo json_encode(['ok' => true, 'sensors' => $rows]);
        exit;
    }

    bm_verify_csrf();
    $user = bm_require_roles(['admin', 'editor']);
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $id = (int)($in['id_sensor_perangkat'] ?? 0);
    $status = ($in['status_sensor'] ?? 'Aktif') === 'Aktif' ? 'Aktif' : 'Nonaktif';
    $min = (float)($in['nilai_min'] ?? 0);
    $max = (float)($in['nilai_max'] ?? 100);
    $off = (float)($in['offset_kalibrasi'] ?? 0);

    $pdo->prepare("UPDATE sensor_perangkat SET status_sensor=?, nilai_min=?, nilai_max=?, offset_kalibrasi=? WHERE id_sensor_perangkat=?")
        ->execute([$status, $min, $max, $off, $id]);
    $pdo->prepare("INSERT INTO status_sensor_kalibrasi (id_sensor_perangkat, nilai_min, nilai_max, offset_kalibrasi, catatan, diubah_oleh) VALUES (?, ?, ?, ?, 'Update dari Panel', ?)")
        ->execute([$id, $min, $max, $off, $user['id_user']]);
    bm_log_activity($pdo, $user['id_user'], 'UPDATE_SENSOR', "Update sensor #{$id} ({$status}, offset {$off})");
    echo json_encode(['ok' => true, 'message' => 'Sensor dan kalibrasi berhasil diperbarui']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
