<?php
declare(strict_types=1);
require_once __DIR__ . '/../middleware/permission.php';
bm_require_roles(['admin', 'editor']);
require __DIR__ . '/../config/database.php';

$type = $_GET['type'] ?? 'sensor';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="biomatrix_laporan_' . $type . '_' . date('Ymd_His') . '.csv"');
$out = fopen('php://output', 'w');

if ($type === 'actuator') {
    fputcsv($out, ['No', 'Waktu', 'Aktuator', 'Status Sebelumnya', 'Status Baru', 'Sumber', 'User']);
    $rows = $pdo->query("SELECT DATE_FORMAT(ra.waktu_perubahan,'%d-%m-%Y %H:%i:%s') AS w, ja.nama_aktuator, ra.status_sebelumnya, ra.status_baru, ra.sumber_perintah, COALESCE(u.username,'Sistem') AS u FROM riwayat_aktuator ra JOIN aktuator_perangkat ap ON ap.id_aktuator=ra.id_aktuator JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator LEFT JOIN users u ON u.id_user=ra.id_user ORDER BY ra.id_riwayat DESC LIMIT 500")->fetchAll();
    foreach ($rows as $i => $r) fputcsv($out, [$i+1, $r['w'], $r['nama_aktuator'], $r['status_sebelumnya'], $r['status_baru'], $r['sumber_perintah'], $r['u']]);
} else {
    fputcsv($out, ['No', 'Waktu', 'Suhu (C)', 'Kelembapan Udara (%)', 'Kelembapan Tanah (%)']);
    $rows = $pdo->query("SELECT DATE_FORMAT(ps.waktu_pencatatan,'%d-%m-%Y %H:%i:%s') AS w, MAX(CASE WHEN js.kode_sensor='TEMP' THEN ps.nilai_sensor END) AS s, MAX(CASE WHEN js.kode_sensor='HUM' THEN ps.nilai_sensor END) AS h, MAX(CASE WHEN js.kode_sensor='SOIL' THEN ps.nilai_sensor END) AS t FROM pembacaan_sensor ps JOIN sensor_perangkat sp ON sp.id_sensor_perangkat=ps.id_sensor_perangkat JOIN jenis_sensor js ON js.id_jenis_sensor=sp.id_jenis_sensor GROUP BY ps.waktu_pencatatan ORDER BY ps.waktu_pencatatan DESC LIMIT 500")->fetchAll();
    foreach ($rows as $i => $r) fputcsv($out, [$i+1, $r['w'], $r['s'], $r['h'], $r['t']]);
}
fclose($out);
