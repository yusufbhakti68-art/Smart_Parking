<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $rows = $pdo->query("SELECT * FROM media_website ORDER BY id_media DESC")->fetchAll();
        echo json_encode(['ok' => true, 'media' => $rows]);
        exit;
    }
    bm_verify_csrf();
    $user = bm_require_roles(['admin', 'editor']);
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    if (($in['action'] ?? '') === 'delete') {
        $pdo->prepare("DELETE FROM media_website WHERE id_media=?")->execute([(int)($in['id_media'] ?? 0)]);
        echo json_encode(['ok' => true, 'message' => 'Media dihapus']);
        exit;
    }
    $nama = trim((string)($in['nama_file'] ?? 'Gambar Baru'));
    $url  = trim((string)($in['url_file'] ?? ''));
    $kat  = trim((string)($in['kategori'] ?? 'galeri'));
    if ($url === '') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'URL gambar wajib diisi']); exit; }
    $pdo->prepare("INSERT INTO media_website (nama_file, url_file, kategori, diunggah_oleh) VALUES (?, ?, ?, ?)")->execute([$nama, $url, $kat, $user['id_user']]);
    bm_log_activity($pdo, $user['id_user'], 'ADD_MEDIA', "Menambahkan media {$nama}");
    echo json_encode(['ok' => true, 'message' => 'Media berhasil disimpan']);
} catch (Throwable $e) {
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
