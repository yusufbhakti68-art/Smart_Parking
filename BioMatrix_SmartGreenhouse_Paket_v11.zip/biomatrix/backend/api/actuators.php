<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';
require_once __DIR__ . '/../services/MqttService.php';

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        bm_require_roles(['admin', 'editor', 'read']);
        $rows = $pdo->query("SELECT ap.*, ja.kode_aktuator, ja.nama_aktuator, p.kode_perangkat
                             FROM aktuator_perangkat ap
                             JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator
                             JOIN perangkat p ON p.id_perangkat=ap.id_perangkat
                             ORDER BY ap.id_aktuator ASC")->fetchAll();
        echo json_encode(['ok' => true, 'actuators' => $rows]);
        exit;
    }

    bm_verify_csrf();
    $user = bm_require_roles(['admin', 'editor']);
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $kode   = strtolower(trim((string)($in['aktuator'] ?? '')));
    $status = strtoupper(trim((string)($in['status'] ?? 'OFF')));
    $mode   = in_array($in['mode_kontrol'] ?? '', ['Otomatis','Manual','Jadwal'], true) ? $in['mode_kontrol'] : ($status === 'AUTO' ? 'Otomatis' : 'Manual');
    $timeout = max(10, (int)($in['waktu_timeout'] ?? 120));

    if (!in_array($kode, ['kipas', 'pompa'], true) || !in_array($status, ['ON', 'OFF', 'AUTO'], true)) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Parameter aktuator tidak valid']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT ap.id_aktuator, ap.id_perangkat, ap.status_aktuator FROM aktuator_perangkat ap JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator WHERE ja.kode_aktuator=? AND ap.id_perangkat=1 LIMIT 1");
    $stmt->execute([$kode]);
    $akt = $stmt->fetch();

    $topic = $kode === 'kipas' ? 'biomatrix/kipas/control' : 'biomatrix/pompa/control';
    $mqttOk = MqttService::publish($topic, $status);

    if ($akt) {
        $prev = $akt['status_aktuator'];
        $newState = ($status === 'AUTO') ? $prev : $status;
        $pdo->prepare("UPDATE aktuator_perangkat SET status_aktuator=?, mode_kontrol=?, waktu_timeout=?, status_konfirmasi=?, terakhir_diubah=NOW() WHERE id_aktuator=?")
            ->execute([$newState, $mode, $timeout, $mqttOk ? 'menunggu' : 'gagal', $akt['id_aktuator']]);

        $pdo->prepare("INSERT INTO perintah_perangkat (id_perangkat, id_aktuator, topic_mqtt, payload, status_perintah, sumber, dibuat_oleh) VALUES (?, ?, ?, ?, ?, 'Manual', ?)")
            ->execute([$akt['id_perangkat'], $akt['id_aktuator'], $topic, $status, $mqttOk ? 'terkirim' : 'gagal', $user['id_user']]);

        if ($status !== 'AUTO') {
            $pdo->prepare("INSERT INTO riwayat_aktuator (id_aktuator, id_user, status_sebelumnya, status_baru, sumber_perintah) VALUES (?, ?, ?, ?, 'Manual')")
                ->execute([$akt['id_aktuator'], $user['id_user'], $prev, $status]);
        }
        bm_log_activity($pdo, $user['id_user'], 'KONTROL_AKTUATOR', "Perintah {$kode} -> {$status} (Mode {$mode}, MQTT: " . ($mqttOk ? 'Terkirim' : 'Gagal') . ")");
    }

    echo json_encode(['ok' => true, 'aktuator' => $kode, 'status' => $status, 'mode' => $mode, 'mqtt_sent' => $mqttOk]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
