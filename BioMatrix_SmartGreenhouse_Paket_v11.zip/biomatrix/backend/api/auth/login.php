<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../middleware/auth.php';

function bm_detect_device(string $ua): string {
    $os = 'Unknown OS';
    if (preg_match('/Windows NT 10/i', $ua)) $os = 'Windows 10/11';
    elseif (preg_match('/Windows/i', $ua)) $os = 'Windows';
    elseif (preg_match('/Android/i', $ua)) $os = 'Android (HP)';
    elseif (preg_match('/iPhone|iPad/i', $ua)) $os = 'iOS';
    elseif (preg_match('/Macintosh|Mac OS/i', $ua)) $os = 'macOS';
    elseif (preg_match('/Linux/i', $ua)) $os = 'Linux';

    $browser = 'Browser';
    if (preg_match('/Edg/i', $ua)) $browser = 'Edge';
    elseif (preg_match('/Chrome/i', $ua)) $browser = 'Chrome';
    elseif (preg_match('/Firefox/i', $ua)) $browser = 'Firefox';
    elseif (preg_match('/Safari/i', $ua)) $browser = 'Safari';
    return "{$os} - {$browser}";
}

try {
    bm_start_session();
    require __DIR__ . '/../../config/database.php';

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $username = trim((string)($input['username'] ?? ''));
    $password = (string)($input['password'] ?? '');

    if ($username === '' || $password === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Username dan kata sandi wajib diisi.']);
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, (string)$user['password_hash'])) {
        http_response_code(401);
        echo json_encode(['ok' => false, 'error' => 'Username atau kata sandi salah!']);
        exit;
    }

    if (($user['status_akun'] ?? 'aktif') !== 'aktif') {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Akun Anda sedang dinonaktifkan oleh Admin.']);
        exit;
    }

    session_regenerate_id(true);
    $_SESSION['bm_user'] = [
        'id_user'      => (int)$user['id_user'],
        'username'     => $user['username'],
        'nama_lengkap' => $user['nama_lengkap'] ?? $user['username'],
        'role'         => $user['role'] ?? 'editor',
    ];
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    $ua = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'), 0, 250);
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $dev = bm_detect_device($ua);

    $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id_user = ?")->execute([$user['id_user']]);
    $pdo->prepare("INSERT INTO riwayat_login (id_user, username, ip_address, device_info, user_agent) VALUES (?, ?, ?, ?, ?)")
        ->execute([$user['id_user'], $user['username'], $ip, $dev, $ua]);
    $pdo->prepare("INSERT INTO log_aktivitas (id_user, jenis_aktivitas, deskripsi) VALUES (?, 'LOGIN', ?)")
        ->execute([$user['id_user'], "Login {$user['username']} ({$user['role']}) dari {$dev} ({$ip})"]);

    echo json_encode([
        'ok'         => true,
        'user'       => $_SESSION['bm_user'],
        'csrf_token' => $_SESSION['csrf_token'],
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
