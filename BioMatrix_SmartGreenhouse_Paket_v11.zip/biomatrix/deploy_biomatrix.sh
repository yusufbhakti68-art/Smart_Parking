#!/bin/bash
set -e

echo "=================================================================="
echo "  BIOMATRIX v11 — BACKWARD-COMPATIBLE UPGRADE & DEPLOYMENT"
echo "=================================================================="

# 1. Backup instalasi & database lama jika sudah ada
BACKUP_DIR="/root/backup_biomatrix_$(date +%Y%m%d_%H%M%S)"
if [ -d "/var/www/biomatrix" ]; then
    mkdir -p "$BACKUP_DIR"
    cp -r /var/www/biomatrix "$BACKUP_DIR/files"
    mysqldump -u biomatrix -pbiomatrix123 biomatrix > "$BACKUP_DIR/biomatrix_backup.sql" 2>/dev/null || true
    echo "[BACKUP] Tersimpan di $BACKUP_DIR"
fi

# 2. Salin file v11 ke /var/www/biomatrix
mkdir -p /var/www/biomatrix
cp -r ./* /var/www/biomatrix/
chown -R www-data:www-data /var/www/biomatrix

# 3. Cek apakah database biomatrix sudah memiliki tabel users (jika belum, import base SQL)
DB_EXISTS=$(mysql -u biomatrix -pbiomatrix123 -N -e "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='users';" 2>/dev/null || echo "0")
if [ "$DB_EXISTS" = "0" ]; then
    echo "[DB] Instalasi baru terdeteksi -> mengimpor biomatrix_v7_full.sql..."
    mysql -u biomatrix -pbiomatrix123 < /var/www/biomatrix/database/biomatrix_v7_full.sql
fi

# 4. Jalankan seluruh migrasi v11 secara berurutan (aman untuk data lama)
for f in /var/www/biomatrix/database/migrations/*.sql; do
    echo "[MIGRATION] Menjalankan $(basename "$f")..."
    mysql -u biomatrix -pbiomatrix123 biomatrix < "$f"
done

# 5. Sinkronkan password bcrypt asli via PHP (admin/admin, pengelola/pengelola, viewer/viewer)
php /var/www/biomatrix/database/seed_passwords.php

# 6. Update VirtualHost Nginx (Port 8080 + /admin + /api/)
PHP_SOCK=$(find /run/php/ -name "php*-fpm.sock" | head -n 1)
cat << EOF > /etc/nginx/sites-available/biomatrix.conf
server {
    listen 8080;
    server_name _;

    root /var/www/biomatrix;
    index index.html index.php;

    location = /admin {
        return 301 /admin/;
    }

    location /admin/ {
        try_files \$uri \$uri/ /admin/index.html;
    }

    location ^~ /api/ {
        rewrite ^/api/(.*)$ /backend/api/\$1 last;
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:$PHP_SOCK;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }
}
EOF

ln -sf /etc/nginx/sites-available/biomatrix.conf /etc/nginx/sites-enabled/biomatrix.conf
nginx -t && systemctl reload nginx
systemctl restart biomatrix-mqtt.service 2>/dev/null || true

echo "=================================================================="
echo "  BIOMATRIX v11 DEPLOYED 100%!"
echo "  Website Utama & Login Pengelola : http://172.25.234.127:8080/"
echo "  Admin Full Control (21 Menu)    : http://172.25.234.127:8080/admin/"
echo "  Akun Default: admin/admin | pengelola/pengelola | viewer/viewer"
echo "=================================================================="
