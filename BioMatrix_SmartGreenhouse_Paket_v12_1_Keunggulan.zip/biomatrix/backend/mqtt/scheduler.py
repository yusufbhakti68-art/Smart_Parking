import time
from datetime import datetime

active_runs = {}


def check_schedules(conn, client):
    now = datetime.now()
    now_ts = time.time()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT ja.*, jakt.kode_aktuator, ap.topic_control
                   FROM jadwal_aktuator ja
                   JOIN aktuator_perangkat ap ON ap.id_aktuator=ja.id_aktuator
                   JOIN jenis_aktuator jakt ON jakt.id_jenis_aktuator=ap.id_jenis_aktuator
                   WHERE ja.aktif=1 AND ap.is_active=1
                     AND ja.tanggal_mulai<=CURDATE()
                     AND (ja.tanggal_selesai IS NULL OR ja.tanggal_selesai>=CURDATE())"""
            )
            schedules = cur.fetchall()

        for schedule_id, info in list(active_runs.items()):
            if now_ts >= info["end_ts"]:
                topic = info["topic"]
                client.publish(topic, "OFF")
                with conn.cursor() as cur:
                    cur.execute(
                        "UPDATE eksekusi_jadwal SET selesai_aktual=NOW(), status_eksekusi='Selesai' WHERE id_eksekusi=%s",
                        (info["exec_id"],),
                    )
                del active_runs[schedule_id]
                print(f"[SCHEDULER] Jadwal #{schedule_id} selesai -> {topic}=OFF", flush=True)

        current_hm = now.strftime("%H:%M")
        for schedule in schedules:
            schedule_id = schedule["id_jadwal"]
            if schedule_id in active_runs:
                continue
            start_str = str(schedule["waktu_mulai"])[:5].zfill(5)
            if start_str == current_hm and now.second < 10:
                topic = schedule.get("topic_control") or f"biomatrix/{schedule['kode_aktuator']}/control"
                client.publish(topic, "ON")
                duration_seconds = max(60, int(schedule["durasi_menit"]) * 60)
                with conn.cursor() as cur:
                    cur.execute(
                        "INSERT INTO eksekusi_jadwal (id_jadwal, waktu_jadwal, mulai_aktual, status_eksekusi) VALUES (%s, NOW(), NOW(), 'Berjalan')",
                        (schedule_id,),
                    )
                    execution_id = cur.lastrowid
                active_runs[schedule_id] = {
                    "end_ts": now_ts + duration_seconds,
                    "kode": schedule["kode_aktuator"],
                    "topic": topic,
                    "exec_id": execution_id,
                }
                print(f"[SCHEDULER] Jadwal '{schedule['nama_jadwal']}' berjalan {schedule['durasi_menit']} menit -> {topic}=ON", flush=True)
    except Exception as exc:
        print(f"[SCHEDULER ERROR] {exc}", flush=True)
