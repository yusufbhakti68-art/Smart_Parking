import time

last_rule_fire = {}


def evaluate_rules(conn, client, state):
    now = time.time()
    try:
        with conn.cursor() as cur:
            cur.execute(
                """SELECT ao.*, js.kode_sensor, ja.kode_aktuator,
                          ap.status_aktuator, ap.mode_kontrol, ap.topic_control
                   FROM aturan_otomatis ao
                   JOIN sensor_perangkat sp ON sp.id_sensor_perangkat=ao.id_sensor_perangkat
                   JOIN jenis_sensor js ON js.id_jenis_sensor=sp.id_jenis_sensor
                   JOIN aktuator_perangkat ap ON ap.id_aktuator=ao.id_aktuator
                   JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator
                   WHERE ao.aktif=1 AND sp.status_sensor='Aktif'
                     AND sp.is_active=1 AND ap.is_active=1
                   ORDER BY ao.prioritas ASC"""
            )
            rules = cur.fetchall()

        sensor_values = state.get("sensor_values", {})
        for rule in rules:
            if rule["mode_kontrol"] == "Manual":
                continue
            code = str(rule["kode_sensor"]).upper()
            value = sensor_values.get(code)
            if value is None:
                if code == "SOIL":
                    value = state.get("kelembapan_tanah")
                elif code == "TEMP":
                    value = state.get("suhu")
                elif code == "HUM":
                    value = state.get("kelembapan_udara")
            if value is None:
                continue

            operator = rule["operator_kondisi"]
            threshold = float(rule["nilai_ambang"])
            matched = (
                (operator == ">" and value > threshold)
                or (operator == "<" and value < threshold)
                or (operator == ">=" and value >= threshold)
                or (operator == "<=" and value <= threshold)
                or (operator == "=" and value == threshold)
            )
            if not matched:
                continue

            rule_id = rule["id_aturan"]
            cooldown = int(rule.get("cooldown_detik") or 30)
            if now - last_rule_fire.get(rule_id, 0) < cooldown:
                continue

            target = rule["status_tujuan"]
            if rule["status_aktuator"] != target:
                last_rule_fire[rule_id] = now
                topic = rule.get("topic_control") or f"biomatrix/{rule['kode_aktuator']}/control"
                client.publish(topic, target)
                print(f"[AUTOMATION] Rule '{rule['nama_aturan']}' triggered ({value} {operator} {threshold}) -> {topic}={target}", flush=True)
    except Exception as exc:
        print(f"[AUTOMATION ERROR] {exc}", flush=True)
