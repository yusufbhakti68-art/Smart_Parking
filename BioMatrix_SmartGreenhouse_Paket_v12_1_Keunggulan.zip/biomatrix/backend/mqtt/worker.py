#!/usr/bin/env python3
import os
import json
import time
import threading

import pymysql
import paho.mqtt.client as mqtt

from automation import evaluate_rules
from scheduler import check_schedules

DB_HOST = os.getenv("BM_DB_HOST") or os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("BM_DB_PORT") or os.getenv("DB_PORT", "3306"))
DB_NAME = os.getenv("BM_DB_NAME") or os.getenv("DB_NAME", "biomatrix")
DB_USER = os.getenv("BM_DB_USER") or os.getenv("DB_USER", "biomatrix")
DB_PASS = os.getenv("BM_DB_PASS") or os.getenv("DB_PASS")
if not DB_PASS:
    raise RuntimeError("BM_DB_PASS/DB_PASS belum diatur. Periksa EnvironmentFile layanan biomatrix-mqtt.")

MQTT_HOST = os.getenv("BM_MQTT_HOST") or os.getenv("MQTT_HOST", "127.0.0.1")
MQTT_PORT = int(os.getenv("BM_MQTT_PORT") or os.getenv("MQTT_PORT", "1883"))
MQTT_USER = os.getenv("BM_MQTT_USER") or None
MQTT_PASS = os.getenv("BM_MQTT_PASS") or None

state = {
    "suhu": None,
    "kelembapan_udara": None,
    "kelembapan_tanah": None,
    "kipas": "OFF",
    "pompa": "OFF",
    "sensor_values": {},
    "actuators": {},
    "last_db_insert": 0,
}


def get_db():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True,
    )


def save_readings(client):
    now = time.time()
    if now - state["last_db_insert"] < 5:
        return
    state["last_db_insert"] = now
    conn = None
    try:
        conn = get_db()
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE perangkat SET status_koneksi='online', last_seen=%s WHERE id_perangkat=1",
                (ts,),
            )
            cur.execute(
                """SELECT sp.id_sensor_perangkat, js.kode_sensor
                   FROM sensor_perangkat sp
                   JOIN jenis_sensor js ON js.id_jenis_sensor=sp.id_jenis_sensor
                   WHERE sp.id_perangkat=1 AND sp.is_active=1 AND sp.status_sensor='Aktif'"""
            )
            sensors = cur.fetchall()
            values = state.get("sensor_values", {})
            for sensor in sensors:
                code = str(sensor["kode_sensor"]).upper()
                value = values.get(code)
                if value is not None:
                    cur.execute(
                        "INSERT INTO pembacaan_sensor (id_sensor_perangkat, nilai_sensor, waktu_pencatatan) VALUES (%s, %s, %s)",
                        (sensor["id_sensor_perangkat"], value, ts),
                    )
        evaluate_rules(conn, client, state)
    except Exception as exc:
        print(f"[DB ERROR] {exc}", flush=True)
    finally:
        if conn:
            conn.close()


def confirm_actuator_db(kode, new_status):
    kode = str(kode).lower()
    conn = None
    try:
        conn = get_db()
        with conn.cursor() as cur:
            cur.execute(
                """SELECT ap.id_aktuator, ap.status_aktuator
                   FROM aktuator_perangkat ap
                   JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator
                   WHERE ja.kode_aktuator=%s AND ap.id_perangkat=1 AND ap.is_active=1
                   LIMIT 1""",
                (kode,),
            )
            actuator = cur.fetchone()
            if not actuator:
                return
            actuator_id = actuator["id_aktuator"]
            previous = actuator.get("status_aktuator") or "OFF"
            cur.execute(
                "UPDATE aktuator_perangkat SET status_aktuator=%s, status_konfirmasi='dikonfirmasi', terakhir_diubah=NOW() WHERE id_aktuator=%s",
                (new_status, actuator_id),
            )
            cur.execute(
                "UPDATE perintah_perangkat SET status_perintah='dikonfirmasi', dikonfirmasi_pada=NOW() WHERE id_aktuator=%s AND status_perintah='terkirim'",
                (actuator_id,),
            )
            if previous != new_status:
                cur.execute(
                    "INSERT INTO riwayat_aktuator (id_aktuator, status_sebelumnya, status_baru, sumber_perintah) VALUES (%s, %s, %s, 'Otomatis')",
                    (actuator_id, previous, new_status),
                )
        state.setdefault("actuators", {})[kode] = new_status
        if kode in ("kipas", "pompa"):
            state[kode] = new_status
    except Exception as exc:
        print(f"[DB ACTUATOR ERROR] {exc}", flush=True)
    finally:
        if conn:
            conn.close()


def background_scheduler_loop(client):
    while True:
        conn = None
        try:
            conn = get_db()
            check_schedules(conn, client)
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE perangkat SET status_koneksi='offline' WHERE last_seen < DATE_SUB(NOW(), INTERVAL 45 SECOND) AND status_koneksi='online'"
                )
        except Exception as exc:
            print(f"[BG LOOP ERROR] {exc}", flush=True)
        finally:
            if conn:
                conn.close()
        time.sleep(5)


def on_connect(client, userdata, flags, rc):
    print(f"[MQTT WORKER v12] Terhubung ke broker: {rc}", flush=True)
    client.subscribe("biomatrix/sensor/+")
    client.subscribe("biomatrix/actuator/+")
    # Topic status lama tetap didukung untuk kipas dan pompa v11.
    client.subscribe("biomatrix/kipas")
    client.subscribe("biomatrix/pompa")


def on_message(client, userdata, msg):
    topic = msg.topic
    payload = msg.payload.decode("utf-8", errors="ignore").strip()
    try:
        if topic == "biomatrix/sensor/tanah":
            value = float(payload)
            state["kelembapan_tanah"] = value
            state["sensor_values"]["SOIL"] = value
            save_readings(client)
        elif topic == "biomatrix/sensor/dht11":
            data = json.loads(payload)
            state["suhu"] = float(data.get("suhu"))
            state["kelembapan_udara"] = float(data.get("kelembapan"))
            state["sensor_values"]["TEMP"] = state["suhu"]
            state["sensor_values"]["HUM"] = state["kelembapan_udara"]
            save_readings(client)
        elif topic.startswith("biomatrix/sensor/"):
            code = topic.rsplit("/", 1)[-1].upper()
            value = float(payload)
            state["sensor_values"][code] = value
            save_readings(client)
        elif topic in ("biomatrix/kipas", "biomatrix/pompa"):
            code = topic.rsplit("/", 1)[-1]
            status = "ON" if payload.upper() == "ON" else "OFF"
            confirm_actuator_db(code, status)
        elif topic.startswith("biomatrix/actuator/"):
            code = topic.rsplit("/", 1)[-1]
            status = "ON" if payload.upper() == "ON" else "OFF"
            confirm_actuator_db(code, status)
    except Exception as exc:
        print(f"[PARSE ERROR] {topic}: {exc}", flush=True)


def main():
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    if MQTT_USER:
        client.username_pw_set(MQTT_USER, MQTT_PASS or "")
    thread = threading.Thread(target=background_scheduler_loop, args=(client,), daemon=True)
    thread.start()
    while True:
        try:
            client.connect(MQTT_HOST, MQTT_PORT, 60)
            client.loop_forever()
        except Exception as exc:
            print(f"[MQTT RETRY] {exc}", flush=True)
            time.sleep(3)


if __name__ == "__main__":
    main()
