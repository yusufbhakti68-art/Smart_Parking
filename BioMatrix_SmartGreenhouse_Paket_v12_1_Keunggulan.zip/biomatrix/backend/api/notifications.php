<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';
bm_require_roles(['admin', 'editor', 'read']);

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        bm_verify_csrf();
        $pdo->exec("UPDATE notifikasi SET dibaca=1");
        echo json_encode(['ok' => true, 'message' => 'Semua notifikasi ditandai sudah dibaca']);
        exit;
    }
    $rows = $pdo->query("SELECT id_notifikasi, judul, pesan, tingkat, dibaca, DATE_FORMAT(created_at,'%d-%m-%Y %H:%i') AS waktu FROM notifikasi ORDER BY id_notifikasi DESC LIMIT 30")->fetchAll();
    echo json_encode(['ok' => true, 'notifications' => $rows]);
} catch (Throwable $e) {
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
