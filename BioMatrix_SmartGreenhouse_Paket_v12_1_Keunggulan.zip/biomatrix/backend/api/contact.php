<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        bm_require_roles(['admin', 'editor']);
        $rows = $pdo->query("SELECT pk.id_pesan, k.nama_lengkap, k.email, pk.isi_pesan, pk.status_baca, DATE_FORMAT(pk.created_at,'%d-%m-%Y %H:%i') AS waktu FROM pesan_kontak pk JOIN kontak k ON k.id_kontak=pk.id_kontak ORDER BY pk.id_pesan DESC LIMIT 50")->fetchAll();
        echo json_encode(['ok' => true, 'messages' => $rows]);
        exit;
    }

    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    if (($in['action'] ?? '') === 'mark_read') {
        bm_verify_csrf();
        bm_require_roles(['admin', 'editor']);
        $pdo->prepare("UPDATE pesan_kontak SET status_baca='sudah_dibaca' WHERE id_pesan=?")->execute([(int)($in['id_pesan'] ?? 0)]);
        echo json_encode(['ok' => true, 'message' => 'Pesan ditandai sudah dibaca']);
        exit;
    }

    if (!empty($in['website'])) { echo json_encode(['ok'=>true,'message'=>'Pesan berhasil dikirim']); exit; }
    $ip=(string)($_SERVER['REMOTE_ADDR']??'0.0.0.0');$limitKey=hash('sha256',$ip.'|contact');
    $pdo->prepare("INSERT INTO public_request_limits(limit_key,window_start,hit_count) VALUES(?,NOW(),1) ON DUPLICATE KEY UPDATE hit_count=IF(window_start < NOW()-INTERVAL 1 HOUR,1,hit_count+1),window_start=IF(window_start < NOW()-INTERVAL 1 HOUR,NOW(),window_start)")->execute([$limitKey]);
    $qLimit=$pdo->prepare("SELECT hit_count FROM public_request_limits WHERE limit_key=?");$qLimit->execute([$limitKey]);if((int)$qLimit->fetchColumn()>5){http_response_code(429);echo json_encode(['ok'=>false,'error'=>'Terlalu banyak pesan dari jaringan ini. Coba lagi nanti.']);exit;}
    if (!empty($in['website'])) { echo json_encode(['ok'=>true,'message'=>'Pesan berhasil dikirim']); exit; }
    $ip=(string)($_SERVER['REMOTE_ADDR']??'0.0.0.0');$limitKey=hash('sha256',$ip.'|contact');
    $pdo->prepare("INSERT INTO public_request_limits(limit_key,window_start,hit_count) VALUES(?,NOW(),1) ON DUPLICATE KEY UPDATE hit_count=IF(window_start < NOW()-INTERVAL 1 HOUR,1,hit_count+1),window_start=IF(window_start < NOW()-INTERVAL 1 HOUR,NOW(),window_start)")->execute([$limitKey]);
    $qLimit=$pdo->prepare("SELECT hit_count FROM public_request_limits WHERE limit_key=?");$qLimit->execute([$limitKey]);if((int)$qLimit->fetchColumn()>5){http_response_code(429);echo json_encode(['ok'=>false,'error'=>'Terlalu banyak pesan dari jaringan ini. Coba lagi nanti.']);exit;}
    $nama = trim((string)($in['nama'] ?? ''));
    $email = trim((string)($in['email'] ?? ''));
    $pesan = trim((string)($in['pesan'] ?? ''));
    if ($nama === '' || $email === '' || $pesan === '') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Semua kolom wajib diisi']); exit; }

    $stmt = $pdo->prepare("SELECT id_kontak FROM kontak WHERE email=? LIMIT 1");
    $stmt->execute([$email]);
    $row = $stmt->fetch();
    $idKontak = $row ? (int)$row['id_kontak'] : 0;
    if (!$idKontak) {
        $pdo->prepare("INSERT INTO kontak (nama_lengkap, email) VALUES (?, ?)")->execute([$nama, $email]);
        $idKontak = (int)$pdo->lastInsertId();
    }
    $pdo->prepare("INSERT INTO pesan_kontak (id_kontak, isi_pesan) VALUES (?, ?)")->execute([$idKontak, $pesan]);
    echo json_encode(['ok' => true, 'message' => 'Pesan berhasil dikirim ke pengelola']);
} catch (Throwable $e) {
    error_log('BioMatrix contact API: '.$e->getMessage());
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Pesan belum dapat dikirim. Silakan coba kembali.']);
}
