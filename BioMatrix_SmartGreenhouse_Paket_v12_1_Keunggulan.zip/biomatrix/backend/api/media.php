<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
require_once __DIR__.'/../middleware/permission.php'; require_once __DIR__.'/../middleware/csrf.php';
function bm_media_error(int $status,string $msg): void { http_response_code($status); echo json_encode(['ok'=>false,'error'=>$msg]); exit; }
try {
 require __DIR__.'/../config/database.php';
 if(($_SERVER['REQUEST_METHOD']??'GET')==='GET'){ bm_require_roles(['admin','editor','read']); $rows=$pdo->query("SELECT id_media,nama_file,url_file,tipe_file,kategori,file_size,created_at FROM media_website ORDER BY id_media DESC")->fetchAll(); echo json_encode(['ok'=>true,'media'=>$rows]); exit; }
 bm_verify_csrf(); $user=bm_require_roles(['admin','editor']); $action=(string)($_POST['action']??'');
 if($action==='delete') { $id=(int)($_POST['id_media']??0); $q=$pdo->prepare("SELECT storage_name FROM media_website WHERE id_media=?");$q->execute([$id]);$m=$q->fetch();if(!$m)bm_media_error(404,'Media tidak ditemukan');
  $pdo->prepare("UPDATE konten_website SET id_media_background=NULL,url_gambar=NULL WHERE id_media_background=?")->execute([$id]);$pdo->prepare("DELETE FROM media_website WHERE id_media=?")->execute([$id]); if(!empty($m['storage_name'])){$f=realpath(__DIR__.'/../../uploads/media');$target=$f?realpath($f.'/'.$m['storage_name']):false;if($target && str_starts_with($target,$f.DIRECTORY_SEPARATOR) && is_file($target))@unlink($target);} bm_log_activity($pdo,$user['id_user'],'MEDIA_DELETE',"Menghapus media #{$id}");echo json_encode(['ok'=>true,'message'=>'Media dihapus']);exit;
 }
 $name=trim((string)($_POST['nama_file']??''));$cat=trim((string)($_POST['kategori']??'galeri'));if($name==='')bm_media_error(400,'Nama media wajib diisi');
 $url='';$mime='';$stored=null;$size=0;$sha=null;
 if(isset($_FILES['file']) && $_FILES['file']['error']!==UPLOAD_ERR_NO_FILE){$f=$_FILES['file'];if($f['error']!==UPLOAD_ERR_OK)bm_media_error(400,'Upload gagal (kode '.$f['error'].')');if($f['size']>8*1024*1024)bm_media_error(413,'Ukuran gambar maksimal 8 MB');
  $fi=new finfo(FILEINFO_MIME_TYPE);$mime=$fi->file($f['tmp_name'])?:'';$exts=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];if(!isset($exts[$mime]))bm_media_error(415,'Format yang diizinkan: JPG, PNG, WEBP, GIF. SVG tidak diizinkan.');
  $dir=__DIR__.'/../../uploads/media';if(!is_dir($dir)&&!mkdir($dir,0750,true))bm_media_error(500,'Folder upload tidak dapat dibuat');$stored=bin2hex(random_bytes(18)).'.'.$exts[$mime];$dest=$dir.'/'.$stored;if(!move_uploaded_file($f['tmp_name'],$dest))bm_media_error(500,'Gagal menyimpan gambar ke server');chmod($dest,0640);$size=(int)$f['size'];$sha=hash_file('sha256',$dest);$url='/uploads/media/'.$stored;
 } else { $url=trim((string)($_POST['url_file']??''));if(!filter_var($url,FILTER_VALIDATE_URL)||!in_array(strtolower((string)parse_url($url,PHP_URL_SCHEME)),['https','http'],true))bm_media_error(400,'URL gambar harus berupa HTTP/HTTPS yang valid');$mime='image/external'; }
 $q=$pdo->prepare("INSERT INTO media_website(nama_file,url_file,tipe_file,kategori,diunggah_oleh,storage_name,file_size,checksum_sha256) VALUES(?,?,?,?,?,?,?,?)");$q->execute([$name,$url,$mime,$cat,$user['id_user'],$stored,$size?:null,$sha]);bm_log_activity($pdo,$user['id_user'],'MEDIA_UPLOAD',"Menambahkan media {$name}");echo json_encode(['ok'=>true,'message'=>'Media berhasil disimpan','url_file'=>$url]);
} catch(Throwable $e){error_log('BioMatrix media API: '.$e->getMessage());http_response_code(500);echo json_encode(['ok'=>false,'error'=>'Terjadi kesalahan saat mengelola media.']);}
