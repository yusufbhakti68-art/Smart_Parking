<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        bm_verify_csrf();
        $user = bm_require_roles(['admin', 'editor']);
        $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $action = trim((string)($in['action'] ?? 'update_section'));

        if ($action === 'update_section') {
            $kunci = trim((string)($in['kunci_bagian'] ?? ''));
            $judul = trim((string)($in['judul'] ?? ''));
            $sub   = trim((string)($in['subjudul'] ?? ''));
            $desc  = trim((string)($in['deskripsi'] ?? ''));
            $img   = trim((string)($in['url_gambar'] ?? ''));
            $mediaId = (int)($in['id_media_background'] ?? 0);
            if ($mediaId > 0) { $mq=$pdo->prepare("SELECT url_file FROM media_website WHERE id_media=?"); $mq->execute([$mediaId]); $mediaUrl=$mq->fetchColumn(); if (!$mediaUrl) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Media background tidak ditemukan']); exit; } $img=(string)$mediaUrl; } else { $mediaId=null; }
            $size  = in_array($in['bg_size'] ?? '', ['cover','contain','auto'], true) ? $in['bg_size'] : 'cover';
            $blur  = max(0, min(20, (int)($in['bg_blur'] ?? 0)));
            $dark  = max(0, min(90, (int)($in['bg_darkness'] ?? 55)));
            $tampil = !empty($in['tampil']) ? 1 : 0;
            $pub   = ($in['status_publikasi'] ?? 'published') === 'draft' ? 'draft' : 'published';

            $old = $pdo->prepare("SELECT judul FROM konten_website WHERE kunci_bagian=? LIMIT 1");
            $old->execute([$kunci]);
            $oldRow = $old->fetch();

            $pdo->prepare("UPDATE konten_website SET judul=?, subjudul=?, deskripsi=?, url_gambar=?, id_media_background=?, bg_size=?, bg_blur=?, bg_darkness=?, tampil=?, status_publikasi=?, updated_by=? WHERE kunci_bagian=?")
                ->execute([$judul, $sub, $desc, $img, $mediaId, $size, $blur, $dark, $tampil, $pub, $user['id_user'], $kunci]);
            $pdo->prepare("INSERT INTO riwayat_perubahan_konten (kunci_bagian, judul_lama, judul_baru, status_publikasi, diubah_oleh) VALUES (?, ?, ?, ?, ?)")
                ->execute([$kunci, $oldRow['judul'] ?? '', $judul, $pub, $user['id_user']]);
            bm_log_activity($pdo, $user['id_user'], 'CMS_UPDATE', "Memperbarui bagian {$kunci} ({$pub})");
            echo json_encode(['ok' => true, 'message' => "Bagian '{$kunci}' disimpan sebagai {$pub}!"]);
            exit;
        }

        if ($action === 'add_section') {
            $judul = trim((string)($in['judul'] ?? ''));
            if ($judul === '') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Judul wajib diisi']); exit; }
            $kunci = 'custom_' . bin2hex(random_bytes(5));
            $mediaId=(int)($in['id_media_background']??0); $img=trim((string)($in['url_gambar']??''));
            if($mediaId>0){$mq=$pdo->prepare("SELECT url_file FROM media_website WHERE id_media=?");$mq->execute([$mediaId]);$u=$mq->fetchColumn();if(!$u){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Media tidak ditemukan']);exit;}$img=(string)$u;}else{$mediaId=null;}
            $pdo->prepare("INSERT INTO konten_website (kunci_bagian, judul, subjudul, deskripsi, url_gambar, id_media_background, bg_size, bg_blur, bg_darkness, tampil, status_publikasi, is_custom, urutan, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'published', 1, 50, ?)")
                ->execute([$kunci, $judul, trim((string)($in['subjudul'] ?? 'INFORMASI')), trim((string)($in['deskripsi'] ?? '')), $img, $mediaId, in_array($in['bg_size']??'', ['cover','contain','auto'], true)?$in['bg_size']:'cover', max(0,min(20,(int)($in['bg_blur']??0))), max(0,min(90,(int)($in['bg_darkness']??50))), $user['id_user']]);
            bm_log_activity($pdo, $user['id_user'], 'CMS_ADD', "Menambah halaman kustom: {$judul}");
            echo json_encode(['ok' => true, 'message' => "Halaman '{$judul}' ditambahkan!"]);
            exit;
        }

        if ($action === 'delete_section') {
            $pdo->prepare("DELETE FROM konten_website WHERE kunci_bagian=? AND is_custom=1")->execute([trim((string)($in['kunci_bagian'] ?? ''))]);
            echo json_encode(['ok' => true, 'message' => 'Halaman kustom dihapus']);
            exit;
        }

        if ($action === 'toggle_menu') {
            bm_require_roles(['admin']);
            $pdo->prepare("UPDATE pengaturan_menu_pengelola SET tampil=? WHERE kode_menu=?")->execute([!empty($in['tampil']) ? 1 : 0, trim((string)($in['kode_menu'] ?? ''))]);
            echo json_encode(['ok' => true, 'message' => 'Visibilitas menu diperbarui']);
            exit;
        }

        if ($action === 'add_nav') {
            bm_require_roles(['admin']);
            $label=trim((string)($in['label']??'')); $target=trim((string)($in['target_section']??''));
            if($label===''||!preg_match('/^custom_[a-f0-9]{10}$/',$target)){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Pilih halaman kustom yang valid dan isi label menu']);exit;}
            $q=$pdo->prepare("SELECT COUNT(*) FROM konten_website WHERE kunci_bagian=? AND is_custom=1");$q->execute([$target]);if(!(int)$q->fetchColumn()){http_response_code(404);echo json_encode(['ok'=>false,'error'=>'Halaman kustom tidak ditemukan']);exit;}
            $slug=trim((string)($in['slug']??''));if($slug==='')$slug=strtolower(trim(preg_replace('/[^a-z0-9]+/i','-',$label),'-'));
            if(!preg_match('/^[a-z0-9-]{2,100}$/',$slug)){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Slug menu tidak valid']);exit;}
            $pdo->prepare("INSERT INTO halaman_navigasi(label,slug,target_section,urutan,tampil) VALUES(?,?,?,?,1)")->execute([$label,$slug,'sec-'.$target,(int)$pdo->query("SELECT COALESCE(MAX(urutan),0)+1 FROM halaman_navigasi")->fetchColumn()]);
            bm_log_activity($pdo,$user['id_user'],'NAV_ADD',"Menambah menu website {$label}");echo json_encode(['ok'=>true,'message'=>'Menu website ditambahkan']);exit;
        }
        if ($action === 'toggle_nav') {
            bm_require_roles(['admin']);$pdo->prepare("UPDATE halaman_navigasi SET tampil=? WHERE id_nav=?")->execute([!empty($in['tampil'])?1:0,(int)($in['id_nav']??0)]);echo json_encode(['ok'=>true,'message'=>'Visibilitas menu website diperbarui']);exit;
        }
        if ($action === 'delete_nav') {
            bm_require_roles(['admin']);$pdo->prepare("DELETE FROM halaman_navigasi WHERE id_nav=?")->execute([(int)($in['id_nav']??0)]);echo json_encode(['ok'=>true,'message'=>'Menu website dihapus']);exit;
        }

        if ($action === 'toggle_sensor') {
            $pdo->prepare("UPDATE sensor_perangkat SET status_sensor=? WHERE id_sensor_perangkat=?")->execute([($in['status_sensor'] ?? '') === 'Aktif' ? 'Aktif' : 'Nonaktif', (int)($in['id_sensor_perangkat'] ?? 0)]);
            echo json_encode(['ok' => true, 'message' => 'Status sensor diperbarui']);
            exit;
        }
    }

    $isAdminView = isset($_GET['mode']) && $_GET['mode'] === 'admin';
    if ($isAdminView) bm_require_roles(['admin']);
    $where = $isAdminView ? '' : "WHERE status_publikasi='published'";
    $kontenRows = $pdo->query("SELECT * FROM konten_website {$where} ORDER BY urutan ASC, id_konten ASC")->fetchAll();
    $kontenMap = [];
    foreach ($kontenRows as $k) { $kontenMap[$k['kunci_bagian']] = $k; }
    $paketRows = $pdo->query("SELECT * FROM paket_komponen WHERE tampil=1 ORDER BY urutan ASC")->fetchAll();
    $menus = $pdo->query("SELECT * FROM pengaturan_menu_pengelola ORDER BY urutan ASC")->fetchAll();
    $sensors = $pdo->query("SELECT sp.id_sensor_perangkat, js.kode_sensor, js.nama_sensor, sp.status_sensor FROM sensor_perangkat sp JOIN jenis_sensor js ON js.id_jenis_sensor=sp.id_jenis_sensor WHERE sp.id_perangkat=1")->fetchAll();
    $media = $pdo->query("SELECT id_media,nama_file,url_file,tipe_file,kategori FROM media_website ORDER BY id_media DESC")->fetchAll();
    $navPublic = $pdo->query("SELECT id_nav,label,slug,target_section,urutan,tampil FROM halaman_navigasi ORDER BY urutan ASC")->fetchAll();

    echo json_encode([
        'ok' => true, 'konten' => $kontenMap, 'konten_list' => $kontenRows,
        'paket' => $paketRows, 'menus' => $menus, 'sensors' => $sensors, 'media' => $media, 'nav_public' => $navPublic
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
