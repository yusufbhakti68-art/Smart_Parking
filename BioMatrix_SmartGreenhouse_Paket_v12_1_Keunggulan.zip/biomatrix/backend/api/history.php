<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
bm_require_roles(['admin', 'editor', 'read']);

try {
    require __DIR__ . '/../config/database.php';
    $limit = min(200, max(10, (int)($_GET['limit'] ?? 50)));
    $sensors = $pdo->query("SELECT DATE_FORMAT(ps.waktu_pencatatan,'%d-%m-%Y %H:%i:%s') AS waktu_format,
                                   MAX(CASE WHEN js.kode_sensor='TEMP' THEN ps.nilai_sensor END) AS suhu,
                                   MAX(CASE WHEN js.kode_sensor='HUM'  THEN ps.nilai_sensor END) AS kelembapan_udara,
                                   MAX(CASE WHEN js.kode_sensor='SOIL' THEN ps.nilai_sensor END) AS kelembapan_tanah
                            FROM pembacaan_sensor ps
                            JOIN sensor_perangkat sp ON sp.id_sensor_perangkat=ps.id_sensor_perangkat
                            JOIN jenis_sensor js ON js.id_jenis_sensor=sp.id_jenis_sensor
                            GROUP BY ps.waktu_pencatatan ORDER BY ps.waktu_pencatatan DESC LIMIT {$limit}")->fetchAll();

    $actuators = $pdo->query("SELECT ra.id_riwayat, ja.nama_aktuator, ra.status_sebelumnya, ra.status_baru, ra.sumber_perintah, DATE_FORMAT(ra.waktu_perubahan,'%d-%m-%Y %H:%i:%s') AS waktu_format, u.username
                              FROM riwayat_aktuator ra
                              JOIN aktuator_perangkat ap ON ap.id_aktuator=ra.id_aktuator
                              JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator
                              LEFT JOIN users u ON u.id_user=ra.id_user
                              ORDER BY ra.id_riwayat DESC LIMIT {$limit}")->fetchAll();

    echo json_encode(['ok' => true, 'sensor_history' => $sensors, 'actuator_history' => $actuators]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
