<?php
declare(strict_types=1); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
try { require __DIR__.'/../config/database.php'; $q=$pdo->prepare("SELECT kunci,nilai FROM pengaturan_sistem WHERE kunci IN ('maintenance_mode','maintenance_message')");$q->execute();$s=[];foreach($q->fetchAll() as $r)$s[$r['kunci']]=$r['nilai'];echo json_encode(['ok'=>true,'maintenance'=>($s['maintenance_mode']??'0')==='1','message'=>$s['maintenance_message']??'Website sedang dalam pemeliharaan.']); }
catch(Throwable $e){http_response_code(200);echo json_encode(['ok'=>true,'maintenance'=>false]);}
