<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        bm_require_roles(['admin', 'editor', 'read']);
        $rows = $pdo->query("SELECT ja.*, jakt.nama_aktuator, jakt.kode_aktuator FROM jadwal_aktuator ja JOIN aktuator_perangkat ap ON ap.id_aktuator=ja.id_aktuator JOIN jenis_aktuator jakt ON jakt.id_jenis_aktuator=ap.id_jenis_aktuator WHERE ap.is_active=1 ORDER BY ja.id_jadwal DESC")->fetchAll();
        $execs = $pdo->query("SELECT ej.*, ja.nama_jadwal FROM eksekusi_jadwal ej JOIN jadwal_aktuator ja ON ja.id_jadwal=ej.id_jadwal ORDER BY ej.id_eksekusi DESC LIMIT 20")->fetchAll();
        $actuators = $pdo->query("SELECT ap.id_aktuator, ja.nama_aktuator, ja.kode_aktuator FROM aktuator_perangkat ap JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator WHERE ap.is_active=1 ORDER BY ap.id_aktuator")->fetchAll();
        echo json_encode(['ok' => true, 'schedules' => $rows, 'executions' => $execs, 'actuators' => $actuators]);
        exit;
    }

    bm_verify_csrf();
    $user = bm_require_roles(['admin', 'editor']);
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $action = $in['action'] ?? 'save';

    if ($action === 'delete') {
        $id = (int)($in['id_jadwal'] ?? 0);
        $pdo->prepare("DELETE FROM jadwal_aktuator WHERE id_jadwal=?")->execute([$id]);
        bm_log_activity($pdo, $user['id_user'], 'DELETE_SCHEDULE', "Menghapus jadwal #{$id}");
        echo json_encode(['ok' => true, 'message' => 'Jadwal berhasil dihapus']);
        exit;
    }
    if ($action === 'toggle') {
        $id = (int)($in['id_jadwal'] ?? 0);
        $aktif = !empty($in['aktif']) ? 1 : 0;
        $pdo->prepare("UPDATE jadwal_aktuator SET aktif=? WHERE id_jadwal=?")->execute([$aktif, $id]);
        echo json_encode(['ok' => true, 'message' => 'Status jadwal diperbarui']);
        exit;
    }

    $idAkt = (int)($in['id_aktuator'] ?? 2);
    $checkAct = $pdo->prepare("SELECT COUNT(*) FROM aktuator_perangkat WHERE id_aktuator=? AND is_active=1");
    $checkAct->execute([$idAkt]);
    if (!(int)$checkAct->fetchColumn()) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Aktuator tidak ditemukan atau sedang dinonaktifkan']); exit; }
    $nama  = trim((string)($in['nama_jadwal'] ?? 'Jadwal Irigasi'));
    $mulai = trim((string)($in['waktu_mulai'] ?? '06:00:00'));
    $dur   = max(1, (int)($in['durasi_menit'] ?? 2));
    $mode  = in_array($in['mode_pengulangan'] ?? '', ['Sekali','Harian','Mingguan'], true) ? $in['mode_pengulangan'] : 'Harian';
    $intJam = max(0, (int)($in['interval_jam'] ?? 2));
    $tglMulai = $in['tanggal_mulai'] ?: date('Y-m-d');

    $pdo->prepare("INSERT INTO jadwal_aktuator (id_aktuator, nama_jadwal, waktu_mulai, durasi_menit, mode_pengulangan, interval_jam, tanggal_mulai, aktif, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?)")
        ->execute([$idAkt, $nama, $mulai, $dur, $mode, $intJam, $tglMulai, $user['id_user']]);
    bm_log_activity($pdo, $user['id_user'], 'ADD_SCHEDULE', "Menambahkan jadwal {$nama} ({$dur} menit)");
    echo json_encode(['ok' => true, 'message' => 'Jadwal otomatis berhasil disimpan']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
