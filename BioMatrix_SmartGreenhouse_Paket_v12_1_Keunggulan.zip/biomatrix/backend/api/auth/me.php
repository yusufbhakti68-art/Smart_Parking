<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../../middleware/auth.php';
$user = bm_current_user();
if (!$user) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'authenticated' => false]);
    exit;
}
echo json_encode(['ok' => true, 'authenticated' => true, 'user' => $user, 'csrf_token' => $_SESSION['csrf_token'] ?? '']);
