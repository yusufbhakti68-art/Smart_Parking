<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
bm_require_roles(['admin', 'editor']);

try {
    require __DIR__ . '/../config/database.php';
    $rows = $pdo->query("SELECT la.id_aktivitas, la.jenis_aktivitas, la.deskripsi, DATE_FORMAT(la.waktu_aktivitas,'%d-%m-%Y %H:%i:%s') AS waktu, COALESCE(u.username,'Sistem') AS username
                         FROM log_aktivitas la LEFT JOIN users u ON u.id_user=la.id_user ORDER BY la.id_aktivitas DESC LIMIT 100")->fetchAll();
    echo json_encode(['ok' => true, 'activities' => $rows]);
} catch (Throwable $e) {
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
