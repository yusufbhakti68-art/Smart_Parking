<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store');
require_once __DIR__.'/../middleware/permission.php'; require_once __DIR__.'/../middleware/csrf.php';
try {
 require __DIR__.'/../config/database.php'; $actor=bm_require_roles(['admin']);
 if (($_SERVER['REQUEST_METHOD']??'GET')==='GET') {
  $users=$pdo->query("SELECT id_user,username,nama_lengkap,role,status_akun,last_login,created_at,updated_at FROM users WHERE deleted_at IS NULL ORDER BY id_user ASC")->fetchAll();
  $history=$pdo->query("SELECT id_login,username,ip_address,device_info,DATE_FORMAT(waktu_login,'%d-%m-%Y %H:%i:%s') waktu_format FROM riwayat_login ORDER BY id_login DESC LIMIT 40")->fetchAll();
  echo json_encode(['ok'=>true,'users'=>$users,'login_history'=>$history]); exit;
 }
 bm_verify_csrf(); $in=json_decode(file_get_contents('php://input'),true)?:$_POST; $action=(string)($in['action']??'create');
 $id=(int)($in['id_user']??0);
 if ($action==='create') {
  $username=trim((string)($in['username']??'')); $nama=trim((string)($in['nama_lengkap']??'Pengelola')); $pass=(string)($in['password']??''); $role=(string)($in['role']??'editor');
  if (!preg_match('/^[A-Za-z0-9._-]{3,50}$/',$username) || strlen($pass)<10 || !in_array($role,['admin','editor','read'],true)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Username 3-50 karakter (huruf/angka/._-), password minimal 10 karakter, dan role harus valid.']); exit; }
  $q=$pdo->prepare("INSERT INTO users(username,nama_lengkap,password_hash,role,status_akun,password_changed_at) VALUES(?,?,?,?, 'aktif',NOW())"); $q->execute([$username,$nama,password_hash($pass,PASSWORD_DEFAULT),$role]);
  bm_log_activity($pdo,$actor['id_user'],'USER_CREATE',"Membuat akun {$username} ({$role})"); echo json_encode(['ok'=>true,'message'=>'Akun berhasil dibuat']); exit;
 }
 if ($id<1) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'ID akun tidak valid']); exit; }
 $q=$pdo->prepare("SELECT id_user,username,role,status_akun FROM users WHERE id_user=? AND deleted_at IS NULL FOR UPDATE"); $pdo->beginTransaction(); $q->execute([$id]); $target=$q->fetch();
 if (!$target) { $pdo->rollBack(); http_response_code(404); echo json_encode(['ok'=>false,'error'=>'Akun tidak ditemukan']); exit; }
 if ($action==='update') {
  $username=trim((string)($in['username']??$target['username'])); $nama=trim((string)($in['nama_lengkap']??'')); $role=(string)($in['role']??$target['role']);
  if (!preg_match('/^[A-Za-z0-9._-]{3,50}$/',$username) || $nama==='' || !in_array($role,['admin','editor','read'],true)) { $pdo->rollBack(); http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Data akun tidak valid']); exit; }
  if ($id===(int)$actor['id_user'] && $role!=='admin') { $pdo->rollBack(); http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Admin tidak dapat menurunkan role akun sendiri']); exit; }
  $pdo->prepare("UPDATE users SET username=?,nama_lengkap=?,role=? WHERE id_user=?")->execute([$username,$nama,$role,$id]);
  bm_log_activity($pdo,$actor['id_user'],'USER_UPDATE',"Mengubah data akun #{$id}");
 } elseif ($action==='reset_password') {
  $pass=(string)($in['password_baru']??''); if (strlen($pass)<10) { $pdo->rollBack(); http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Password baru minimal 10 karakter']); exit; }
  $pdo->prepare("UPDATE users SET password_hash=?,password_changed_at=NOW() WHERE id_user=?")->execute([password_hash($pass,PASSWORD_DEFAULT),$id]);
  bm_log_activity($pdo,$actor['id_user'],'USER_PASSWORD_RESET',"Reset password akun #{$id}");
 } elseif ($action==='toggle_status') {
  $new=($in['status_akun']??'')==='aktif'?'aktif':'nonaktif';
  if ($id===(int)$actor['id_user'] && $new!=='aktif') { $pdo->rollBack(); http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Tidak dapat menonaktifkan akun sendiri']); exit; }
  if ($target['role']==='admin' && $new!=='aktif') { $c=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status_akun='aktif' AND deleted_at IS NULL")->fetchColumn(); if($c<=1){$pdo->rollBack();http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Admin aktif terakhir tidak dapat dinonaktifkan']);exit;} }
  $pdo->prepare("UPDATE users SET status_akun=? WHERE id_user=?")->execute([$new,$id]); bm_log_activity($pdo,$actor['id_user'],'USER_STATUS',"Status akun #{$id} menjadi {$new}");
 } elseif ($action==='soft_delete') {
  if ($id===(int)$actor['id_user']) { $pdo->rollBack(); http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Tidak dapat menghapus akun yang sedang digunakan']); exit; }
  if ($target['role']==='admin') { $c=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status_akun='aktif' AND deleted_at IS NULL")->fetchColumn(); if($c<=1){$pdo->rollBack();http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Admin aktif terakhir tidak dapat dihapus']);exit;} }
  $pdo->prepare("UPDATE users SET status_akun='nonaktif',deleted_at=NOW() WHERE id_user=?")->execute([$id]); bm_log_activity($pdo,$actor['id_user'],'USER_SOFT_DELETE',"Mengarsipkan akun #{$id} ({$target['username']})");
 } else { $pdo->rollBack(); http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Aksi tidak dikenal']); exit; }
 $pdo->commit(); echo json_encode(['ok'=>true,'message'=>'Perubahan akun berhasil disimpan']);
} catch(Throwable $e) { if(isset($pdo)&&$pdo->inTransaction())$pdo->rollBack(); error_log('BioMatrix users API: '.$e->getMessage()); http_response_code(500); echo json_encode(['ok'=>false,'error'=>'Terjadi kesalahan pada pengelolaan akun.']); }
