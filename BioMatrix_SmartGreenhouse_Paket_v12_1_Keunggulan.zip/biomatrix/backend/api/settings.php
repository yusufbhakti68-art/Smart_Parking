<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';
require_once __DIR__ . '/../services/MqttService.php';

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        bm_require_roles(['admin', 'editor', 'read']);
        $sys = $pdo->query("SELECT * FROM pengaturan_sistem ORDER BY kunci ASC")->fetchAll();
        $dev = $pdo->query("SELECT p.*, pp.mode_sistem, pp.interval_update FROM perangkat p LEFT JOIN pengaturan_perangkat pp ON pp.id_perangkat=p.id_perangkat WHERE p.id_perangkat=1")->fetch();
        echo json_encode(['ok' => true, 'system' => $sys, 'device' => $dev]);
        exit;
    }

    bm_verify_csrf();
    $user = bm_require_roles(['admin', 'editor']);
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;

    if (isset($in['kunci']) && isset($in['nilai'])) {
        bm_require_roles(['admin']);
        $key=trim((string)$in['kunci']); $value=trim((string)$in['nilai']);
        $pdo->prepare("UPDATE pengaturan_sistem SET nilai=? WHERE kunci=?")->execute([$value,$key]);
        if($key==='maintenance_mode'){
            $flag='/var/lib/biomatrix/maintenance.flag';
            if($value==='1'){if(!is_dir(dirname($flag))||!is_writable(dirname($flag))||file_put_contents($flag,'enabled')===false){http_response_code(500);echo json_encode(['ok'=>false,'error'=>'Status tersimpan di database tetapi flag server tidak dapat ditulis. Periksa permission /var/lib/biomatrix.']);exit;}}
            else {if(is_file($flag)&&!@unlink($flag)){http_response_code(500);echo json_encode(['ok'=>false,'error'=>'Tidak dapat menonaktifkan flag maintenance server.']);exit;}}
        }
        bm_log_activity($pdo, $user['id_user'], 'SYS_SETTING', "Ubah {$in['kunci']}");
        echo json_encode(['ok' => true, 'message' => 'Pengaturan sistem disimpan']);
        exit;
    }

    $nama = trim((string)($in['nama_perangkat'] ?? 'BioMatrix Greenhouse'));
    $mode = in_array($in['mode_sistem'] ?? '', ['Otomatis','Manual'], true) ? $in['mode_sistem'] : 'Otomatis';
    $suhu = (float)($in['suhu_maks'] ?? 30.0);
    $tanah = (float)($in['kelembapan_tanah_min'] ?? 40.0);

    $pdo->prepare("UPDATE perangkat SET nama_perangkat=? WHERE id_perangkat=1")->execute([$nama]);
    $pdo->prepare("UPDATE pengaturan_perangkat SET mode_sistem=? WHERE id_perangkat=1")->execute([$mode]);
    $pdo->prepare("UPDATE aturan_otomatis SET nilai_ambang=? WHERE id_sensor_perangkat=2")->execute([$suhu]);
    $pdo->prepare("UPDATE aturan_otomatis SET nilai_ambang=? WHERE id_sensor_perangkat=1")->execute([$tanah]);

    MqttService::publish('biomatrix/config', json_encode(['mode_sistem'=>$mode, 'suhu_maks'=>$suhu, 'kelembapan_tanah_min'=>$tanah]));
    bm_log_activity($pdo, $user['id_user'], 'UPDATE_SETTINGS', "Mode: {$mode}, SuhuMaks: {$suhu}C, TanahMin: {$tanah}%");
    echo json_encode(['ok' => true, 'message' => 'Pengaturan tersimpan & dikirim ke ESP32']);
} catch (Throwable $e) {
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
