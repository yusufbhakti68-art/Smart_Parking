<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../middleware/permission.php';
bm_require_roles(['admin', 'editor', 'read']);

try {
    require __DIR__ . '/../config/database.php';
    $devOnline = (int)$pdo->query("SELECT COUNT(*) FROM perangkat WHERE status_koneksi='online'")->fetchColumn();
    $devTotal  = (int)$pdo->query("SELECT COUNT(*) FROM perangkat")->fetchColumn();
    $senAktif  = (int)$pdo->query("SELECT COUNT(*) FROM sensor_perangkat WHERE status_sensor='Aktif'")->fetchColumn();
    $aktOn     = (int)$pdo->query("SELECT COUNT(*) FROM aktuator_perangkat WHERE status_aktuator='ON'")->fetchColumn();
    $jadAktif  = (int)$pdo->query("SELECT COUNT(*) FROM jadwal_aktuator WHERE aktif=1")->fetchColumn();
    $unreadMsg = (int)$pdo->query("SELECT COUNT(*) FROM pesan_kontak WHERE status_baca='belum_dibaca'")->fetchColumn();
    $unreadNotif = (int)$pdo->query("SELECT COUNT(*) FROM notifikasi WHERE dibaca=0")->fetchColumn();

    $latestRows = $pdo->query("SELECT kode_sensor, nilai_sensor, waktu_pencatatan FROM v_sensor_terakhir WHERE id_perangkat=1")->fetchAll();
    $latest = ['suhu' => null, 'kelembapan_udara' => null, 'kelembapan_tanah' => null];
    foreach ($latestRows as $r) {
        if ($r['kode_sensor'] === 'TEMP') $latest['suhu'] = $r['nilai_sensor'];
        if ($r['kode_sensor'] === 'HUM')  $latest['kelembapan_udara'] = $r['nilai_sensor'];
        if ($r['kode_sensor'] === 'SOIL') $latest['kelembapan_tanah'] = $r['nilai_sensor'];
    }

    $recentActivity = $pdo->query("SELECT la.jenis_aktivitas, la.deskripsi, DATE_FORMAT(la.waktu_aktivitas,'%d-%m-%Y %H:%i:%s') AS waktu, u.username FROM log_aktivitas la LEFT JOIN users u ON u.id_user=la.id_user ORDER BY la.id_aktivitas DESC LIMIT 8")->fetchAll();
    $notifications  = $pdo->query("SELECT id_notifikasi, judul, pesan, tingkat, dibaca, DATE_FORMAT(created_at,'%d-%m-%Y %H:%i') AS waktu FROM notifikasi ORDER BY id_notifikasi DESC LIMIT 5")->fetchAll();

    echo json_encode([
        'ok' => true,
        'kpi' => [
            'devices_online' => $devOnline,
            'devices_total'  => $devTotal,
            'sensors_active' => $senAktif,
            'actuators_on'   => $aktOn,
            'schedules_active' => $jadAktif,
            'unread_messages'  => $unreadMsg,
            'unread_notifications' => $unreadNotif,
        ],
        'latest' => $latest,
        'recent_activity' => $recentActivity,
        'notifications' => $notifications,
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
