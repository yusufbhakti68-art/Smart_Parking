<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
bm_require_roles(['admin']);

try {
    require __DIR__ . '/../config/database.php';
    $roles = $pdo->query("SELECT * FROM hak_akses ORDER BY id_role ASC")->fetchAll();
    $perms = $pdo->query("SELECT * FROM permission ORDER BY id_permission ASC")->fetchAll();
    $maps  = $pdo->query("SELECT * FROM role_permission")->fetchAll();
    echo json_encode(['ok' => true, 'roles' => $roles, 'permissions' => $perms, 'mappings' => $maps]);
} catch (Throwable $e) {
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
