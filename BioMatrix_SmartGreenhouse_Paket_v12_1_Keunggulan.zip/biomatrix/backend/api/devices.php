<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';
    $method = $_SERVER['REQUEST_METHOD'];

    if ($method === 'GET') {
        bm_require_roles(['admin', 'editor', 'read']);
        $rows = $pdo->query("SELECT p.*, pp.mode_sistem, pp.interval_update FROM perangkat p LEFT JOIN pengaturan_perangkat pp ON pp.id_perangkat=p.id_perangkat ORDER BY p.id_perangkat ASC")->fetchAll();
        echo json_encode(['ok' => true, 'devices' => $rows]);
        exit;
    }

    bm_verify_csrf();
    $user = bm_require_roles(['admin']);
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $action = $in['action'] ?? ($method === 'DELETE' ? 'delete' : 'save');

    if ($action === 'delete') {
        $id = (int)($in['id_perangkat'] ?? 0);
        if ($id <= 1) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Perangkat utama tidak dapat dihapus']); exit; }
        $pdo->prepare("DELETE FROM perangkat WHERE id_perangkat=?")->execute([$id]);
        bm_log_activity($pdo, $user['id_user'], 'DELETE_DEVICE', "Menghapus perangkat ID #{$id}");
        echo json_encode(['ok' => true, 'message' => 'Perangkat berhasil dihapus']);
        exit;
    }

    $id = (int)($in['id_perangkat'] ?? 0);
    $kode = trim((string)($in['kode_perangkat'] ?? ''));
    $nama = trim((string)($in['nama_perangkat'] ?? ''));
    $fw   = trim((string)($in['versi_firmware'] ?? 'v1.3.0'));
    $hb   = max(5, (int)($in['heartbeat_interval'] ?? 10));

    if ($id > 0) {
        $pdo->prepare("UPDATE perangkat SET nama_perangkat=?, versi_firmware=?, heartbeat_interval=? WHERE id_perangkat=?")->execute([$nama, $fw, $hb, $id]);
        bm_log_activity($pdo, $user['id_user'], 'UPDATE_DEVICE', "Memperbarui perangkat {$nama}");
        echo json_encode(['ok' => true, 'message' => 'Perangkat berhasil diperbarui']);
    } else {
        if ($kode === '' || $nama === '') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Kode dan nama perangkat wajib diisi']); exit; }
        $tokenPlain = bin2hex(random_bytes(16));
        $tokenHash  = hash('sha256', $tokenPlain);
        $pdo->prepare("INSERT INTO perangkat (kode_perangkat, nama_perangkat, versi_firmware, device_token_hash, heartbeat_interval, status_koneksi) VALUES (?, ?, ?, ?, ?, 'offline')")
            ->execute([$kode, $nama, $fw, $tokenHash, $hb]);
        $newId = (int)$pdo->lastInsertId();
        $pdo->prepare("INSERT IGNORE INTO pengaturan_perangkat (id_perangkat, mode_sistem, interval_update) VALUES (?, 'Otomatis', 5)")->execute([$newId]);
        bm_log_activity($pdo, $user['id_user'], 'ADD_DEVICE', "Menambahkan perangkat {$kode} ({$nama})");
        echo json_encode(['ok' => true, 'message' => "Perangkat {$kode} ditambahkan", 'device_token' => $tokenPlain]);
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
