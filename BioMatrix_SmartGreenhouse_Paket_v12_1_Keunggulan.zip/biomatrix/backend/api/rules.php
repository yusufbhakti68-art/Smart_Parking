<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        bm_require_roles(['admin', 'editor', 'read']);
        $rows = $pdo->query("SELECT ao.*, js.nama_sensor, js.satuan, jakt.nama_aktuator
                             FROM aturan_otomatis ao
                             JOIN sensor_perangkat sp ON sp.id_sensor_perangkat=ao.id_sensor_perangkat
                             JOIN jenis_sensor js ON js.id_jenis_sensor=sp.id_jenis_sensor
                             JOIN aktuator_perangkat ap ON ap.id_aktuator=ao.id_aktuator
                             JOIN jenis_aktuator jakt ON jakt.id_jenis_aktuator=ap.id_jenis_aktuator
                             WHERE sp.is_active=1 AND ap.is_active=1
                             ORDER BY ao.prioritas ASC, ao.id_aturan DESC")->fetchAll();
        $sensors=$pdo->query("SELECT sp.id_sensor_perangkat,js.nama_sensor,js.kode_sensor,js.satuan FROM sensor_perangkat sp JOIN jenis_sensor js ON js.id_jenis_sensor=sp.id_jenis_sensor WHERE sp.is_active=1 AND sp.status_sensor='Aktif' ORDER BY sp.id_sensor_perangkat")->fetchAll();
        $actuators=$pdo->query("SELECT ap.id_aktuator,ja.nama_aktuator,ja.kode_aktuator FROM aktuator_perangkat ap JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator WHERE ap.is_active=1 ORDER BY ap.id_aktuator")->fetchAll();
        echo json_encode(['ok' => true, 'rules' => $rows, 'sensors'=>$sensors, 'actuators'=>$actuators]);
        exit;
    }

    bm_verify_csrf();
    $user = bm_require_roles(['admin', 'editor']);
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $action = $in['action'] ?? 'save';

    if ($action === 'delete') {
        $pdo->prepare("DELETE FROM aturan_otomatis WHERE id_aturan=?")->execute([(int)($in['id_aturan'] ?? 0)]);
        echo json_encode(['ok' => true, 'message' => 'Aturan otomatis dihapus']);
        exit;
    }
    if ($action === 'toggle') {
        $pdo->prepare("UPDATE aturan_otomatis SET aktif=? WHERE id_aturan=?")->execute([!empty($in['aktif']) ? 1 : 0, (int)($in['id_aturan'] ?? 0)]);
        echo json_encode(['ok' => true, 'message' => 'Status aturan diperbarui']);
        exit;
    }

    $idSp   = (int)($in['id_sensor_perangkat'] ?? 2);
    $idAkt  = (int)($in['id_aktuator'] ?? 1);
    $nama   = trim((string)($in['nama_aturan'] ?? 'Aturan Baru'));
    $op     = in_array($in['operator_kondisi'] ?? '', ['>','<','>=','<=','='], true) ? $in['operator_kondisi'] : '>';
    $ambang = (float)($in['nilai_ambang'] ?? 30);
    $tujuan = ($in['status_tujuan'] ?? 'ON') === 'ON' ? 'ON' : 'OFF';
    $hyst   = (float)($in['hysteresis'] ?? 2.0);
    $cd     = max(5, (int)($in['cooldown_detik'] ?? 30));

    $valid=$pdo->prepare("SELECT (SELECT COUNT(*) FROM sensor_perangkat WHERE id_sensor_perangkat=? AND is_active=1 AND status_sensor='Aktif') AS sensor_ok,(SELECT COUNT(*) FROM aktuator_perangkat WHERE id_aktuator=? AND is_active=1) AS actuator_ok");$valid->execute([$idSp,$idAkt]);$v=$valid->fetch();if(!(int)$v['sensor_ok']||!(int)$v['actuator_ok']){http_response_code(400);echo json_encode(['ok'=>false,'error'=>'Pilih sensor dan aktuator yang masih aktif']);exit;}
    $pdo->prepare("INSERT INTO aturan_otomatis (id_sensor_perangkat, id_aktuator, nama_aturan, operator_kondisi, nilai_ambang, status_tujuan, hysteresis, cooldown_detik, aktif) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)")
        ->execute([$idSp, $idAkt, $nama, $op, $ambang, $tujuan, $hyst, $cd]);
    bm_log_activity($pdo, $user['id_user'], 'ADD_RULE', "Menambahkan aturan {$nama} ({$op} {$ambang} -> {$tujuan})");
    echo json_encode(['ok' => true, 'message' => 'Aturan otomatis berhasil disimpan']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
