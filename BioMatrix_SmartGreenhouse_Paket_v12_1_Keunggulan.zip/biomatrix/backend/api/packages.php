<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        echo json_encode(['ok' => true, 'packages' => $pdo->query("SELECT * FROM paket_komponen ORDER BY urutan ASC")->fetchAll()]);
        exit;
    }
    bm_verify_csrf();
    $user = bm_require_roles(['admin', 'editor']);
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    if (($in['action'] ?? '') === 'delete') {
        $pdo->prepare("DELETE FROM paket_komponen WHERE id_komponen=?")->execute([(int)($in['id_komponen'] ?? 0)]);
        echo json_encode(['ok' => true, 'message' => 'Komponen paket dihapus']);
        exit;
    }
    $nama = trim((string)($in['nama_komponen'] ?? ''));
    $jml  = trim((string)($in['jumlah'] ?? '1 Unit'));
    $ket  = trim((string)($in['keterangan'] ?? ''));
    $ikon = trim((string)($in['ikon'] ?? 'fa-microchip'));
    $harga = (float)($in['harga'] ?? 0);
    if ($nama === '') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Nama komponen wajib diisi']); exit; }
    $pdo->prepare("INSERT INTO paket_komponen (nama_komponen, jumlah, keterangan, ikon, harga, tampil) VALUES (?, ?, ?, ?, ?, 1)")
        ->execute([$nama, $jml, $ket, $ikon, $harga]);
    bm_log_activity($pdo, $user['id_user'], 'ADD_PACKAGE', "Menambahkan komponen paket: {$nama}");
    echo json_encode(['ok' => true, 'message' => 'Komponen paket ditambahkan']);
} catch (Throwable $e) {
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
