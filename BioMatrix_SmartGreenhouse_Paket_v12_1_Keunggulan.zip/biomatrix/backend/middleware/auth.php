<?php
declare(strict_types=1);
function bm_start_session(): void {
    if (session_status() === PHP_SESSION_NONE) {
        ini_set('session.use_strict_mode','1');
        ini_set('session.use_only_cookies','1');
        $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
        session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>$isHttps,'httponly'=>true,'samesite'=>'Lax']);
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
function bm_current_user(): ?array {
    bm_start_session();
    if (empty($_SESSION['bm_user']['id_user'])) return null;
    try {
        if (!isset($GLOBALS['pdo'])) { require __DIR__ . '/../config/database.php'; $GLOBALS['pdo']=$pdo; }
        $pdo=$GLOBALS['pdo'];
        $q=$pdo->prepare("SELECT id_user,username,nama_lengkap,role,status_akun,deleted_at FROM users WHERE id_user=? LIMIT 1");
        $q->execute([(int)$_SESSION['bm_user']['id_user']]); $fresh=$q->fetch();
        if (!$fresh || ($fresh['status_akun']??'nonaktif')!=='aktif' || !empty($fresh['deleted_at'])) {
            $_SESSION=[]; session_destroy(); return null;
        }
        $_SESSION['bm_user']=['id_user'=>(int)$fresh['id_user'],'username'=>$fresh['username'],'nama_lengkap'=>$fresh['nama_lengkap'],'role'=>$fresh['role']];
        return $_SESSION['bm_user'];
    } catch (Throwable $e) { error_log('BioMatrix session validation failed: '.$e->getMessage()); $_SESSION=[]; if(session_status()===PHP_SESSION_ACTIVE)session_destroy(); return null; }
}
function bm_require_auth(): array {
    $user=bm_current_user();
    if (!$user) { http_response_code(401); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok'=>false,'error'=>'Sesi tidak valid atau akun tidak aktif.']); exit; }
    return $user;
}
