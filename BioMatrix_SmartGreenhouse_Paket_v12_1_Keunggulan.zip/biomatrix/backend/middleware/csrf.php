<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';
function bm_verify_csrf(): void {
    bm_start_session();
    $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
    if (in_array($method, ['GET','HEAD','OPTIONS'], true)) return;
    $header = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    $sessionToken = (string)($_SESSION['csrf_token'] ?? '');
    if ($header === '' || $sessionToken === '' || !hash_equals($sessionToken, $header)) {
        http_response_code(403);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>false,'error'=>'Token keamanan CSRF tidak ada atau tidak valid.']);
        exit;
    }
}
