<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

function bm_require_roles(array $allowedRoles): array {
    $user = bm_require_auth();
    if (!in_array($user['role'] ?? 'read', $allowedRoles, true)) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'error' => 'Akses ditolak: hak akses Anda tidak mencukupi.']);
        exit;
    }
    return $user;
}

function bm_log_activity(PDO $pdo, ?int $userId, string $jenis, string $deskripsi): void {
    try {
        $pdo->prepare("INSERT INTO log_aktivitas (id_user, jenis_aktivitas, deskripsi) VALUES (?, ?, ?)")
            ->execute([$userId, $jenis, $deskripsi]);
    } catch (Throwable $e) {}
}
