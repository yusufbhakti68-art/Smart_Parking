<?php
declare(strict_types=1);
$secureConfig='/etc/biomatrix/biomatrix.php';
if (is_readable($secureConfig)) { $cfg=require $secureConfig; }
else { $cfg=['db_host'=>getenv('BM_DB_HOST')?:null,'db_name'=>getenv('BM_DB_NAME')?:null,'db_user'=>getenv('BM_DB_USER')?:null,'db_pass'=>getenv('BM_DB_PASS')?:null,'mqtt_host'=>getenv('BM_MQTT_HOST')?:'127.0.0.1','mqtt_port'=>(int)(getenv('BM_MQTT_PORT')?:1883),'mqtt_user'=>getenv('BM_MQTT_USER')?:null,'mqtt_pass'=>getenv('BM_MQTT_PASS')?:null]; }
foreach(['db_host','db_name','db_user','db_pass'] as $key){if(!isset($cfg[$key])||$cfg[$key]===''){error_log('BioMatrix missing DB setting: '.$key);throw new RuntimeException('Konfigurasi database server belum lengkap.');}}
return $cfg;
