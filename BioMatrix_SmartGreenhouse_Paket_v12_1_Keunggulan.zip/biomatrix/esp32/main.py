from machine import ADC, Pin, SoftI2C
import time
import dht
import network
import ujson
from umqtt.simple import MQTTClient

from lcd_api import LcdApi
from i2c_lcd import I2cLcd

# =========================================================
# 1. KONFIGURASI WIFI & MQTT
# =========================================================
WIFI_SSID = "Hotspot-SMK"        # Ganti dengan nama WiFi / Hotspot Laptop
WIFI_PASSWORD = ""               # Isi password WiFi jika ada

MQTT_SERVER = "10.15.42.1"       # Ganti dengan IPv4 Laptop / Server Anda
MQTT_PORT = 1883
MQTT_USER = None       # Isi jika broker memakai autentikasi
MQTT_PASSWORD = None   # Gunakan kredensial yang sama dengan BM_MQTT_USER/PASS di server
CLIENT_ID = "biomatrix-esp32"

# TOPIC MQTT (Sinkron 100% dengan Web Dashboard & Database Worker)
TOPIC_SOIL         = b"biomatrix/sensor/tanah"
TOPIC_DHT          = b"biomatrix/sensor/dht11"
TOPIC_FAN_STATUS   = b"biomatrix/kipas"
TOPIC_PUMP_STATUS  = b"biomatrix/pompa"
TOPIC_FAN_CONTROL  = b"biomatrix/kipas/control"
TOPIC_PUMP_CONTROL = b"biomatrix/pompa/control"
TOPIC_CONFIG       = b"biomatrix/config"

# =========================================================
# 2. KONFIGURASI HARDWARE
# =========================================================
adc_pin = Pin(34)
soil_sensor = ADC(adc_pin)
soil_sensor.atten(ADC.ATTN_11DB)
soil_sensor.width(ADC.WIDTH_12BIT)

dht_sensor = dht.DHT11(Pin(4))

# LCD 1602 I2C
i2c = SoftI2C(scl=Pin(22), sda=Pin(21), freq=100000)
LCD_ADDR = 0x27

def init_lcd():
    try:
        _lcd = I2cLcd(i2c, LCD_ADDR, 2, 16)
        _lcd.clear()
        return _lcd
    except Exception as e:
        print("Gagal inisialisasi LCD:", e)
        return None

lcd = init_lcd()

# Relay (Active LOW: 0 = ON, 1 = OFF)
pump = Pin(26, Pin.OUT)
fan = Pin(27, Pin.OUT)

pump.value(1)  # OFF saat awal menyala
fan.value(1)   # OFF saat awal menyala

pump_status = "OFF"
fan_status = "OFF"
manual_pump = False
manual_fan = False
system_mode = "Otomatis"

# Kalibrasi Sensor Tanah & Ambang Batas Otomatis
VAL_DRY = 3000
VAL_WET = 1400
SOIL_THRESHOLD = 40.0
TEMP_THRESHOLD = 30.0

# Pengaman Lokal v11: Batas Maksimal Pompa ON jika koneksi server terputus (2 Menit)
# Jadwal Penyiraman Rutin: Setiap 2 Jam Sekali Hidup Selama 2 Menit
INTERVAL_JADWAL_POMPA_MS = 2 * 60 * 60 * 1000   # 2 jam = 7.200.000 ms
DURASI_POMPA_HIDUP_MS    = 2 * 60 * 1000        # 2 menit = 120.000 ms
last_scheduled_pump_ms   = time.ticks_ms()
scheduled_pump_active    = False
scheduled_pump_start_ms  = 0

temperature = 0
humidity = 0
soil_moisture = 0.0

lcd_mode = 0
last_line1 = ""
last_line2 = ""
mqtt_connected = False

# =========================================================
# 3. WIFI & MQTT SETUP (SEKALI CONNECT TERUS)
# =========================================================
def connect_wifi():
    wifi = network.WLAN(network.STA_IF)
    wifi.active(True)
    if not wifi.isconnected():
        print("Menghubungkan ke WiFi...")
        wifi.connect(WIFI_SSID, WIFI_PASSWORD)
        timeout = 20
        while not wifi.isconnected() and timeout > 0:
            print(".", end="")
            time.sleep(1)
            timeout -= 1

    if wifi.isconnected():
        print("\nWiFi Berhasil Terhubung! IP:", wifi.ifconfig()[0])
        return wifi
    else:
        print("\nGagal Terhubung WiFi")
        return None

def mqtt_callback(topic, msg):
    global manual_pump, manual_fan, pump_status, fan_status, system_mode
    global TEMP_THRESHOLD, SOIL_THRESHOLD

    print("\n[MQTT MASUK]", topic.decode(), "->", msg.decode())

    if topic == TOPIC_PUMP_CONTROL:
        command = msg.decode().strip().upper()
        if command == "ON":
            pump.value(0)
            pump_status = "ON"
            manual_pump = True
        elif command == "OFF":
            pump.value(1)
            pump_status = "OFF"
            manual_pump = True
        elif command == "AUTO":
            manual_pump = False
        if mqtt_connected:
            mqtt_client.publish(TOPIC_PUMP_STATUS, pump_status.encode())

    elif topic == TOPIC_FAN_CONTROL:
        command = msg.decode().strip().upper()
        if command == "ON":
            fan.value(0)
            fan_status = "ON"
            manual_fan = True
        elif command == "OFF":
            fan.value(1)
            fan_status = "OFF"
            manual_fan = True
        elif command == "AUTO":
            manual_fan = False
        if mqtt_connected:
            mqtt_client.publish(TOPIC_FAN_STATUS, fan_status.encode())

    elif topic == TOPIC_CONFIG:
        try:
            cfg = ujson.loads(msg.decode())
            if "mode_sistem" in cfg:
                system_mode = cfg["mode_sistem"]
                if system_mode == "Otomatis":
                    manual_pump = False
                    manual_fan = False
            if "suhu_maks" in cfg:
                TEMP_THRESHOLD = float(cfg["suhu_maks"])
            if "kelembapan_tanah_min" in cfg:
                SOIL_THRESHOLD = float(cfg["kelembapan_tanah_min"])
        except Exception as e:
            print("Gagal baca config:", e)

wifi = connect_wifi()
if wifi is None:
    raise Exception("WiFi gagal terhubung!")

print("Menghubungkan ke Broker MQTT...")
mqtt_client = MQTTClient(CLIENT_ID, MQTT_SERVER, port=MQTT_PORT, user=MQTT_USER, password=MQTT_PASSWORD, keepalive=60)
mqtt_client.set_callback(mqtt_callback)

try:
    mqtt_client.connect()
    mqtt_client.subscribe(TOPIC_FAN_CONTROL)
    mqtt_client.subscribe(TOPIC_PUMP_CONTROL)
    mqtt_client.subscribe(TOPIC_CONFIG)
    mqtt_connected = True
    print("MQTT & Subscribe Berhasil!")
except Exception as e:
    mqtt_connected = False
    print("Gagal Koneksi MQTT:", e)

# =========================================================
# 4. FUNGSI SENSOR & HELPER AMAN LCD
# =========================================================
def read_filtered_adc(samples=10):
    total = 0
    valid_count = 0
    for _ in range(samples):
        val = soil_sensor.read()
        if val >= 100:
            total += val
            valid_count += 1
        time.sleep_ms(20)
    if valid_count == 0:
        return None
    return int(total / valid_count)

def calculate_moisture(raw_val):
    if raw_val is None:
        return 0.0
    percentage = ((VAL_DRY - raw_val) / (VAL_DRY - VAL_WET)) * 100.0
    percentage = max(0.0, min(100.0, percentage))
    return round(percentage, 1)

def print_lcd_smart(line1, line2):
    global lcd, last_line1, last_line2

    if lcd is None:
        lcd = init_lcd()
        if lcd is None:
            return

    str1 = (line1 + "                ")[:16]
    str2 = (line2 + "                ")[:16]

    if str1 != last_line1 or str2 != last_line2:
        try:
            lcd.move_to(0, 0)
            lcd.putstr(str1)
            lcd.move_to(0, 1)
            lcd.putstr(str2)
            last_line1 = str1
            last_line2 = str2
        except Exception as e:
            print("[LCD Glitch] Mencoba Re-init I2C...", e)
            lcd = init_lcd()

# =========================================================
# 5. PROGRAM UTAMA
# =========================================================
print("=== Biomatrix IoT Active ===")

last_sensor_read = 0
sensor_interval = 2000   # Pembacaan sensor & publish MQTT tetap cepat (2 detik)

last_lcd_transition = 0
lcd_interval = 10000     # Transisi berganti tampilan LCD pas 10 DETIK

while True:
    try:
        # Cek perintah MQTT masuk (sekali connect terus tanpa reconnect berulang-ulang)
        if mqtt_connected:
            mqtt_client.check_msg()

        current_time = time.ticks_ms()

        # 0. Logika Jadwal Rutin Pompa: Setiap 2 Jam Sekali Hidup Selama 2 Menit
        if not scheduled_pump_active:
            if time.ticks_diff(current_time, last_scheduled_pump_ms) >= INTERVAL_JADWAL_POMPA_MS:
                scheduled_pump_active = True
                scheduled_pump_start_ms = current_time
                last_scheduled_pump_ms = current_time
                pump.value(0)
                pump_status = "ON"
                print("[JADWAL 2 JAM] Pompa menyala otomatis selama 2 menit!")
                if mqtt_connected:
                    mqtt_client.publish(TOPIC_PUMP_STATUS, b"ON")
        else:
            if time.ticks_diff(current_time, scheduled_pump_start_ms) >= DURASI_POMPA_HIDUP_MS:
                scheduled_pump_active = False
                if not manual_pump:
                    pump.value(1)
                    pump_status = "OFF"
                print("[JADWAL 2 JAM] Durasi 2 menit selesai, pompa dimatikan.")
                if mqtt_connected:
                    mqtt_client.publish(TOPIC_PUMP_STATUS, pump_status.encode())

        # 1. Pembacaan Sensor & MQTT (Setiap 2 Detik)
        if time.ticks_diff(current_time, last_sensor_read) >= sensor_interval:
            last_sensor_read = current_time

            raw_adc = read_filtered_adc(samples=10)
            soil_moisture = calculate_moisture(raw_adc)

            try:
                dht_sensor.measure()
                temperature = dht_sensor.temperature()
                humidity = dht_sensor.humidity()
            except OSError:
                print("Peringatan: Gagal baca DHT11")

            # Otomatisasi Relay (Jika tidak sedang jadwal 2 jam & tidak di-override manual)
            if not manual_pump and not scheduled_pump_active and system_mode == "Otomatis":
                if soil_moisture < SOIL_THRESHOLD:
                    pump.value(0)
                    pump_status = "ON"
                else:
                    pump.value(1)
                    pump_status = "OFF"

            if not manual_fan and system_mode == "Otomatis":
                if temperature > TEMP_THRESHOLD:
                    fan.value(0)
                    fan_status = "ON"
                else:
                    fan.value(1)
                    fan_status = "OFF"

            # Log Serial
            print(f"Tanah: {soil_moisture}% | Suhu: {temperature}C | Humd: {humidity}% | Pompa: {pump_status} | Kipas: {fan_status}")

            # Publish MQTT
            if mqtt_connected:
                try:
                    mqtt_client.publish(TOPIC_SOIL, str(soil_moisture).encode())
                    dht_data = ujson.dumps({"suhu": temperature, "kelembapan": humidity})
                    mqtt_client.publish(TOPIC_DHT, dht_data.encode())
                    mqtt_client.publish(TOPIC_FAN_STATUS, fan_status.encode())
                    mqtt_client.publish(TOPIC_PUMP_STATUS, pump_status.encode())
                except Exception as e:
                    print("Gagal Publish MQTT, mencoba sambung ulang...", e)
                    try:
                        mqtt_client.connect()
                        mqtt_client.subscribe(TOPIC_FAN_CONTROL)
                        mqtt_client.subscribe(TOPIC_PUMP_CONTROL)
                        mqtt_client.subscribe(TOPIC_CONFIG)
                    except Exception:
                        pass

        # 2. Transisi Tampilan LCD (Setiap 10 Detik)
        if time.ticks_diff(current_time, last_lcd_transition) >= lcd_interval:
            last_lcd_transition = current_time
            lcd_mode = 1 if lcd_mode == 0 else 0

        if lcd_mode == 0:
            l1 = "Biomatrix Smart"
            l2 = "Green House"
        else:
            l1 = f"T:{soil_moisture}% S:{temperature}C"
            l2 = f"P:{pump_status}    K:{fan_status}"

        print_lcd_smart(l1, l2)
        time.sleep_ms(20)

    except Exception as e:
        print("Error pada Loop Utama:", e)
        time.sleep(1)
