# BioMatrix Smart Greenhouse v12

## Baseline and compatibility
- Dibangun di atas paket v11; file publik, panel admin, backend API, worker MQTT, firmware, dan migrasi lama dipertahankan.
- Database lama tidak di-drop dan data lama tidak di-reset. Migration baru: `database/migrations/006_v12_management.sql`.

## Perubahan utama
1. Akun: edit username/nama/role, reset password, blokir/aktifkan, soft delete (arsip). Password tidak pernah ditampilkan; hanya hash yang disimpan.
2. Sensor: tambah jenis sensor dan pasang sensor ke perangkat utama (ID 1); simpan GPIO/topic data; edit kalibrasi/status; worker dapat menyimpan sensor tambahan yang mengirim angka ke `biomatrix/sensor/<KODE_SENSOR>`; arsipkan sensor tanpa menghapus riwayat.
3. Aktuator: tambah jenis dan registrasi pada perangkat utama (ID 1), simpan topic MQTT/GPIO; jadwal dan aturan otomatis memakai topic yang tersimpan; arsipkan tanpa menghapus riwayat.
4. Media: upload gambar ke server (JPG/PNG/WEBP/GIF, maksimal 8 MB) atau URL HTTP/HTTPS manual. SVG ditolak. Nama media dapat dipilih sebagai background pada editor CMS; URL manual tetap tersedia.
5. Navigasi publik: halaman kustom dapat ditambahkan ke menu desktop/mobile dari admin.
6. Maintenance: aktifkan untuk website publik. `/admin/` tetap tersedia. API, MQTT, worker, dan jadwal tidak dihentikan oleh maintenance.
7. Keamanan: CSRF wajib untuk mutasi, session cookie HttpOnly/SameSite, pemeriksaan ulang status akun pada sesi, rahasia DB melalui environment untuk PHP dan worker MQTT, autentikasi broker opsional, Nginx membatasi file internal, dan tidak ada seeding password default pada deploy.

## Batasan penting
- Menambahkan record sensor/aktuator ke database tidak otomatis menambah kemampuan hardware. Sensor baru harus dipublikasikan firmware pada `biomatrix/sensor/<KODE_SENSOR>` (payload angka; worker v12 menyimpan otomatis berdasarkan kode). Aktuator baru harus mendengarkan `topic_control` dan memublikasikan status ke `biomatrix/actuator/<KODE_AKTUATOR>`; GPIO/topic tetap harus dipetakan pada firmware. Perangkat v11 tetap beroperasi seperti sebelumnya. Pendaftaran IoT baru pada v12 saat ini dibatasi pada perangkat utama ID 1; dukungan multi-perangkat penuh memerlukan perluasan identitas topic dan worker.
- Frontend HTML/CSS/JS yang dikirim ke browser dapat dilihat/disimpan. Tidak mungkin menjamin 100% tidak disalin. Logika sensitif dan kredensial harus berada di server; minifikasi/obfuscation hanya mempersulit, bukan mencegah penyalinan.
- Maintenance diproteksi server-side melalui flag Nginx: halaman publik dialihkan ke maintenance.html sebelum konten utama dikirim; `/admin/` dan `/api/` tetap dapat diakses.
- Penghapusan akun menggunakan soft delete; data historis dan relasi tidak dihapus.
- Migrasi 006 diasumsikan database `biomatrix` yang sudah melalui migrasi v11 (001-005). Jangan menjalankan SQL dasar v7 pada database yang sudah berisi data karena file dasar v7 memiliki `DROP DATABASE`.

## Pemeriksaan sebelum produksi
- Ganti password database dan simpan di `/etc/biomatrix/biomatrix.env` dengan permission terbatas.
- Pastikan user DB memiliki hak minimum yang diperlukan (SELECT/INSERT/UPDATE/DELETE/CREATE/ALTER/INDEX untuk migrasi), dan jangan pakai root DB.
- Aktifkan HTTPS/TLS, firewall, backup otomatis, dan pantau log.
- Uji di staging dahulu; backup file dan database sebelum migration.


## Patch v12.1.0 — Website publik
1. Menghapus menu dan section `Simulasi Sistem` dari navigasi desktop, navigasi mobile, dan isi website publik. Penjelasan alur sistem tetap tersedia pada section `Cara Kerja`.
2. Menambahkan menu dan section `Keunggulan` dengan enam poin: kondisi terpantau, kendali terpusat, otomatisasi fleksibel, data dan riwayat, akses berbasis web, serta operasional terstruktur.
3. Memisahkan `Keunggulan` (nilai/manfaat penggunaan) dari `Fitur Sistem` (kemampuan teknis).
4. Menyesuaikan bagian `Manfaat` agar tidak mengulang isi kartu Keunggulan.
5. Menambahkan migration `007_public_site_keunggulan.sql` untuk memperbarui CMS dan menu bawaan tanpa menghapus halaman kustom atau data IoT.
