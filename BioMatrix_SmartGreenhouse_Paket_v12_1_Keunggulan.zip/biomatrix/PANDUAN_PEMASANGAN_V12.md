# Panduan Pemasangan BioMatrix v12.1

## 0. Sebelum mulai
1. Uji di server staging jika tersedia.
2. Buat backup file dan database. Jangan jalankan `database/biomatrix_v7_full.sql` pada database yang sudah ada karena skrip tersebut menghapus dan membuat ulang database.
3. Pastikan v11 sudah memakai database `biomatrix` dan migration 001-005 telah diterapkan.
4. Paket ini tidak menyertakan password admin baru dan tidak mengatur ulang password akun v11 yang sudah aktif.

## 1. Ekstrak dan salin
```bash
unzip BioMatrix_SmartGreenhouse_Paket_v12.zip
cd biomatrix
```
Salin folder `biomatrix` ke server. Jika ingin memakai script deploy:
```bash
sudo bash deploy_biomatrix.sh
```
Pada eksekusi pertama script membuat `/etc/biomatrix/biomatrix.env` dan berhenti. Edit file tersebut:
```bash
sudo nano /etc/biomatrix/biomatrix.env
```
Isi `BM_DB_HOST`, `BM_DB_NAME`, `BM_DB_USER`, `BM_DB_PASS`, `BM_MQTT_HOST`, `BM_MQTT_PORT`, dan bila diperlukan `BM_MQTT_USER`/`BM_MQTT_PASS`. Jika password mengandung karakter khusus shell seperti spasi atau `#`, bungkus nilainya dengan tanda kutip tunggal yang sesuai. Gunakan password database kuat yang sudah disiapkan di MariaDB. Jangan menaruh file env di web root atau Git.

## 2. Deploy
Jalankan ulang:
```bash
sudo bash deploy_biomatrix.sh
```
Script akan membuat backup file lama, menyalin v12, menjaga isi folder upload, menerapkan seluruh migration v11, 006, dan 007 secara berurutan, lalu memuat ulang Nginx. Script tidak menjalankan seed password default.

## 3. Jika database v11 belum dimigrasikan
Periksa dahulu status:
```bash
mysql -u USER_DB -p biomatrix -e "SHOW TABLES;"
```
Jika database sudah berisi tabel users dan tabel v11, jangan import SQL dasar. Pastikan migration 001-005 sudah diterapkan, lalu 006 dan 007.
Jika ini instalasi database baru, siapkan database dan user secara manual, import `database/biomatrix_v7_full.sql` hanya sekali, lalu jalankan migration 001-007. SQL dasar ini mengandung `DROP DATABASE` dan membuat akun awal dengan hash password sementara yang sama. Setelah migrasi selesai, jalankan sekali `sudo -u www-data php /var/www/biomatrix/database/seed_passwords.php` (sesuaikan path) untuk merotasi seluruh password akun awal menjadi password acak yang hanya dicetak ke terminal. Jangan jalankan script ini pada upgrade v11; script akan menolak mengubah akun yang password-nya sudah tersetel.

## 4. Pemeriksaan
```bash
sudo nginx -t
sudo systemctl status nginx --no-pager
sudo systemctl status php*-fpm --no-pager
curl -i http://127.0.0.1:8080/api/site-status.php
```
Buka website publik `http://IP-SERVER:8080/` dan panel admin `http://IP-SERVER:8080/admin/`.

## 5. Uji fitur v12
- Login admin dan buka Manajemen Pengguna: edit, reset password, blokir, aktifkan, arsipkan. Pastikan password lama tidak pernah ditampilkan.
- Upload JPG/PNG/WEBP/GIF maksimal 8 MB di Media. Pilih media dari editor halaman atau gunakan URL manual.
- Tambah jenis dan pasang sensor. Sensor baru v12 saat ini dipasang pada perangkat utama ID 1. Nilainya tersimpan otomatis jika firmware memublikasikan angka ke topic `biomatrix/sensor/<KODE_SENSOR>` yang sama persis dengan kode jenis sensor. Kolom GPIO hanya menyimpan konfigurasi; firmware tetap harus membaca pin tersebut.
- Tambah jenis dan daftarkan aktuator. Registrasi aktuator v12 saat ini dibatasi pada perangkat utama ID 1. Pastikan firmware berlangganan `topic_control` dan memublikasikan status ke `biomatrix/actuator/<KODE_AKTUATOR>` serta memakai GPIO yang sesuai. Jadwal dan aturan otomatis menggunakan topic_control yang tersimpan.
- Buka Maintenance Mode, aktifkan, lalu uji website publik. `/admin/` harus tetap dapat diakses. Nonaktifkan kembali setelah uji.

## 6. Catatan keamanan
- Gunakan HTTPS/TLS sebelum dipakai melalui internet.
- Ganti password akun admin/pengelola dari panel. Password minimal 10 karakter untuk pembuatan/reset akun melalui v12.
- Batasi port database dan MQTT hanya untuk host yang membutuhkan. Jangan expose broker tanpa autentikasi. Jika mengaktifkan `BM_MQTT_USER`/`BM_MQTT_PASS`, masukkan pasangan yang sama ke `MQTT_USER`/`MQTT_PASSWORD` pada `esp32/main.py` lalu unggah ulang firmware ESP32.
- Atur backup terjadwal dan simpan backup di luar server web.
- Kode frontend yang diunduh browser tidak dapat dijaga agar 100% tidak disalin. Jangan pernah menyimpan secret di HTML/JS.

## 7. Rollback
Jika terjadi masalah, hentikan perubahan dan pulihkan backup file/database yang dibuat sebelum deploy. Migration menambah kolom/tabel dan tidak menghapus data, tetapi rollback manual tetap perlu diuji terhadap versi MariaDB dan keadaan database aktual.


## 8. Perubahan website publik pada v12.1
- Menu dan section `Simulasi Sistem` dihapus karena alur arsitektur sudah dijelaskan pada `Cara Kerja`.
- Bagian `Keunggulan` ditambahkan sebagai section tersendiri dengan enam kartu manfaat produk.
- Bagian `Fitur Sistem` tetap dipertahankan untuk menjelaskan kemampuan teknis.
- Migration `007_public_site_keunggulan.sql` menghapus hanya record bawaan `simulasi` (`is_custom=0`), menambahkan konten `keunggulan`, dan merapikan navigasi bawaan. Halaman kustom buatan admin tidak dihapus.
