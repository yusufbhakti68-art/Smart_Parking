<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli') { http_response_code(404); exit("Not found\n"); }
require __DIR__ . '/../backend/config/database.php';
$defaultHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi';
$rows = $pdo->query("SELECT id_user,username,password_hash,password_changed_at FROM users WHERE deleted_at IS NULL ORDER BY id_user")->fetchAll();
if (!$rows) {
    $password = bin2hex(random_bytes(12));
    $pdo->prepare("INSERT INTO users(username,nama_lengkap,password_hash,role,status_akun,password_changed_at) VALUES('admin','Administrator BioMatrix',?,'admin','aktif',NOW())")
        ->execute([password_hash($password, PASSWORD_DEFAULT)]);
    echo "Bootstrap admin dibuat. Username: admin\nPassword sementara: {$password}\nSimpan aman dan segera ubah dari panel.\n";
    exit;
}
$initialSeedOnly = true;
foreach ($rows as $row) {
    if (!hash_equals($defaultHash, (string)$row['password_hash']) || !empty($row['password_changed_at'])) {
        $initialSeedOnly = false; break;
    }
}
if (!$initialSeedOnly) {
    fwrite(STDERR, "Seed dihentikan: ditemukan akun yang sudah memiliki password tersetel. Tidak ada password yang diubah.\n");
    exit(2);
}
$pdo->beginTransaction();
try {
    foreach ($rows as $row) {
        $password = bin2hex(random_bytes(12));
        $pdo->prepare("UPDATE users SET password_hash=?,password_changed_at=NOW() WHERE id_user=?")
            ->execute([password_hash($password, PASSWORD_DEFAULT), $row['id_user']]);
        echo $row['username'] . " | password sementara: " . $password . "\n";
    }
    $pdo->commit();
    echo "Password akun awal berhasil dirotasi satu kali. Simpan hasil ini dan segera ganti password.\n";
} catch (Throwable $e) {
    $pdo->rollBack();
    fwrite(STDERR, "Rotasi password gagal: " . $e->getMessage() . "\n");
    exit(1);
}
