-- BioMatrix v12.1 public website refinement.
-- Safe for an existing v12 database: no database/table reset and no custom page deletion.
USE biomatrix;

-- Remove the built-in Simulation menu/section. Custom pages are deliberately untouched.
DELETE FROM halaman_navigasi WHERE slug='simulasi' OR target_section='simulasi';
DELETE FROM konten_website WHERE kunci_bagian='simulasi' AND is_custom=0;

-- Add the new Keunggulan section for the public website and CMS editor.
INSERT INTO konten_website
    (kunci_bagian, judul, subjudul, deskripsi, url_gambar, bg_size, bg_blur, bg_darkness, tampil, is_custom, urutan, status_publikasi)
VALUES
    ('keunggulan', 'Keunggulan BioMatrix', 'KEUNGGULAN BIOMATRIX',
     'BioMatrix menghubungkan pemantauan kondisi, pengendalian perangkat, dan informasi operasional agar pengelolaan greenhouse lebih mudah dipahami dan terarah.',
     '', 'cover', 0, 35, 1, 0, 7, 'published')
ON DUPLICATE KEY UPDATE
    judul=VALUES(judul), subjudul=VALUES(subjudul), deskripsi=VALUES(deskripsi),
    is_custom=0, urutan=7;

-- Keep the CMS ordering aligned with the public page.
UPDATE konten_website SET urutan=6 WHERE kunci_bagian='tentang' AND is_custom=0;
UPDATE konten_website SET urutan=7 WHERE kunci_bagian='keunggulan' AND is_custom=0;
UPDATE konten_website SET urutan=8 WHERE kunci_bagian='fitur' AND is_custom=0;
UPDATE konten_website SET urutan=9 WHERE kunci_bagian='cara-kerja' AND is_custom=0;
UPDATE konten_website SET urutan=10 WHERE kunci_bagian='manfaat' AND is_custom=0;
UPDATE konten_website SET urutan=11 WHERE kunci_bagian='galeri-faq' AND is_custom=0;

-- Normalize built-in navigation records. Custom records (sec-*) remain unchanged.
DELETE FROM halaman_navigasi WHERE slug IN ('galeri','faq');
INSERT INTO halaman_navigasi (label, slug, target_section, urutan, tampil)
VALUES ('Galeri & FAQ', 'galeri-faq', 'galeri-faq', 9, 1)
ON DUPLICATE KEY UPDATE label=VALUES(label), target_section=VALUES(target_section), urutan=VALUES(urutan), tampil=1;

INSERT INTO halaman_navigasi (label, slug, target_section, urutan, tampil)
VALUES ('Keunggulan', 'keunggulan', 'keunggulan', 3, 1)
ON DUPLICATE KEY UPDATE label=VALUES(label), target_section=VALUES(target_section), urutan=VALUES(urutan), tampil=1;

UPDATE halaman_navigasi SET label='Tentang BioMatrix', target_section='tentang', urutan=2 WHERE slug='tentang';
UPDATE halaman_navigasi SET label='Inovasi', target_section='inovasi', urutan=4 WHERE slug='inovasi';
UPDATE halaman_navigasi SET label='Fitur Sistem', target_section='fitur', urutan=5 WHERE slug='fitur';
UPDATE halaman_navigasi SET label='Cara Kerja', target_section='cara-kerja', urutan=6 WHERE slug='cara-kerja';
UPDATE halaman_navigasi SET label='Manfaat', target_section='manfaat', urutan=7 WHERE slug='manfaat';
UPDATE halaman_navigasi SET label='Paket Perangkat', target_section='paket', urutan=8 WHERE slug='paket';
UPDATE halaman_navigasi SET label='Galeri & FAQ', target_section='galeri-faq', urutan=9 WHERE slug='galeri-faq';
UPDATE halaman_navigasi SET label='Live Monitoring', target_section='live-monitoring', urutan=10 WHERE slug='live-monitoring';
UPDATE halaman_navigasi SET label='Kontak', target_section='kontak', urutan=11 WHERE slug='kontak';

UPDATE pengaturan_sistem SET nilai='12.1.0' WHERE kunci='site_version';
