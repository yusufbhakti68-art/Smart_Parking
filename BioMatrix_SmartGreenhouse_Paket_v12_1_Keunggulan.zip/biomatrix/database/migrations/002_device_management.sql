-- Migration 002: Device Token, Sensor Calibration & Command Queue
USE biomatrix;

CREATE TABLE IF NOT EXISTS perintah_perangkat (
    id_perintah BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_perangkat BIGINT UNSIGNED NOT NULL,
    id_aktuator BIGINT UNSIGNED NULL,
    topic_mqtt VARCHAR(120) NOT NULL,
    payload VARCHAR(255) NOT NULL,
    status_perintah ENUM('antre','terkirim','dikonfirmasi','gagal','kedaluwarsa') NOT NULL DEFAULT 'antre',
    sumber ENUM('Manual','Otomatis','Jadwal','Sistem') NOT NULL DEFAULT 'Manual',
    dibuat_oleh BIGINT UNSIGNED NULL,
    dibuat_pada DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dikonfirmasi_pada DATETIME NULL,
    INDEX idx_pp_status (id_perangkat, status_perintah),
    CONSTRAINT fk_cmd_dev FOREIGN KEY (id_perangkat) REFERENCES perangkat(id_perangkat) ON DELETE CASCADE,
    CONSTRAINT fk_cmd_user FOREIGN KEY (dibuat_oleh) REFERENCES users(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS status_sensor_kalibrasi (
    id_kalibrasi BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_sensor_perangkat BIGINT UNSIGNED NOT NULL,
    nilai_min DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    nilai_max DECIMAL(10,2) NOT NULL DEFAULT 100.00,
    offset_kalibrasi DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    catatan VARCHAR(255) NULL,
    diubah_oleh BIGINT UNSIGNED NULL,
    diubah_pada DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_kal_sp FOREIGN KEY (id_sensor_perangkat) REFERENCES sensor_perangkat(id_sensor_perangkat) ON DELETE CASCADE,
    CONSTRAINT fk_kal_user FOREIGN KEY (diubah_oleh) REFERENCES users(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

SET @c = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='perangkat' AND COLUMN_NAME='device_token_hash');
SET @s = IF(@c=0, "ALTER TABLE perangkat ADD COLUMN device_token_hash VARCHAR(255) NULL AFTER versi_firmware, ADD COLUMN heartbeat_interval INT UNSIGNED NOT NULL DEFAULT 10 AFTER status_koneksi", "SELECT 1");
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @c = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='sensor_perangkat' AND COLUMN_NAME='nilai_min');
SET @s = IF(@c=0, "ALTER TABLE sensor_perangkat ADD COLUMN nilai_min DECIMAL(10,2) NOT NULL DEFAULT 0.00, ADD COLUMN nilai_max DECIMAL(10,2) NOT NULL DEFAULT 100.00, ADD COLUMN offset_kalibrasi DECIMAL(10,2) NOT NULL DEFAULT 0.00", "SELECT 1");
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @c = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='aktuator_perangkat' AND COLUMN_NAME='waktu_timeout');
SET @s = IF(@c=0, "ALTER TABLE aktuator_perangkat ADD COLUMN waktu_timeout INT UNSIGNED NOT NULL DEFAULT 120, ADD COLUMN status_konfirmasi ENUM('menunggu','dikonfirmasi','gagal') NOT NULL DEFAULT 'dikonfirmasi'", "SELECT 1");
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
