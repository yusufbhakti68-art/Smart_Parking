-- Migration 004: CMS Media, Content History, Draft/Publish & Package Fields
USE biomatrix;

CREATE TABLE IF NOT EXISTS media_website (
    id_media BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nama_file VARCHAR(150) NOT NULL,
    url_file VARCHAR(500) NOT NULL,
    tipe_file VARCHAR(40) NOT NULL DEFAULT 'image/jpeg',
    kategori VARCHAR(40) NOT NULL DEFAULT 'galeri',
    diunggah_oleh BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mw_user FOREIGN KEY (diunggah_oleh) REFERENCES users(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS riwayat_perubahan_konten (
    id_riwayat BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kunci_bagian VARCHAR(50) NOT NULL,
    judul_lama VARCHAR(150) NULL,
    judul_baru VARCHAR(150) NULL,
    status_publikasi ENUM('draft','published') NOT NULL DEFAULT 'published',
    diubah_oleh BIGINT UNSIGNED NULL,
    waktu_ubah DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_rpk_user FOREIGN KEY (diubah_oleh) REFERENCES users(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

SET @c = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='konten_website' AND COLUMN_NAME='status_publikasi');
SET @s = IF(@c=0, "ALTER TABLE konten_website ADD COLUMN slug VARCHAR(80) NULL AFTER kunci_bagian, ADD COLUMN tipe_bagian VARCHAR(40) NOT NULL DEFAULT 'section' AFTER slug, ADD COLUMN status_publikasi ENUM('draft','published') NOT NULL DEFAULT 'published' AFTER tampil", "SELECT 1");
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

SET @c = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='paket_komponen' AND COLUMN_NAME='harga');
SET @s = IF(@c=0, "ALTER TABLE paket_komponen ADD COLUMN gambar VARCHAR(500) NULL, ADD COLUMN harga DECIMAL(12,2) NOT NULL DEFAULT 0.00, ADD COLUMN tampil BOOLEAN NOT NULL DEFAULT TRUE", "SELECT 1");
PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

INSERT IGNORE INTO media_website (id_media, nama_file, url_file, tipe_file, kategori) VALUES
(1, 'Hero Pegunungan Sejuk', 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&q=85&w=1920', 'image/jpeg', 'background'),
(2, 'Greenhouse BioMatrix Utama', 'https://i.ibb.co.com/YFFkbq2N/greenhouse.png', 'image/png', 'galeri'),
(3, 'Ventilasi Alami Greenhouse', 'https://i.ibb.co.com/tMDKPwPb/Natural-Ventilation-2-11zon-1024x685.jpg', 'image/jpeg', 'galeri'),
(4, 'Curug & Alam Sejuk', 'https://images.unsplash.com/photo-1432405972618-c60b0225b8f9?auto=format&fit=crop&q=85&w=1000', 'image/jpeg', 'background');
