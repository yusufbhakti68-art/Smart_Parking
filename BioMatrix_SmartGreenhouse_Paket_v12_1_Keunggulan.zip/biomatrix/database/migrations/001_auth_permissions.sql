-- Migration 001: Auth, Permissions & User Sessions (Backward-Compatible)
USE biomatrix;

CREATE TABLE IF NOT EXISTS hak_akses (
    id_role INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode_role VARCHAR(30) NOT NULL UNIQUE,
    nama_role VARCHAR(60) NOT NULL,
    deskripsi VARCHAR(255) NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS permission (
    id_permission INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode_permission VARCHAR(60) NOT NULL UNIQUE,
    nama_permission VARCHAR(100) NOT NULL,
    grup VARCHAR(40) NOT NULL DEFAULT 'Umum'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS role_permission (
    id_role INT UNSIGNED NOT NULL,
    id_permission INT UNSIGNED NOT NULL,
    PRIMARY KEY (id_role, id_permission),
    CONSTRAINT fk_rp_role FOREIGN KEY (id_role) REFERENCES hak_akses(id_role) ON DELETE CASCADE,
    CONSTRAINT fk_rp_perm FOREIGN KEY (id_permission) REFERENCES permission(id_permission) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sesi_pengguna (
    id_sesi VARCHAR(128) PRIMARY KEY,
    id_user BIGINT UNSIGNED NOT NULL,
    ip_address VARCHAR(45) NULL,
    device_info VARCHAR(150) NULL,
    expires_at DATETIME NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_sp_user FOREIGN KEY (id_user) REFERENCES users(id_user) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Tambah kolom status_akun & updated_at pada users jika belum ada
SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='users' AND COLUMN_NAME='status_akun');
SET @sql = IF(@col_exists = 0, "ALTER TABLE users ADD COLUMN status_akun ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif' AFTER role", "SELECT 1");
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @col_exists = (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='users' AND COLUMN_NAME='updated_at');
SET @sql = IF(@col_exists = 0, "ALTER TABLE users ADD COLUMN updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at", "SELECT 1");
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

INSERT IGNORE INTO hak_akses (id_role, kode_role, nama_role, deskripsi) VALUES
(1, 'admin', 'Administrator', 'Kendali penuh atas seluruh sistem IoT, CMS website, akun, dan keamanan'),
(2, 'editor', 'Pengelola / Editor', 'Operasional greenhouse, kontrol aktuator, jadwal, sensor, dan konten'),
(3, 'read', 'Viewer (Lihat Saja)', 'Hanya dapat memantau dashboard, grafik, dan riwayat data tanpa mengubah');

INSERT IGNORE INTO permission (kode_permission, nama_permission, grup) VALUES
('dashboard.view', 'Lihat Dashboard & Monitoring', 'Overview'),
('devices.manage', 'Kelola Perangkat IoT', 'Greenhouse'),
('sensors.manage', 'Kelola Sensor & Kalibrasi', 'Greenhouse'),
('actuators.control', 'Kontrol Kipas & Pompa', 'Greenhouse'),
('schedules.manage', 'Kelola Jadwal Otomatis', 'Greenhouse'),
('rules.manage', 'Kelola Aturan Otomatis', 'Greenhouse'),
('reports.export', 'Ekspor Laporan CSV/PDF', 'Data'),
('cms.manage', 'Kelola Halaman, Media & Paket', 'Website'),
('messages.manage', 'Kelola Pesan Pengunjung', 'Website'),
('users.manage', 'Kelola Akun & Hak Akses', 'Sistem'),
('settings.manage', 'Pengaturan Global & Keamanan', 'Sistem');

-- Berikan semua izin ke Admin (id_role=1)
INSERT IGNORE INTO role_permission (id_role, id_permission)
SELECT 1, id_permission FROM permission;

-- Berikan izin operasional ke Editor (id_role=2)
INSERT IGNORE INTO role_permission (id_role, id_permission)
SELECT 2, id_permission FROM permission
WHERE kode_permission IN ('dashboard.view','sensors.manage','actuators.control','schedules.manage','rules.manage','reports.export','cms.manage','messages.manage');

-- Berikan izin lihat saja ke Viewer (id_role=3)
INSERT IGNORE INTO role_permission (id_role, id_permission)
SELECT 3, id_permission FROM permission
WHERE kode_permission IN ('dashboard.view');
