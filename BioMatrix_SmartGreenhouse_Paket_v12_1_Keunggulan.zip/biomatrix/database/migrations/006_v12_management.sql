-- BioMatrix v12 migration 006 (backward-compatible; does not drop or reset existing data)
USE biomatrix;

SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='deleted_at');
SET @s=IF(@c=0,"ALTER TABLE users ADD COLUMN deleted_at DATETIME NULL AFTER updated_at", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='password_changed_at');
SET @s=IF(@c=0,"ALTER TABLE users ADD COLUMN password_changed_at DATETIME NULL AFTER deleted_at", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='sensor_perangkat' AND COLUMN_NAME='is_active');
SET @s=IF(@c=0,"ALTER TABLE sensor_perangkat ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='aktuator_perangkat' AND COLUMN_NAME='is_active');
SET @s=IF(@c=0,"ALTER TABLE aktuator_perangkat ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='sensor_perangkat' AND COLUMN_NAME='pin_gpio');
SET @s=IF(@c=0,"ALTER TABLE sensor_perangkat ADD COLUMN pin_gpio SMALLINT NULL, ADD COLUMN topic_data VARCHAR(190) NULL", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='aktuator_perangkat' AND COLUMN_NAME='topic_control');
SET @s=IF(@c=0,"ALTER TABLE aktuator_perangkat ADD COLUMN topic_control VARCHAR(190) NULL, ADD COLUMN pin_gpio SMALLINT NULL", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='konten_website' AND COLUMN_NAME='id_media_background');
SET @s=IF(@c=0,"ALTER TABLE konten_website ADD COLUMN id_media_background BIGINT UNSIGNED NULL", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='konten_website' AND INDEX_NAME='idx_kw_media');
SET @s=IF(@c=0,"ALTER TABLE konten_website ADD INDEX idx_kw_media (id_media_background)", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;
SET @c=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='media_website' AND COLUMN_NAME='storage_name');
SET @s=IF(@c=0,"ALTER TABLE media_website ADD COLUMN storage_name VARCHAR(255) NULL, ADD COLUMN file_size BIGINT UNSIGNED NULL, ADD COLUMN checksum_sha256 CHAR(64) NULL", "SELECT 1"); PREPARE st FROM @s; EXECUTE st; DEALLOCATE PREPARE st;

CREATE TABLE IF NOT EXISTS halaman_navigasi (
 id_nav BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 label VARCHAR(80) NOT NULL,
 slug VARCHAR(100) NOT NULL UNIQUE,
 target_section VARCHAR(100) NOT NULL,
 urutan INT UNSIGNED NOT NULL DEFAULT 1,
 tampil TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO halaman_navigasi(label,slug,target_section,urutan,tampil) VALUES
('Beranda','home','home',1,1),('Tentang BioMatrix','tentang','tentang',2,1),('Inovasi','inovasi','inovasi',3,1),
('Fitur Unggulan','fitur','fitur',4,1),('Cara Kerja','cara-kerja','cara-kerja',5,1),('Manfaat','manfaat','manfaat',6,1),
('Paket Perangkat','paket','paket',7,1),('Galeri','galeri','galeri',8,1),('Live Monitoring','live-monitoring','live-monitoring',9,1),
('Simulasi Sistem','simulasi','simulasi',10,1),('FAQ','faq','faq',11,1),('Kontak','kontak','kontak',12,1);

INSERT IGNORE INTO pengaturan_sistem(kunci,nilai,keterangan) VALUES
('maintenance_mode','0','Mode pemeliharaan website publik; panel /admin tetap tersedia'),
('maintenance_message','Website BioMatrix sedang dalam pemeliharaan. Silakan kembali beberapa saat lagi.','Pesan publik saat maintenance'),
('site_version','12.0.0','Versi platform');

UPDATE aktuator_perangkat ap JOIN jenis_aktuator ja ON ja.id_jenis_aktuator=ap.id_jenis_aktuator
SET ap.topic_control=CONCAT('biomatrix/',ja.kode_aktuator,'/control') WHERE ap.topic_control IS NULL OR ap.topic_control='';

UPDATE pengaturan_sistem SET nilai='12.0.0' WHERE kunci='site_version';

CREATE TABLE IF NOT EXISTS login_attempts (
 id_attempt BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) NOT NULL,
 ip_address VARCHAR(45) NOT NULL,
 attempted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_login_ip_time(ip_address,attempted_at),
 INDEX idx_login_user_time(username,attempted_at)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS public_request_limits (
 limit_key CHAR(64) PRIMARY KEY,
 window_start DATETIME NOT NULL,
 hit_count INT UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB;


INSERT IGNORE INTO konten_website(kunci_bagian,judul,subjudul,deskripsi,url_gambar,bg_size,bg_blur,bg_darkness,tampil,is_custom,urutan) VALUES
('tentang','Tentang BioMatrix','MENGENAL BIOMATRIX','Pertanian lebih terukur melalui integrasi sensor, perangkat kendali, dan pemantauan IoT.','', 'cover',0,35,1,0,6),
('fitur','Fitur Unggulan','FITUR BIOMATRIX','Monitoring sensor, kontrol perangkat, grafik, riwayat, dan otomatisasi.','', 'cover',0,35,1,0,7),
('cara-kerja','Cara Kerja Sistem','ALUR KERJA IoT','Sensor mengirim data melalui ESP32 dan MQTT menuju dashboard.','', 'cover',0,35,1,0,8),
('manfaat','Manfaat Sistem','MANFAAT BIOMATRIX','Informasi terstruktur untuk membantu pengelolaan greenhouse.','', 'cover',0,35,1,0,9),
('galeri-faq','Galeri & FAQ','GALERI PROYEK','Dokumentasi perangkat dan jawaban pertanyaan umum.','', 'cover',0,35,1,0,10),
('simulasi','Simulasi Sistem','SIMULASI IoT','Alur sensor, ESP32, MQTT, server, dan aktuator.','', 'cover',0,35,1,0,11);
