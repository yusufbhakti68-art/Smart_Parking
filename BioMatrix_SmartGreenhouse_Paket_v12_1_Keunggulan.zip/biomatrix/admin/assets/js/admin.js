// BIOMATRIX v12 — FULL CONTROL ADMIN ENGINE (PHP Session + CSRF + 22 Modules)
let csrfToken = '';
let admLiveChart = null, admHistoryChart = null;
let liveSoil = null, liveTemp = null, liveHum = null;

function showToast(msg, type = 'success') {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    el.className = `px-4 py-3 rounded-lg border text-xs font-semibold ${type === 'error' ? 'bg-[#FDECEC] border-[#F8B4B4] text-[#B91C1C]' : 'bg-[#17332A] border-[#234E3F] text-white'}`;
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(() => el.remove(), 3200);
}

async function apiGet(url) {
    const res = await fetch(url, { cache: 'no-store' });
    return await res.json();
}

async function apiPost(url, payload) {
    const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify(payload)
    });
    return await res.json();
}

async function handleAdminLogin(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    try {
        const d = await apiPost('/api/auth/login.php', { username, password });
        if (d.ok && d.user) {
            if (d.user.role !== 'admin') {
                showToast('Akun ini bukan Admin. Silakan masuk melalui Login Dashboard Pengelola.', 'error');
                await fetch('/api/auth/logout.php', { method: 'POST' });
                return;
            }
            csrfToken = d.csrf_token || '';
            openAdmin(d.user);
            return;
        }
        showToast(d.error || 'Username atau kata sandi salah!', 'error');
    } catch (err) {
        showToast('Gagal terhubung ke server API PHP.', 'error');
    }
}

function openAdmin(user) {
    document.getElementById('adminLoginScreen').classList.add('hidden');
    document.getElementById('adminApp').classList.remove('hidden');
    document.getElementById('topbar-username').textContent = user.nama_lengkap || user.username || 'Admin';
    loadDashboard();
    initAdminMqtt();
}

async function logoutAdmin() {
    try { await fetch('/api/auth/logout.php', { method: 'POST' }); } catch (e) {}
    location.reload();
}

function switchTab(tab) {
    document.querySelectorAll('.page-content').forEach(el => el.classList.add('hidden'));
    document.getElementById(`page-${tab}`)?.classList.remove('hidden');
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('is-active'));
    document.querySelector(`.nav-btn[data-tab="${tab}"]`)?.classList.add('is-active');

    if (tab === 'dashboard') loadDashboard();
    if (tab === 'devices') loadDevices();
    if (tab === 'sensors') loadSensors();
    if (tab === 'actuators') loadActuators();
    if (tab === 'schedules') loadSchedules();
    if (tab === 'automation') loadRules();
    if (['analytics','history_sensor','history_actuator'].includes(tab)) loadHistory();
    if (['cms','navigation'].includes(tab)) loadCms();
    if (tab === 'media') loadMedia();
    if (tab === 'packages') loadPackages();
    if (tab === 'messages') loadMessages();
    if (['akun','security'].includes(tab)) loadUsers();
    if (tab === 'maintenance') loadMaintenance();
    if (tab === 'maintenance') loadMaintenance();
    if (tab === 'permissions') loadPermissions();
    if (tab === 'settings') loadSysSettings();
    if (tab === 'activity') loadActivity();
}

async function loadDashboard() {
    const d = await apiGet('/api/dashboard.php');
    if (!d.ok) return;
    document.getElementById('kpi-dev').textContent = `${d.kpi.devices_online}/${d.kpi.devices_total}`;
    document.getElementById('kpi-sen').textContent = d.kpi.sensors_active;
    document.getElementById('kpi-akt').textContent = d.kpi.actuators_on;
    document.getElementById('kpi-jad').textContent = d.kpi.schedules_active;

    const nb = document.getElementById('notif-badge');
    if (nb) {
        nb.textContent = d.kpi.unread_notifications;
        nb.classList.toggle('hidden', d.kpi.unread_notifications <= 0);
    }

    document.getElementById('dash-notifs').innerHTML = (d.notifications || []).map(n => `
        <div class="p-3 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] flex justify-between items-start gap-2">
            <div><div class="font-bold text-[#111827]">${n.judul}</div><div class="text-[#4B5563] mt-0.5">${n.pesan}</div></div>
            <span class="text-[10px] text-[#6B7280] shrink-0">${n.waktu}</span>
        </div>
    `).join('') || '<div class="text-[#6B7280]">Tidak ada notifikasi.</div>';

    document.getElementById('dash-activity').innerHTML = (d.recent_activity || []).map(a => `
        <div class="p-2.5 rounded-lg bg-[#F3F7F5] border border-[#E5EFEA]">
            <div class="flex justify-between"><span class="font-bold text-[#15803D]">${escapeHtml(a.jenis_aktivitas)}</span><span class="text-[10px] text-[#6B7280]">${escapeHtml(a.waktu)}</span></div>
            <div class="text-[#4B5563] mt-0.5">${escapeHtml(a.deskripsi)}</div>
        </div>
    `).join('') || '<div class="text-[#6B7280]">Belum ada aktivitas.</div>';
}

async function markNotificationsRead() {
    const d = await apiPost('/api/notifications.php', {});
    if (d.ok) { showToast(d.message); loadDashboard(); }
}

async function loadDevices() {
    const d = await apiGet('/api/devices.php');
    if (!d.ok) return;
    document.getElementById('devices-tbody').innerHTML = d.devices.map(dev => `
        <tr>
            <td class="p-3 font-bold text-[#17332A]">${escapeHtml(dev.kode_perangkat)}</td>
            <td class="p-3">${escapeHtml(dev.nama_perangkat)}</td>
            <td class="p-3 font-mono">${escapeHtml(dev.versi_firmware || '-')}</td>
            <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] font-bold ${dev.status_koneksi==='online'?'bg-[#E5EFEA] text-[#15803D]':'bg-[#E5E7EB] text-[#4B5563]'}">${escapeHtml(dev.status_koneksi)}</span></td>
            <td class="p-3">${dev.id_perangkat > 1 ? `<button onclick="deleteDevice(${dev.id_perangkat})" class="text-[#B91C1C] font-bold">Hapus</button>` : '<span class="text-[#6B7280]">Utama</span>'}</td>
        </tr>
    `).join('');
}

async function addDevice(e) {
    e.preventDefault();
    const d = await apiPost('/api/devices.php', { kode_perangkat: document.getElementById('dev-kode').value, nama_perangkat: document.getElementById('dev-nama').value, versi_firmware: document.getElementById('dev-fw').value });
    if (d.ok) { showToast(d.message); e.target.reset(); loadDevices(); } else showToast(d.error || 'Gagal', 'error');
}

async function deleteDevice(id) {
    if (!confirm('Hapus perangkat ini?')) return;
    const d = await apiPost('/api/devices.php', { action: 'delete', id_perangkat: id });
    if (d.ok) { showToast(d.message); loadDevices(); }
}

async function loadSensors() {
    const d = await apiGet('/api/sensors.php');
    if (!d.ok) return;
    fillOptions('sen-new-device', d.devices, 'id_perangkat', x => `${x.kode_perangkat} - ${x.nama_perangkat}`); fillOptions('sen-new-type', d.types, 'id_jenis_sensor', x => `${x.kode_sensor} - ${x.nama_sensor} (${x.satuan})`);
    document.getElementById('sensors-grid').innerHTML = d.sensors.map(s => `
        <div class="bm-card p-5 space-y-3">
            <div class="flex justify-between items-center">
                <div><div class="font-bold text-sm text-[#111827]">${escapeHtml(s.nama_sensor)}</div><div class="text-[11px] text-[#6B7280]">${escapeHtml(s.kode_instalasi)} (${escapeHtml(s.satuan)})</div></div>
                <label class="bm-switch"><input type="checkbox" id="sen-st-${s.id_sensor_perangkat}" ${s.status_sensor==='Aktif'?'checked':''}><span class="bm-slider"></span></label>
            </div>
            <div class="grid grid-cols-3 gap-2">
                <div><label class="text-[10px] text-[#6B7280]">Min</label><input type="number" id="sen-min-${s.id_sensor_perangkat}" value="${s.nilai_min ?? 0}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
                <div><label class="text-[10px] text-[#6B7280]">Max</label><input type="number" id="sen-max-${s.id_sensor_perangkat}" value="${s.nilai_max ?? 100}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
                <div><label class="text-[10px] text-[#6B7280]">Offset</label><input type="number" step="0.1" id="sen-off-${s.id_sensor_perangkat}" value="${s.offset_kalibrasi ?? 0}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
            </div>
            <div class="flex gap-2"><button onclick="saveSensor(${s.id_sensor_perangkat})" class="flex-1 py-2 rounded-lg bg-[#17332A] text-white text-xs font-bold">Simpan</button><button onclick="archiveSensor(${s.id_sensor_perangkat})" class="px-3 py-2 rounded-lg bg-red-50 text-red-700 text-xs font-bold">Nonaktifkan</button></div>
        </div>
    `).join('');
}

function fillOptions(id, rows, key, label){const el=document.getElementById(id);if(el)el.innerHTML=(rows||[]).map(x=>`<option value="${x[key]}">${escapeHtml(label(x))}</option>`).join('');}
async function addSensorType(e){e.preventDefault();const d=await apiPost('/api/sensors.php',{action:'create_type',kode_sensor:document.getElementById('sen-type-code').value,nama_sensor:document.getElementById('sen-type-name').value,satuan:document.getElementById('sen-type-unit').value});if(d.ok){showToast(d.message);e.target.reset();loadSensors();}else showToast(d.error||'Gagal','error');}
async function addSensor(e){e.preventDefault();const d=await apiPost('/api/sensors.php',{action:'add',id_perangkat:document.getElementById('sen-new-device').value,id_jenis_sensor:document.getElementById('sen-new-type').value,kode_instalasi:document.getElementById('sen-new-code').value,pin_gpio:document.getElementById('sen-new-pin').value,topic_data:document.getElementById('sen-new-topic').value});if(d.ok){showToast(d.message);e.target.reset();loadSensors();}else showToast(d.error||'Gagal','error');}
async function archiveSensor(id){if(!confirm('Nonaktifkan sensor ini? Riwayat pembacaan akan tetap disimpan.'))return;const d=await apiPost('/api/sensors.php',{action:'delete',id_sensor_perangkat:id});if(d.ok){showToast(d.message);loadSensors();}else showToast(d.error||'Gagal','error');}

async function saveSensor(id) {
    const d = await apiPost('/api/sensors.php', {
        id_sensor_perangkat: id,
        status_sensor: document.getElementById(`sen-st-${id}`).checked ? 'Aktif' : 'Nonaktif',
        nilai_min: parseFloat(document.getElementById(`sen-min-${id}`).value || 0),
        nilai_max: parseFloat(document.getElementById(`sen-max-${id}`).value || 100),
        offset_kalibrasi: parseFloat(document.getElementById(`sen-off-${id}`).value || 0)
    });
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal', 'error');
}

async function loadActuators() {
    const d = await apiGet('/api/actuators.php');
    if (!d.ok) return;
    fillOptions('act-new-device', d.devices, 'id_perangkat', x => `${x.kode_perangkat} - ${x.nama_perangkat}`); fillOptions('act-new-type', d.types, 'id_jenis_aktuator', x => `${x.kode_aktuator} - ${x.nama_aktuator}`);
    document.getElementById('actuators-grid').innerHTML = d.actuators.map(a => `
        <div class="bm-card p-5 space-y-4">
            <div class="flex justify-between items-center">
                <div><div class="font-bold text-base text-[#111827]">${escapeHtml(a.nama_aktuator)}</div><div class="text-xs text-[#6B7280]">Mode: <strong>${a.mode_kontrol}</strong> • Konfirmasi: ${a.status_konfirmasi || 'ok'}</div></div>
                <span class="px-3 py-1 rounded-md text-xs font-bold ${a.status_aktuator==='ON'?'bg-[#17332A] text-white':'bg-[#E5E7EB] text-[#4B5563]'}">${a.status_aktuator}</span>
            </div>
            <div class="grid grid-cols-3 gap-2">
                <button onclick="cmdActuator('${escapeHtml(a.kode_aktuator)}','ON',${a.id_aktuator})" class="py-2 rounded-lg bg-[#17332A] text-white text-xs font-bold">ON</button>
                <button onclick="cmdActuator('${escapeHtml(a.kode_aktuator)}','OFF',${a.id_aktuator})" class="py-2 rounded-lg bg-[#E5E7EB] text-[#111827] text-xs font-bold">OFF</button>
                <button onclick="cmdActuator('${escapeHtml(a.kode_aktuator)}','AUTO',${a.id_aktuator})" class="py-2 rounded-lg bg-[#E6F2F6] text-[#1D6F8A] text-xs font-bold">AUTO</button>
            </div>
        </div>
    `).join('');
}

async function cmdActuator(kode, status, id) {
    const d = await apiPost('/api/actuators.php', { aktuator: kode, id_aktuator:id, status });
    if (d.ok) { showToast(`Perintah ${kode} -> ${status} dikirim via MQTT server`); loadActuators(); } else showToast(d.error || 'Gagal', 'error');
}

async function addActuatorType(e){e.preventDefault();const d=await apiPost('/api/actuators.php',{action:'create_type',kode_aktuator:document.getElementById('act-type-code').value,nama_aktuator:document.getElementById('act-type-name').value});if(d.ok){showToast(d.message);e.target.reset();loadActuators();}else showToast(d.error||'Gagal','error');}
async function addActuator(e){e.preventDefault();const d=await apiPost('/api/actuators.php',{action:'add',id_perangkat:document.getElementById('act-new-device').value,id_jenis_aktuator:document.getElementById('act-new-type').value,pin_gpio:document.getElementById('act-new-pin').value,topic_control:document.getElementById('act-new-topic').value});if(d.ok){showToast(d.message);e.target.reset();loadActuators();}else showToast(d.error||'Gagal','error');}

async function loadSchedules() {
    const d = await apiGet('/api/schedules.php');
    if (!d.ok) return;
    const schAct=document.getElementById('sch-akt'); if(schAct)schAct.innerHTML=(d.actuators||[]).map(a=>`<option value="${a.id_aktuator}">${escapeHtml(a.nama_aktuator)} (${escapeHtml(a.kode_aktuator)})</option>`).join('');
    document.getElementById('schedules-tbody').innerHTML = d.schedules.map(s => `
        <tr>
            <td class="p-3 font-bold text-[#111827]">${escapeHtml(s.nama_jadwal)}</td>
            <td class="p-3">${escapeHtml(s.nama_aktuator)}</td>
            <td class="p-3 font-mono">${String(s.waktu_mulai).slice(0,5)}</td>
            <td class="p-3">${s.durasi_menit} mnt (${escapeHtml(s.mode_pengulangan)})</td>
            <td class="p-3"><input type="checkbox" ${Number(s.aktif)===1?'checked':''} onchange="toggleSchedule(${s.id_jadwal},this.checked)"></td>
            <td class="p-3"><button onclick="deleteSchedule(${s.id_jadwal})" class="text-[#B91C1C] font-bold">Hapus</button></td>
        </tr>
    `).join('');
}

async function addSchedule(e) {
    e.preventDefault();
    const d = await apiPost('/api/schedules.php', { nama_jadwal: document.getElementById('sch-nama').value, id_aktuator: document.getElementById('sch-akt').value, waktu_mulai: document.getElementById('sch-mulai').value + ':00', durasi_menit: document.getElementById('sch-durasi').value, mode_pengulangan: document.getElementById('sch-mode').value });
    if (d.ok) { showToast(d.message); e.target.reset(); loadSchedules(); }
}
async function toggleSchedule(id, aktif) { const d = await apiPost('/api/schedules.php', { action: 'toggle', id_jadwal: id, aktif: aktif?1:0 }); if (d.ok) showToast(d.message); }
async function deleteSchedule(id) { if (!confirm('Hapus jadwal ini?')) return; const d = await apiPost('/api/schedules.php', { action: 'delete', id_jadwal: id }); if (d.ok) { showToast(d.message); loadSchedules(); } }

async function loadRules() {
    const d = await apiGet('/api/rules.php');
    if (!d.ok) return;
    fillOptions('rl-sensor', d.sensors, 'id_sensor_perangkat', x => `${x.nama_sensor} (${x.kode_sensor})`); fillOptions('rl-akt', d.actuators, 'id_aktuator', x => `${x.nama_aktuator} (${x.kode_aktuator})`);
    document.getElementById('rules-tbody').innerHTML = d.rules.map(r => `
        <tr>
            <td class="p-3 font-bold">${escapeHtml(r.nama_aturan)}</td>
            <td class="p-3">${escapeHtml(r.nama_sensor)} ${r.operator_kondisi} ${r.nilai_ambang}${r.satuan}</td>
            <td class="p-3 font-bold text-[#15803D]">${escapeHtml(r.nama_aktuator)} → ${r.status_tujuan}</td>
            <td class="p-3"><input type="checkbox" ${Number(r.aktif)===1?'checked':''} onchange="toggleRule(${r.id_aturan},this.checked)"></td>
            <td class="p-3"><button onclick="deleteRule(${r.id_aturan})" class="text-[#B91C1C] font-bold">Hapus</button></td>
        </tr>
    `).join('');
}

async function addRule(e) {
    e.preventDefault();
    const d = await apiPost('/api/rules.php', { nama_aturan: document.getElementById('rl-nama').value, id_sensor_perangkat: document.getElementById('rl-sensor').value, operator_kondisi: document.getElementById('rl-op').value, nilai_ambang: document.getElementById('rl-ambang').value, id_aktuator: document.getElementById('rl-akt').value, status_tujuan: document.getElementById('rl-tujuan').value });
    if (d.ok) { showToast(d.message); e.target.reset(); loadRules(); }
}
async function toggleRule(id, aktif) { const d = await apiPost('/api/rules.php', { action: 'toggle', id_aturan: id, aktif: aktif?1:0 }); if (d.ok) showToast(d.message); }
async function deleteRule(id) { if (!confirm('Hapus aturan ini?')) return; const d = await apiPost('/api/rules.php', { action: 'delete', id_aturan: id }); if (d.ok) { showToast(d.message); loadRules(); } }

async function loadHistory() {
    const d = await apiGet('/api/history.php?limit=40');
    if (!d.ok) return;
    document.getElementById('hist-sensor-tbody').innerHTML = d.sensor_history.map((r,i) => `<tr><td class="p-3">${i+1}</td><td class="p-3 font-mono">${escapeHtml(r.waktu_format)}</td><td class="p-3 font-bold">${r.suhu ?? '--'}</td><td class="p-3 font-bold">${r.kelembapan_udara ?? '--'}</td><td class="p-3 font-bold">${r.kelembapan_tanah ?? '--'}</td></tr>`).join('');
    document.getElementById('hist-act-tbody').innerHTML = d.actuator_history.map(r => `<tr><td class="p-3 font-mono">${escapeHtml(r.waktu_format)}</td><td class="p-3 font-bold">${escapeHtml(r.nama_aktuator)}</td><td class="p-3">${escapeHtml(r.status_sebelumnya)} → <strong>${escapeHtml(r.status_baru)}</strong></td><td class="p-3">${escapeHtml(r.sumber_perintah)}</td><td class="p-3">${escapeHtml(r.username || 'Sistem')}</td></tr>`).join('');

    if (admHistoryChart && d.sensor_history.length > 0) {
        const rev = [...d.sensor_history].reverse();
        admHistoryChart.data.labels = rev.map(r => r.waktu_format.slice(11));
        admHistoryChart.data.datasets[0].data = rev.map(r => parseFloat(r.kelembapan_tanah || 0));
        admHistoryChart.data.datasets[1].data = rev.map(r => parseFloat(r.suhu || 0));
        admHistoryChart.data.datasets[2].data = rev.map(r => parseFloat(r.kelembapan_udara || 0));
        admHistoryChart.update('none');
    }
}

async function loadCms() {
    const d = await apiGet('/api/cms.php?mode=admin');
    if (!d.ok) return;
    document.getElementById('cms-editor-list').innerHTML = (d.konten_list || []).map(k => `
        <div class="bm-card p-5 space-y-3">
            <div class="flex justify-between items-center border-b border-[#E5EFEA] pb-2">
                <span class="font-bold text-sm text-[#17332A] uppercase">${k.kunci_bagian}</span>
                <div class="flex items-center gap-3 text-xs">
                    <select id="cms-pub-${k.kunci_bagian}" class="px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-[11px] font-bold">
                        <option value="published" ${k.status_publikasi!=='draft'?'selected':''}>Published</option>
                        <option value="draft" ${k.status_publikasi==='draft'?'selected':''}>Draft</option>
                    </select>
                    <label class="flex items-center gap-1"><input type="checkbox" id="cms-tampil-${k.kunci_bagian}" ${Number(k.tampil)===1?'checked':''}> Tampil</label>
                    ${Number(k.is_custom)===1 ? `<button onclick="deleteCustomPage('${k.kunci_bagian}')" class="text-[#B91C1C] font-bold">Hapus</button>` : ''}
                </div>
            </div>
            <div class="grid grid-cols-2 gap-2">
                <input type="text" id="cms-judul-${k.kunci_bagian}" value="${escapeHtml(k.judul||'')}" placeholder="Judul" class="px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                <input type="text" id="cms-sub-${k.kunci_bagian}" value="${escapeHtml(k.subjudul||'')}" placeholder="Subjudul" class="px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
            </div>
            <textarea rows="2" id="cms-desc-${k.kunci_bagian}" class="w-full px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">${escapeHtml(k.deskripsi||'')}</textarea>
            <select id="cms-media-${k.kunci_bagian}" class="w-full px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"><option value="0">Pilih dari Media Library (opsional)</option>${(d.media||[]).map(m=>`<option value="${m.id_media}" ${Number(k.id_media_background)===Number(m.id_media)?'selected':''}>${escapeHtml(m.nama_file)}</option>`).join('')}</select><input type="text" id="cms-img-${k.kunci_bagian}" value="${escapeHtml(k.url_gambar||'')}" placeholder="URL manual (opsional) — dipakai jika Media Library tidak dipilih" class="w-full px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
            <div class="grid grid-cols-3 gap-2">
                <select id="cms-size-${k.kunci_bagian}" class="px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"><option value="cover" ${k.bg_size==='cover'?'selected':''}>Cover</option><option value="contain" ${k.bg_size==='contain'?'selected':''}>Contain</option><option value="auto" ${k.bg_size==='auto'?'selected':''}>Auto</option></select>
                <input type="number" min="0" max="20" id="cms-blur-${k.kunci_bagian}" value="${k.bg_blur??0}" title="Blur px" class="px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                <input type="number" min="0" max="90" id="cms-dark-${k.kunci_bagian}" value="${k.bg_darkness??55}" title="Gelap %" class="px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
            </div>
            <button onclick="saveCmsSection('${k.kunci_bagian}')" class="px-4 py-2 rounded-lg bg-[#17332A] text-white text-xs font-bold">Simpan Perubahan</button>
        </div>
    `).join('');

    fillOptions('new-pg-media', d.media, 'id_media', x => x.nama_file); const pageSelect=document.getElementById('nav-public-target'); if(pageSelect)pageSelect.innerHTML='<option value="">Pilih halaman kustom</option>'+(d.konten_list||[]).filter(x=>Number(x.is_custom)===1).map(x=>`<option value="${x.kunci_bagian}">${escapeHtml(x.judul)}</option>`).join('');
    document.getElementById('public-nav-list').innerHTML=(d.nav_public||[]).filter(n=>String(n.target_section).startsWith('sec-')).map(n=>`<div class="border rounded-lg p-3 flex justify-between items-center gap-2"><span class="text-xs font-bold">${escapeHtml(n.label)}</span><div class="flex items-center gap-2"><label class="text-xs"><input type="checkbox" ${Number(n.tampil)===1?'checked':''} onchange="togglePublicNav(${n.id_nav},this.checked)"> Tampil</label><button onclick="deletePublicNav(${n.id_nav})" class="text-red-700 text-xs font-bold">Hapus</button></div></div>`).join('');
    document.getElementById('menu-toggle-list').innerHTML = (d.menus || []).map(m => `
        <div class="bm-card p-4 flex items-center justify-between">
            <span class="font-bold text-sm text-[#111827]">${m.nama_menu}</span>
            <label class="bm-switch"><input type="checkbox" ${Number(m.tampil)===1?'checked':''} onchange="toggleMenu('${m.kode_menu}',this.checked)"><span class="bm-slider"></span></label>
        </div>
    `).join('');
}

async function saveCmsSection(kunci) {
    const d = await apiPost('/api/cms.php', {
        action: 'update_section', kunci_bagian: kunci,
        judul: document.getElementById(`cms-judul-${kunci}`).value,
        subjudul: document.getElementById(`cms-sub-${kunci}`).value,
        deskripsi: document.getElementById(`cms-desc-${kunci}`).value,
        url_gambar: document.getElementById(`cms-img-${kunci}`).value,
        id_media_background: document.getElementById(`cms-media-${kunci}`)?.value || 0,
        bg_size: document.getElementById(`cms-size-${kunci}`).value,
        bg_blur: parseInt(document.getElementById(`cms-blur-${kunci}`).value || 0),
        bg_darkness: parseInt(document.getElementById(`cms-dark-${kunci}`).value || 55),
        tampil: document.getElementById(`cms-tampil-${kunci}`).checked ? 1 : 0,
        status_publikasi: document.getElementById(`cms-pub-${kunci}`).value
    });
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal', 'error');
}

async function addCustomPage(e) {
    e.preventDefault();
    const d = await apiPost('/api/cms.php', { action: 'add_section', judul: document.getElementById('new-pg-judul').value, subjudul: document.getElementById('new-pg-sub').value, url_gambar: document.getElementById('new-pg-img').value, id_media_background: document.getElementById('new-pg-media').value, bg_size: document.getElementById('new-pg-size').value, deskripsi: document.getElementById('new-pg-desc').value });
    if (d.ok) { showToast(d.message); e.target.reset(); document.getElementById('modal-add-page').classList.add('hidden'); loadCms(); }
}
async function deleteCustomPage(kunci) { if (!confirm('Hapus halaman?')) return; const d = await apiPost('/api/cms.php', { action: 'delete_section', kunci_bagian: kunci }); if (d.ok) { showToast(d.message); loadCms(); } }
async function toggleMenu(kode, tampil) { const d = await apiPost('/api/cms.php', { action: 'toggle_menu', kode_menu: kode, tampil: tampil?1:0 }); if (d.ok) showToast(d.message); }

async function loadMedia() {
 const d=await apiGet('/api/media.php');if(!d.ok)return;
 document.getElementById('media-grid').innerHTML=d.media.map(m=>`<div class="bm-card overflow-hidden"><img src="${escapeHtml(m.url_file)}" alt="${escapeHtml(m.nama_file)}" class="w-full h-36 object-cover"><div class="p-3 space-y-2"><div class="font-bold text-xs">${escapeHtml(m.nama_file)}</div><div class="text-[10px] text-gray-500">${escapeHtml(m.kategori)} • ${m.file_size?Math.round(m.file_size/1024)+' KB':'URL eksternal'}</div><div class="flex justify-between text-[11px]"><button onclick="copyMediaUrl('${escapeJs(m.url_file)}')" class="text-green-700 font-bold">Salin URL</button><button onclick="deleteMedia(${m.id_media})" class="text-red-700 font-bold">Hapus</button></div></div></div>`).join('');
}
async function copyMediaUrl(url){try{await navigator.clipboard.writeText(url);showToast('URL disalin');}catch(e){showToast('Tidak dapat menyalin URL','error');}}
async function addMedia(e){e.preventDefault();const form=new FormData();form.append('nama_file',document.getElementById('med-nama').value);form.append('kategori','galeri');const file=document.getElementById('med-file').files[0];const url=document.getElementById('med-url').value.trim();if(file)form.append('file',file);else if(url)form.append('url_file',url);else{showToast('Pilih file gambar atau masukkan URL','error');return;}try{const res=await fetch('/api/media.php',{method:'POST',headers:{'X-CSRF-Token':csrfToken},body:form});const d=await res.json();if(d.ok){showToast(d.message);e.target.reset();loadMedia();loadCms();}else showToast(d.error||'Upload gagal','error');}catch(err){showToast('Upload gagal terhubung ke server','error');}}
async function deleteMedia(id){if(!confirm('Hapus media? Jika dipakai sebagai background, referensinya akan dilepas.'))return;const form=new FormData();form.append('action','delete');form.append('id_media',id);const res=await fetch('/api/media.php',{method:'POST',headers:{'X-CSRF-Token':csrfToken},body:form});const d=await res.json();if(d.ok){showToast(d.message);loadMedia();loadCms();}else showToast(d.error||'Gagal','error');}

async function loadPackages() {
    const d = await apiGet('/api/packages.php');
    if (!d.ok) return;
    document.getElementById('packages-list').innerHTML = d.packages.map(p => `
        <div class="bm-card p-4 flex justify-between items-start gap-3">
            <div><div class="font-bold text-sm text-[#111827]">${escapeHtml(p.nama_komponen)} <span class="text-[10px] px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A]">${escapeHtml(p.jumlah)}</span></div><div class="text-xs text-[#4B5563] mt-1">${escapeHtml(p.keterangan||'')}</div></div>
            <button onclick="deletePackage(${p.id_komponen})" class="text-xs text-[#B91C1C] font-bold shrink-0">Hapus</button>
        </div>
    `).join('');
}
async function addPackage(e) { e.preventDefault(); const d = await apiPost('/api/packages.php', { nama_komponen: document.getElementById('pkg-nama').value, jumlah: document.getElementById('pkg-jml').value, keterangan: document.getElementById('pkg-ket').value }); if (d.ok) { showToast(d.message); e.target.reset(); loadPackages(); } }
async function deletePackage(id) { if (!confirm('Hapus komponen?')) return; const d = await apiPost('/api/packages.php', { action: 'delete', id_komponen: id }); if (d.ok) { showToast(d.message); loadPackages(); } }

async function loadMessages() {
    const d = await apiGet('/api/contact.php');
    if (!d.ok) return;
    document.getElementById('messages-tbody').innerHTML = d.messages.map(m => `
        <tr><td class="p-3 font-mono">${escapeHtml(m.waktu)}</td><td class="p-3"><strong>${escapeHtml(m.nama_lengkap)}</strong><br><span class="text-[#6B7280]">${escapeHtml(m.email)}</span></td><td class="p-3">${escapeHtml(m.isi_pesan)}</td><td class="p-3">${m.status_baca==='belum_dibaca'?`<button onclick="markMsgRead(${m.id_pesan})" class="px-2 py-1 rounded bg-[#17332A] text-white text-[10px] font-bold">Tandai Dibaca</button>`:'<span class="text-[#15803D] font-bold">Dibaca</span>'}</td></tr>
    `).join('') || '<tr><td colspan="4" class="p-4 text-center text-[#6B7280]">Belum ada pesan pengunjung.</td></tr>';
}
async function markMsgRead(id) { const d = await apiPost('/api/contact.php', { action: 'mark_read', id_pesan: id }); if (d.ok) { showToast(d.message); loadMessages(); } }

async function loadUsers() {
    const d = await apiGet('/api/users.php'); if (!d.ok) { showToast(d.error||'Gagal memuat akun','error'); return; }
    document.getElementById('users-table-body').innerHTML = d.users.map(u => `
      <tr><td class="p-3 font-bold">${escapeHtml(u.username)}</td><td class="p-3">${escapeHtml(u.nama_lengkap)}</td>
      <td class="p-3">${escapeHtml(u.role)}</td><td class="p-3">${escapeHtml(u.status_akun)}</td>
      <td class="p-3"><div class="flex flex-wrap gap-2">
       <button onclick="editUser(${u.id_user},'${escapeJs(u.username)}','${escapeJs(u.nama_lengkap)}','${u.role}')" class="text-[#1D6F8A] font-bold">Edit</button>
       <button onclick="resetUserPassword(${u.id_user},'${escapeJs(u.username)}')" class="text-[#047857] font-bold">Reset password</button>
       <button onclick="toggleUserStatus(${u.id_user},'${u.status_akun==='aktif'?'nonaktif':'aktif'}')" class="text-[#92400E] font-bold">${u.status_akun==='aktif'?'Blokir':'Aktifkan'}</button>
       <button onclick="softDeleteUser(${u.id_user},'${escapeJs(u.username)}')" class="text-[#B91C1C] font-bold">Arsipkan</button></div></td></tr>`).join('');
    document.getElementById('login-history-body').innerHTML = (d.login_history||[]).map((r,i)=>`<tr><td class="p-3">${i+1}</td><td class="p-3">${escapeHtml(r.username)}</td><td class="p-3">${escapeHtml(r.waktu_format)}</td><td class="p-3">${escapeHtml(r.ip_address||'-')}</td><td class="p-3">${escapeHtml(r.device_info||'-')}</td></tr>`).join('');
}
function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function escapeJs(v){return String(v??'').replace(/\\/g,'\\\\').replace(/'/g,"\\'").replace(/[\r\n]/g,' ');}
async function addUserAccount(e){e.preventDefault();const d=await apiPost('/api/users.php',{nama_lengkap:document.getElementById('new-user-nama').value,username:document.getElementById('new-user-username').value,password:document.getElementById('new-user-pass').value,role:document.getElementById('new-user-role').value});if(d.ok){showToast(d.message);e.target.reset();loadUsers();}else showToast(d.error||'Gagal','error');}
async function editUser(id,username,nama,role){const nu=prompt('Username baru:',username);if(nu===null)return;const nn=prompt('Nama pengelola:',nama);if(nn===null)return;const nr=prompt('Role: admin / editor / read',role);if(nr===null)return;const d=await apiPost('/api/users.php',{action:'update',id_user:id,username:nu,nama_lengkap:nn,role:nr});if(d.ok){showToast(d.message);loadUsers();}else showToast(d.error||'Gagal','error');}
async function resetUserPassword(id,username){const pw=prompt('Masukkan password baru untuk '+username+' (minimal 10 karakter). Password lama tidak dapat dilihat:');if(pw===null)return;const d=await apiPost('/api/users.php',{action:'reset_password',id_user:id,password_baru:pw});if(d.ok)showToast(d.message);else showToast(d.error||'Gagal','error');}
async function toggleUserStatus(id,st){const d=await apiPost('/api/users.php',{action:'toggle_status',id_user:id,status_akun:st});if(d.ok){showToast(d.message);loadUsers();}else showToast(d.error||'Gagal','error');}
async function softDeleteUser(id,username){if(!confirm('Arsipkan akun '+username+'? Akun tidak dapat login, tetapi riwayat dan data terkait tetap dipertahankan.'))return;const d=await apiPost('/api/users.php',{action:'soft_delete',id_user:id});if(d.ok){showToast(d.message);loadUsers();}else showToast(d.error||'Gagal','error');}

async function loadPermissions() {
    const d = await apiGet('/api/permissions.php');
    if (!d.ok) return;
    document.getElementById('permissions-list').innerHTML = d.roles.map(r => {
        const permIds = d.mappings.filter(m => m.id_role == r.id_role).map(m => m.id_permission);
        const list = d.permissions.filter(p => permIds.includes(p.id_permission)).map(p => `<li class="text-xs text-[#4B5563]">✓ ${p.nama_permission}</li>`).join('');
        return `<div class="bm-card p-5 space-y-2"><div class="font-extrabold text-sm text-[#15803D]">${r.nama_role} (${r.kode_role})</div><p class="text-[11px] text-[#6B7280]">${r.deskripsi||''}</p><ul class="space-y-1 pt-2 border-t border-[#E5EFEA]">${list}</ul></div>`;
    }).join('');
}

async function loadSysSettings() {
    const d = await apiGet('/api/settings.php');
    if (!d.ok) return;
    document.getElementById('sys-settings-list').innerHTML = (d.system || []).map(s => `
        <div class="bm-card p-4 space-y-2">
            <div class="font-bold text-xs text-[#17332A] uppercase">${escapeHtml(s.kunci)}</div>
            <div class="text-[11px] text-[#6B7280]">${escapeHtml(s.keterangan||'')}</div>
            <div class="flex gap-2">
                <input type="text" id="sys-${escapeHtml(s.kunci)}" value="${escapeHtml(s.nilai||'')}" class="flex-1 px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                <button onclick="saveSysKey('${escapeHtml(s.kunci)}')" class="px-3 py-1.5 rounded bg-[#17332A] text-white text-xs font-bold">Simpan</button>
            </div>
        </div>
    `).join('');
}
async function saveSysKey(k) { const d = await apiPost('/api/settings.php', { kunci: k, nilai: document.getElementById(`sys-${k}`).value }); if (d.ok) showToast(d.message); }

async function loadActivity() {
    const d = await apiGet('/api/activity.php');
    if (!d.ok) return;
    document.getElementById('activity-tbody').innerHTML = d.activities.map(a => `<tr><td class="p-3 font-mono">${escapeHtml(a.waktu)}</td><td class="p-3 font-bold">${escapeHtml(a.username)}</td><td class="p-3"><span class="px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A] text-[10px] font-bold">${escapeHtml(a.jenis_aktivitas)}</span></td><td class="p-3">${escapeHtml(a.deskripsi)}</td></tr>`).join('');
}

function initAdminMqtt() {
    if (typeof mqtt === 'undefined') return;
    const host = window.location.hostname || '127.0.0.1';
    const client = mqtt.connect(`ws://${host}:9001`, { reconnectPeriod: 3000, clean: true });
    client.on('connect', () => {
        document.getElementById('adm-mqtt-pill').textContent = 'MQTT Online';
        client.subscribe('biomatrix/sensor/tanah');
        client.subscribe('biomatrix/sensor/dht11');
    });
    client.on('message', (topic, msg) => {
        const val = msg.toString().trim();
        if (topic === 'biomatrix/sensor/tanah') { liveSoil = parseFloat(val); document.getElementById('mon-soil').textContent = `${liveSoil}%`; }
        if (topic === 'biomatrix/sensor/dht11') { try { const d = JSON.parse(val); liveTemp = parseFloat(d.suhu); liveHum = parseFloat(d.kelembapan); document.getElementById('mon-temp').textContent = `${liveTemp}°C`; document.getElementById('mon-hum').textContent = `${liveHum}%`; } catch(e){} }
        if (admLiveChart) {
            admLiveChart.data.labels.push(new Date().toTimeString().slice(0,8));
            admLiveChart.data.datasets[0].data.push(liveSoil ?? 0);
            admLiveChart.data.datasets[1].data.push(liveTemp ?? 0);
            admLiveChart.data.datasets[2].data.push(liveHum ?? 0);
            if (admLiveChart.data.labels.length > 15) { admLiveChart.data.labels.shift(); admLiveChart.data.datasets.forEach(ds => ds.data.shift()); }
            admLiveChart.update('none');
        }
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    setInterval(() => { const el = document.getElementById('current-datetime'); if (el) el.textContent = new Date().toLocaleString('id-ID') + ' WIB'; }, 1000);
    const cfg = { type: 'line', data: { labels: [], datasets: [{ label: 'Tanah (%)', data: [], borderColor: '#15803D', borderWidth: 2, tension: 0.3 }, { label: 'Suhu (°C)', data: [], borderColor: '#B45309', borderWidth: 2, tension: 0.3 }, { label: 'Udara (%)', data: [], borderColor: '#1D6F8A', borderWidth: 2, tension: 0.3 }] }, options: { responsive: true, maintainAspectRatio: false } };
    const c1 = document.getElementById('admLiveChart')?.getContext('2d'); if (c1) admLiveChart = new Chart(c1, JSON.parse(JSON.stringify(cfg)));
    const c2 = document.getElementById('admHistoryChart')?.getContext('2d'); if (c2) admHistoryChart = new Chart(c2, JSON.parse(JSON.stringify(cfg)));

    try {
        const me = await apiGet('/api/auth/me.php');
        if (me.ok && me.authenticated && me.user.role === 'admin') {
            csrfToken = me.csrf_token || '';
            openAdmin(me.user);
        }
    } catch (e) {}
});

async function loadMaintenance(){const d=await apiGet('/api/settings.php');if(!d.ok)return;const m=(d.system||[]);const get=k=>m.find(x=>x.kunci===k)?.nilai||'';document.getElementById('maintenance-enabled').checked=get('maintenance_mode')==='1';document.getElementById('maintenance-message').value=get('maintenance_message')||'Website sedang dalam pemeliharaan.';}
async function saveMaintenance(){const enabled=document.getElementById('maintenance-enabled').checked?'1':'0';const message=document.getElementById('maintenance-message').value;const d=await apiPost('/api/settings.php',{action:'update',kunci:'maintenance_mode',nilai:enabled});if(!d.ok){showToast(d.error||'Gagal menyimpan maintenance','error');return;}const d2=await apiPost('/api/settings.php',{action:'update',kunci:'maintenance_message',nilai:message});if(d2.ok)showToast('Maintenance Mode berhasil diperbarui');else showToast(d2.error||'Pesan gagal disimpan','error');}

async function addPublicNav(e){e.preventDefault();const d=await apiPost('/api/cms.php',{action:'add_nav',label:document.getElementById('nav-public-label').value,target_section:document.getElementById('nav-public-target').value,slug:document.getElementById('nav-public-slug').value});if(d.ok){showToast(d.message);e.target.reset();loadCms();}else showToast(d.error||'Gagal','error');}
async function togglePublicNav(id,show){const d=await apiPost('/api/cms.php',{action:'toggle_nav',id_nav:id,tampil:show?1:0});if(d.ok)showToast(d.message);else showToast(d.error||'Gagal','error');}
async function deletePublicNav(id){if(!confirm('Hapus menu website ini? Halamannya tidak ikut dihapus.'))return;const d=await apiPost('/api/cms.php',{action:'delete_nav',id_nav:id});if(d.ok){showToast(d.message);loadCms();}else showToast(d.error||'Gagal','error');}
