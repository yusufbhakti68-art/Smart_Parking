# SmartParking Island — Paket Integrasi IoT

Paket ini menggabungkan dashboard HTML yang dilampirkan, rancangan MariaDB, ESP32-WROOM, MQTT Mosquitto, PHP API monitoring, dan panduan pemasangan.

## Isi paket

- `dashboard/index.html` — dashboard HTML asli yang dilampirkan, ditambah konfigurasi MQTT dan pemuat adapter. Tampilan simulasi asli tetap dipertahankan.
- `dashboard/integration.js` — mengambil status slot dari API dan menerima pembaruan MQTT.
- `database/smartparking.sql` — 21 tabel inti beserta PK, FK, indeks, CHECK, dan seed lantai/slot/perangkat/gerbang/enam sensor.
- `firmware/SmartParking_ESP32.ino` — firmware ESP32-WROOM, 6 HC-SR04, 2 servo, LCD I2C, dan asumsi 2 RC522.
- `docs/BLUEPRINT_PINOUT.md` — blueprint pinout, wiring, pembagi tegangan ECHO, dan catu daya.
- `backend/api/health.php`, `state.php` — endpoint health check dan status slot/perangkat.
- `backend/mqtt/worker.py` — penghubung MQTT ke MariaDB; menangani log sensor, RFID masuk/keluar, transaksi parkir, tagihan, konfirmasi pembayaran petugas, dan perintah servo.
- `mosquitto/` — contoh konfigurasi broker, WebSocket, dan ACL topic.
- `nginx/smartparking.conf` — virtual host Nginx untuk dashboard dan PHP API.
- `docs/PANDUAN_INSTALASI.pdf` — panduan instalasi server, database, MQTT, firmware, dan pengujian.

## Hardware yang diasumsikan

| Perangkat | Jumlah | Catatan |
|---|---:|---|
| ESP32-WROOM DevKit | 1 | Controller utama |
| RFID RC522 | 2 | Satu reader di gerbang masuk dan satu di gerbang keluar. Tipe RFID kamu belum diketahui; RC522 hanya asumsi sementara. |
| HC-SR04 | 6 | A1, A2, B1, B2, gerbang masuk, gerbang keluar |
| Servo | 2 | Palang masuk dan keluar |
| LCD 16x2 I2C | 1 | Alamat umum 0x27; alternatif 0x3F |
| Supply servo 5V | 1 | Kapasitas arus disesuaikan servo |

**Penting:** jika RFID yang kamu beli hanya satu modul, dua gerbang tidak dapat membaca kartu secara independen pada saat bersamaan. Untuk desain dua gerbang, dibutuhkan dua reader. Jika modul ternyata PN532 atau jenis lain, firmware dan wiring harus disesuaikan sebelum upload.

## Fitur yang sudah disiapkan dan batasannya

### Sudah ada dalam paket
- Skema 21 tabel database dan data awal dua lantai/empat slot.
- Pembacaan 6 sensor dan pengiriman status ke MQTT.
- Pencatatan riwayat sensor, RFID, dan perintah gerbang.
- Tap RFID masuk: validasi kartu, pilih slot yang belum memiliki transaksi aktif, buat transaksi, dan perintahkan servo masuk terbuka.
- Tap RFID keluar: hitung biaya berdasarkan snapshot tarif, ubah transaksi menjadi menunggu pembayaran, dan tampilkan tagihan.
- Konfirmasi pembayaran oleh petugas melalui topic MQTT; setelah konfirmasi, transaksi selesai dan gerbang keluar diperintahkan terbuka.
- Dashboard menerima status slot dan status ESP32 dari API/MQTT.

### Belum terintegrasi penuh / harus dikembangkan sebelum produksi
- Form login dan chat CS pada HTML asli masih menggunakan simulasi JavaScript lokal. Tabel CS sudah ada di database, tetapi endpoint autentikasi, API chat, dan integrasi UI chat belum diaktifkan. Jangan gunakan login demo untuk akun nyata.
- Pembayaran QRIS belum terhubung ke payment gateway. Jangan mengirim konfirmasi QRIS manual kecuali pembayaran benar-benar telah diverifikasi.
- Worker starter belum menghubungkan transaksi ke kendaraan pilihan pengguna; kolom `id_kendaraan` disiapkan nullable untuk integrasi tahap berikutnya. Tarif awal worker menggunakan aturan motor/semua.
- Booking, promo/voucher, laporan keuangan lengkap, manajemen user, dan penilaian CS pada dashboard HTML asli masih berupa simulasi.
- Pengujian perangkat fisik tidak dapat dilakukan dari sini. Kalibrasi sensor, arah servo, jarak deteksi, kualitas daya, dan kompatibilitas modul RFID harus diuji di perangkat nyata.

Jadi paket ini adalah **starter integrasi IoT yang dapat dipasang dan diuji bertahap**, bukan sertifikasi bahwa seluruh fitur produksi sudah aktif. Jangan gunakan untuk mengelola kendaraan/uang sungguhan sebelum autentikasi, pembayaran, dan uji keselamatan gerbang diselesaikan.

## 1. Persiapan server Ubuntu/Debian

Paket diuji secara statis dengan PHP lint dan Python compile pada lingkungan pembuatan. Contoh server menggunakan Ubuntu/Debian dengan Nginx, PHP-FPM, MariaDB, Mosquitto, dan Python 3.

```bash
sudo apt update
sudo apt install nginx mariadb-server php-fpm php-mysql mosquitto mosquitto-clients python3 python3-venv python3-pip -y
```

Ekstrak ZIP, lalu salin folder proyek:

```bash
sudo mkdir -p /var/www/smartparking
sudo cp -a SmartParking_IoT/. /var/www/smartparking/
sudo chown -R root:www-data /var/www/smartparking
sudo find /var/www/smartparking -type d -exec chmod 750 {} \;
sudo find /var/www/smartparking -type f -exec chmod 640 {} \;
```

## 2. Buat database MariaDB

```bash
sudo mariadb < /var/www/smartparking/database/smartparking.sql
```

Jika database `smartparking` sudah pernah dibuat dari paket/versi lama, jangan langsung menimpa atau menghapusnya. Backup terlebih dahulu (`sudo mariadb-dump smartparking > backup_smartparking.sql`) lalu gunakan database kosong baru atau lakukan migrasi manual. SQL paket ini ditujukan untuk instalasi bersih; `CREATE TABLE IF NOT EXISTS` tidak otomatis mengubah struktur tabel lama.

Buat user aplikasi. Ganti password dengan password kuat milikmu:

```sql
CREATE USER 'smartparking_app'@'localhost' IDENTIFIED BY 'GANTI_PASSWORD_DATABASE_KUAT';
GRANT SELECT, INSERT, UPDATE, DELETE ON smartparking.* TO 'smartparking_app'@'localhost';
FLUSH PRIVILEGES;
```

Edit konfigurasi PHP:

```bash
sudo nano /var/www/smartparking/backend/config/config.php
```

Ganti `CHANGE_DB_PASSWORD`. Batasi akses file:

```bash
sudo chown root:www-data /var/www/smartparking/backend/config/config.php
sudo chmod 640 /var/www/smartparking/backend/config/config.php
```

Periksa tabel:

```bash
sudo mariadb smartparking -e "SHOW TABLES; SELECT nomor_slot FROM Slot_tbl;"
```

## 3. Konfigurasi MQTT Mosquitto

Salin konfigurasi:

```bash
sudo cp /var/www/smartparking/mosquitto/mosquitto.conf /etc/mosquitto/conf.d/smartparking.conf
sudo cp /var/www/smartparking/mosquitto/acl /etc/mosquitto/acl
sudo chown root:mosquitto /etc/mosquitto/acl
sudo chmod 640 /etc/mosquitto/acl
```

Buat tiga akun MQTT (masukkan password ketika diminta; jangan memakai password yang sama):

```bash
sudo mosquitto_passwd -c /etc/mosquitto/passwd smartparking-device
sudo mosquitto_passwd /etc/mosquitto/passwd smartparking-backend
sudo mosquitto_passwd /etc/mosquitto/passwd smartparking-dashboard
sudo chown root:mosquitto /etc/mosquitto/passwd
sudo chmod 640 /etc/mosquitto/passwd
sudo systemctl enable mosquitto
sudo systemctl restart mosquitto
sudo systemctl status mosquitto --no-pager
```

Catat password masing-masing:
- `smartparking-device`: dimasukkan ke firmware ESP32.
- `smartparking-backend`: dimasukkan ke service worker.
- `smartparking-dashboard`: dimasukkan ke `dashboard/index.html` dan `dashboard/integration.js`. Password browser dapat dilihat pengguna, tetapi ACL hanya memberi hak baca.

Port: TCP 1883 untuk ESP32/backend dan TCP 9001 WebSocket untuk browser. Batasi akses hanya dari LAN; jangan membuka MQTT langsung ke internet.

## 4. Jalankan MQTT worker

Buat akun sistem dan virtual environment:

```bash
sudo useradd --system --no-create-home --shell /usr/sbin/nologin --groups www-data smartparking
sudo python3 -m venv /var/www/smartparking/backend/mqtt/venv
sudo /var/www/smartparking/backend/mqtt/venv/bin/pip install -r /var/www/smartparking/backend/mqtt/requirements.txt
```

Salin service dan edit kredensial:

```bash
sudo cp /var/www/smartparking/backend/mqtt/smartparking-mqtt.service /etc/systemd/system/
sudo nano /etc/systemd/system/smartparking-mqtt.service
```

Ganti `GANTI_PASSWORD_BACKEND` dan `GANTI_PASSWORD_DATABASE`. Jalankan:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now smartparking-mqtt
sudo systemctl status smartparking-mqtt --no-pager
sudo journalctl -u smartparking-mqtt -f
```

## 5. Konfigurasi Nginx dan PHP-FPM

Cari socket PHP-FPM:

```bash
ls /run/php/
```

Edit `/var/www/smartparking/nginx/smartparking.conf` jika socket bukan `php8.2-fpm.sock`. Salin dan aktifkan:

```bash
sudo cp /var/www/smartparking/nginx/smartparking.conf /etc/nginx/sites-available/smartparking
sudo ln -s /etc/nginx/sites-available/smartparking /etc/nginx/sites-enabled/smartparking
sudo nginx -t
sudo systemctl reload nginx
```

Jika site default bentrok di port 80, nonaktifkan symlink default setelah memastikan tidak ada situs lain yang menggunakannya.

Tes:

```bash
curl http://127.0.0.1/api/health.php
curl http://127.0.0.1/api/state.php
```

## 6. Cari IP server dan konfigurasi ESP32

```bash
hostname -I
```

Gunakan IP LAN server, contoh `192.168.1.10`. Jangan gunakan `localhost` pada firmware karena `localhost` akan menunjuk ke ESP32 itu sendiri.

Edit `firmware/SmartParking_ESP32.ino`:
- `WIFI_SSID`
- `WIFI_PASSWORD`
- `MQTT_HOST`
- `MQTT_PASS` (password `smartparking-device`)

Install library Arduino IDE:
- ESP32 board package (Espressif Systems)
- PubSubClient
- MFRC522
- ESP32Servo
- LiquidCrystal_I2C

Pilih board ESP32 Dev Module/ESP32-WROOM yang sesuai dan port USB yang benar. Upload, lalu buka Serial Monitor 115200 baud.

## 7. Daftarkan UID RFID

Baca UID melalui Serial Monitor (tambahkan Serial print jika dibutuhkan) atau sementara tampilkan melalui LCD. Daftarkan UID yang benar-benar dibaca:

```sql
INSERT INTO Kartu_tbl(nomor_kartu,status_kartu) VALUES ('UID_RFID_KAPITAL','aktif');
```

Jika kartu terikat ke user, isi `id_user` dengan ID akun yang sudah terdaftar. Jangan memasukkan UID contoh yang tidak berasal dari kartu fisik.

## 8. Alur transaksi dan konfirmasi pembayaran tunai

1. Reader masuk mengirim UID dengan `reader=masuk`.
2. Worker memvalidasi kartu dan memilih slot tanpa transaksi aktif.
3. Worker membuat transaksi, lalu mengirim perintah buka ke servo masuk.
4. Reader keluar mengirim UID dengan `reader=keluar`.
5. Worker menghitung biaya, menandai transaksi `menunggu_pembayaran`, dan membuat pembayaran berstatus `menunggu`.
6. Setelah petugas benar-benar menerima pembayaran tunai, petugas mengonfirmasi melalui MQTT. Contoh (ganti password dan ID transaksi):

```bash
mosquitto_pub -h 127.0.0.1 -p 1883 -u smartparking-backend -P 'PASSWORD_BACKEND' \
  -t smartparking/payment/confirm \
  -m '{"id_transaksi":1,"id_metode":1,"reference":"TUNAI-001"}'
```

`id_metode=1` adalah Tunai dan `id_metode=2` adalah QRIS pada seed database. Konfirmasi QRIS hanya boleh dilakukan setelah gateway pembayaran memverifikasi transaksi; integrasi gateway belum disediakan dalam paket.

## 9. Pengujian bertahap

1. `sudo systemctl status mariadb nginx mosquitto smartparking-mqtt`.
2. Buka `http://IP_SERVER/api/health.php`; hasil yang diharapkan `ok:true`.
3. Buka `http://IP_SERVER/api/state.php`; pastikan empat slot muncul.
4. Cek MQTT: `mosquitto_sub -h 127.0.0.1 -u smartparking-backend -P 'PASSWORD_BACKEND' -t 'smartparking/#' -v`.
5. Upload firmware; pastikan ESP32 online.
6. Uji satu HC-SR04 dan pembagi tegangan terlebih dahulu. Kalibrasi threshold 15 cm.
7. Uji setiap servo tanpa palang mekanik. Pastikan arah buka/tutup benar.
8. Uji dua reader RC522 dan pastikan reader masuk/keluar mengirim arah yang benar.
9. Daftarkan UID uji, lakukan masuk, keluar, pembayaran tunai uji, lalu cek tabel Transaksi_tbl dan Pembayaran_tbl.

## 10. Troubleshooting cepat

- `Access denied`: periksa user/password DB pada config PHP dan service worker.
- MQTT `not authorised`: periksa password dan ACL, pastikan nama user tepat.
- Dashboard tidak menerima MQTT: cek port 9001, listener WebSocket, password dashboard, dan Console browser.
- API 502: cek socket PHP-FPM pada konfigurasi Nginx.
- ESP32 restart saat servo bergerak: supply servo kurang kuat atau GND belum common.
- ESP32 gagal boot: periksa beban pada GPIO2/GPIO15 dan pin strapping.
- Sensor membaca jarak tidak wajar: periksa pembagi tegangan ECHO, GND, posisi sensor, dan threshold.
- RFID gagal: pastikan modul RC522 mendapat 3.3V dan dua reader berbagi SPI dengan SS terpisah.

## Keamanan dan catatan akhir

- Jangan gunakan password contoh atau membagikan kredensial MQTT.
- Dashboard HTML saat ini mempertahankan login dan CS simulasi dari file sumber. Jangan masukkan password asli/akun pribadi.
- Batasi port 1883 dan 9001 ke jaringan lokal. Untuk akses publik wajib memakai TLS, ACL yang ketat, autentikasi backend, proteksi CSRF, dan audit keamanan.
- Uji servo tanpa palang dan tanpa kendaraan terlebih dahulu. Sediakan emergency stop dan sensor keselamatan tambahan; ultrasonik bukan satu-satunya pengaman palang.
- Pembuatan paket ini tidak dapat menguji kondisi fisik rangkaian atau versi library di komputer kamu. Jalankan checklist pengujian sebelum dipakai.
