-- SmartParking Island | MariaDB 10.6+ / MySQL 8+
-- Import: sudo mariadb < database/smartparking.sql
CREATE DATABASE IF NOT EXISTS smartparking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smartparking;

CREATE TABLE IF NOT EXISTS User_tbl (
 id_user BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama_user VARCHAR(100) NOT NULL,
 email_user VARCHAR(150) NOT NULL UNIQUE,
 password_user VARCHAR(255) NOT NULL,
 role_user ENUM('admin','petugas','user') NOT NULL DEFAULT 'user',
 status_user ENUM('aktif','nonaktif','terblokir') NOT NULL DEFAULT 'aktif',
 tanggal_daftar DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Kartu_tbl (
 id_kartu BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_user BIGINT UNSIGNED NULL,
 nomor_kartu VARCHAR(100) NOT NULL UNIQUE,
 status_kartu ENUM('aktif','nonaktif','hilang','diblokir') NOT NULL DEFAULT 'aktif',
 tanggal_daftar DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_kartu_user FOREIGN KEY (id_user) REFERENCES User_tbl(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Kendaraan_tbl (
 id_kendaraan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_user BIGINT UNSIGNED NOT NULL,
 nomor_polisi VARCHAR(20) NOT NULL UNIQUE,
 jenis_kendaraan ENUM('motor','mobil') NOT NULL,
 merk_kendaraan VARCHAR(100) NULL,
 warna_kendaraan VARCHAR(50) NULL,
 status_kendaraan ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
 CONSTRAINT fk_kendaraan_user FOREIGN KEY (id_user) REFERENCES User_tbl(id_user) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Lantai_tbl (
 id_lantai BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama_lantai VARCHAR(50) NOT NULL UNIQUE,
 keterangan VARCHAR(255) NULL,
 status_lantai ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Slot_tbl (
 id_slot BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_lantai BIGINT UNSIGNED NOT NULL,
 nomor_slot VARCHAR(20) NOT NULL,
 status_operasional ENUM('aktif','maintenance','nonaktif') NOT NULL DEFAULT 'aktif',
 waktu_update DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 UNIQUE KEY uq_slot_lantai_nomor (id_lantai, nomor_slot),
 CONSTRAINT fk_slot_lantai FOREIGN KEY (id_lantai) REFERENCES Lantai_tbl(id_lantai) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Perangkat_tbl (
 id_perangkat BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 kode_perangkat VARCHAR(100) NOT NULL UNIQUE,
 nama_perangkat VARCHAR(100) NOT NULL,
 lokasi_perangkat VARCHAR(150) NULL,
 status_perangkat ENUM('online','offline','maintenance') NOT NULL DEFAULT 'offline',
 last_seen DATETIME NULL,
 versi_firmware VARCHAR(50) NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Gerbang_tbl (
 id_gerbang BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_perangkat BIGINT UNSIGNED NOT NULL,
 nama_gerbang VARCHAR(100) NOT NULL,
 jenis_gerbang ENUM('masuk','keluar') NOT NULL,
 lokasi_gerbang VARCHAR(150) NULL,
 status_gerbang ENUM('aktif','nonaktif','maintenance') NOT NULL DEFAULT 'aktif',
 UNIQUE KEY uq_gerbang_jenis (jenis_gerbang),
 CONSTRAINT fk_gerbang_perangkat FOREIGN KEY (id_perangkat) REFERENCES Perangkat_tbl(id_perangkat) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Sensor_tbl (
 id_sensor BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_perangkat BIGINT UNSIGNED NOT NULL,
 id_slot BIGINT UNSIGNED NULL,
 id_gerbang BIGINT UNSIGNED NULL,
 kode_sensor VARCHAR(100) NOT NULL UNIQUE,
 nama_sensor VARCHAR(100) NOT NULL,
 jenis_sensor ENUM('ultrasonik') NOT NULL DEFAULT 'ultrasonik',
 status_sensor ENUM('aktif','rusak','offline') NOT NULL DEFAULT 'aktif',
 CONSTRAINT fk_sensor_perangkat FOREIGN KEY (id_perangkat) REFERENCES Perangkat_tbl(id_perangkat) ON DELETE RESTRICT,
 CONSTRAINT fk_sensor_slot FOREIGN KEY (id_slot) REFERENCES Slot_tbl(id_slot) ON DELETE RESTRICT,
 CONSTRAINT fk_sensor_gerbang FOREIGN KEY (id_gerbang) REFERENCES Gerbang_tbl(id_gerbang) ON DELETE RESTRICT,
 CONSTRAINT chk_sensor_lokasi CHECK ((id_slot IS NOT NULL AND id_gerbang IS NULL) OR (id_slot IS NULL AND id_gerbang IS NOT NULL)),
 UNIQUE KEY uq_sensor_slot (id_slot),
 UNIQUE KEY uq_sensor_gerbang (id_gerbang)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Tarif_tbl (
 id_tarif BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama_tarif VARCHAR(100) NOT NULL,
 jenis_kendaraan ENUM('motor','mobil','semua') NOT NULL DEFAULT 'semua',
 tarif_awal DECIMAL(12,2) NOT NULL DEFAULT 0,
 durasi_awal_menit INT UNSIGNED NOT NULL DEFAULT 60,
 tarif_per_interval DECIMAL(12,2) NOT NULL DEFAULT 2000,
 interval_menit INT UNSIGNED NOT NULL DEFAULT 60,
 tarif_maksimal DECIMAL(12,2) NOT NULL DEFAULT 20000,
 berlaku_mulai DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 berlaku_sampai DATETIME NULL,
 status_tarif ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
 CHECK (tarif_awal >= 0 AND tarif_per_interval >= 0 AND tarif_maksimal >= 0 AND interval_menit > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Metode_pembayaran_tbl (
 id_metode BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama_metode VARCHAR(50) NOT NULL UNIQUE,
 status_metode ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif'
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Denda_tbl (
 id_denda BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 nama_denda VARCHAR(100) NOT NULL,
 batas_waktu_menit INT UNSIGNED NULL,
 jumlah_denda DECIMAL(12,2) NOT NULL DEFAULT 0,
 status_denda ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
 CHECK (jumlah_denda >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Transaksi_tbl (
 id_transaksi BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_kartu BIGINT UNSIGNED NOT NULL,
 id_user BIGINT UNSIGNED NULL,
 id_kendaraan BIGINT UNSIGNED NULL,
 id_slot BIGINT UNSIGNED NOT NULL,
 id_tarif BIGINT UNSIGNED NOT NULL,
 id_gerbang_masuk BIGINT UNSIGNED NOT NULL,
 id_gerbang_keluar BIGINT UNSIGNED NULL,
 waktu_masuk DATETIME NOT NULL,
 waktu_keluar DATETIME NULL,
 total_durasi_menit INT UNSIGNED NULL,
 tarif_awal_snapshot DECIMAL(12,2) NOT NULL,
 durasi_awal_snapshot INT UNSIGNED NOT NULL,
 tarif_interval_snapshot DECIMAL(12,2) NOT NULL,
 interval_menit_snapshot INT UNSIGNED NOT NULL,
 tarif_maksimal_snapshot DECIMAL(12,2) NOT NULL,
 total_tarif DECIMAL(12,2) NOT NULL DEFAULT 0,
 status_transaksi ENUM('berlangsung','menunggu_pembayaran','selesai','batal') NOT NULL DEFAULT 'berlangsung',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 slot_aktif_id BIGINT UNSIGNED GENERATED ALWAYS AS (CASE WHEN status_transaksi IN ('berlangsung','menunggu_pembayaran') THEN id_slot ELSE NULL END) STORED,
 kartu_aktif_id BIGINT UNSIGNED GENERATED ALWAYS AS (CASE WHEN status_transaksi IN ('berlangsung','menunggu_pembayaran') THEN id_kartu ELSE NULL END) STORED,
 kendaraan_aktif_id BIGINT UNSIGNED GENERATED ALWAYS AS (CASE WHEN status_transaksi IN ('berlangsung','menunggu_pembayaran') AND id_kendaraan IS NOT NULL THEN id_kendaraan ELSE NULL END) STORED,
 UNIQUE KEY uq_transaksi_slot_aktif (slot_aktif_id),
 UNIQUE KEY uq_transaksi_kartu_aktif (kartu_aktif_id),
 UNIQUE KEY uq_transaksi_kendaraan_aktif (kendaraan_aktif_id),
 INDEX idx_transaksi_kartu_status (id_kartu,status_transaksi),
 INDEX idx_transaksi_waktu (waktu_masuk),
 CONSTRAINT fk_transaksi_kartu FOREIGN KEY (id_kartu) REFERENCES Kartu_tbl(id_kartu) ON DELETE RESTRICT,
 CONSTRAINT fk_transaksi_user FOREIGN KEY (id_user) REFERENCES User_tbl(id_user) ON DELETE SET NULL,
 CONSTRAINT fk_transaksi_kendaraan FOREIGN KEY (id_kendaraan) REFERENCES Kendaraan_tbl(id_kendaraan) ON DELETE SET NULL,
 CONSTRAINT fk_transaksi_slot FOREIGN KEY (id_slot) REFERENCES Slot_tbl(id_slot) ON DELETE RESTRICT,
 CONSTRAINT fk_transaksi_tarif FOREIGN KEY (id_tarif) REFERENCES Tarif_tbl(id_tarif) ON DELETE RESTRICT,
 CONSTRAINT fk_transaksi_gerbang_masuk FOREIGN KEY (id_gerbang_masuk) REFERENCES Gerbang_tbl(id_gerbang) ON DELETE RESTRICT,
 CONSTRAINT fk_transaksi_gerbang_keluar FOREIGN KEY (id_gerbang_keluar) REFERENCES Gerbang_tbl(id_gerbang) ON DELETE RESTRICT,
 CHECK (total_tarif >= 0 AND interval_menit_snapshot > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Pembayaran_tbl (
 id_pembayaran BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_transaksi BIGINT UNSIGNED NOT NULL,
 id_metode BIGINT UNSIGNED NOT NULL,
 jumlah_bayar DECIMAL(12,2) NOT NULL,
 kode_referensi VARCHAR(120) NULL,
 waktu_bayar DATETIME NULL,
 status_pembayaran ENUM('menunggu','berhasil','gagal','dibatalkan') NOT NULL DEFAULT 'menunggu',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_pembayaran_transaksi (id_transaksi,status_pembayaran),
 CONSTRAINT fk_pembayaran_transaksi FOREIGN KEY (id_transaksi) REFERENCES Transaksi_tbl(id_transaksi) ON DELETE RESTRICT,
 CONSTRAINT fk_pembayaran_metode FOREIGN KEY (id_metode) REFERENCES Metode_pembayaran_tbl(id_metode) ON DELETE RESTRICT,
 CHECK (jumlah_bayar >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Transaksi_denda_tbl (
 id_transaksi_denda BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_transaksi BIGINT UNSIGNED NOT NULL,
 id_denda BIGINT UNSIGNED NOT NULL,
 jumlah_denda_snapshot DECIMAL(12,2) NOT NULL,
 keterangan VARCHAR(255) NULL,
 waktu_dikenakan DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_td_transaksi FOREIGN KEY (id_transaksi) REFERENCES Transaksi_tbl(id_transaksi) ON DELETE RESTRICT,
 CONSTRAINT fk_td_denda FOREIGN KEY (id_denda) REFERENCES Denda_tbl(id_denda) ON DELETE RESTRICT,
 CHECK (jumlah_denda_snapshot >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Log_sensor_tbl (
 id_log_sensor BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_sensor BIGINT UNSIGNED NOT NULL,
 jarak_cm DECIMAL(8,2) NULL,
 status_deteksi ENUM('kosong','terisi','tidak_diketahui') NOT NULL,
 waktu_pembacaan DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_log_sensor_time (id_sensor,waktu_pembacaan),
 CONSTRAINT fk_log_sensor_sensor FOREIGN KEY (id_sensor) REFERENCES Sensor_tbl(id_sensor) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Log_rfid_tbl (
 id_log_rfid BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_kartu BIGINT UNSIGNED NULL,
 id_gerbang BIGINT UNSIGNED NOT NULL,
 id_perangkat BIGINT UNSIGNED NOT NULL,
 uid_terbaca VARCHAR(100) NOT NULL,
 hasil_validasi ENUM('diterima','ditolak') NOT NULL,
 alasan VARCHAR(255) NULL,
 waktu_scan DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_log_rfid_uid_time (uid_terbaca,waktu_scan),
 CONSTRAINT fk_log_rfid_kartu FOREIGN KEY (id_kartu) REFERENCES Kartu_tbl(id_kartu) ON DELETE SET NULL,
 CONSTRAINT fk_log_rfid_gerbang FOREIGN KEY (id_gerbang) REFERENCES Gerbang_tbl(id_gerbang) ON DELETE RESTRICT,
 CONSTRAINT fk_log_rfid_perangkat FOREIGN KEY (id_perangkat) REFERENCES Perangkat_tbl(id_perangkat) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Log_gerbang_tbl (
 id_log_gerbang BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_gerbang BIGINT UNSIGNED NOT NULL,
 id_perangkat BIGINT UNSIGNED NOT NULL,
 id_transaksi BIGINT UNSIGNED NULL,
 perintah ENUM('buka','tutup') NOT NULL,
 hasil ENUM('berhasil','gagal','dikirim') NOT NULL,
 waktu_perintah DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 keterangan VARCHAR(255) NULL,
 CONSTRAINT fk_log_gerbang_gerbang FOREIGN KEY (id_gerbang) REFERENCES Gerbang_tbl(id_gerbang) ON DELETE RESTRICT,
 CONSTRAINT fk_log_gerbang_perangkat FOREIGN KEY (id_perangkat) REFERENCES Perangkat_tbl(id_perangkat) ON DELETE RESTRICT,
 CONSTRAINT fk_log_gerbang_transaksi FOREIGN KEY (id_transaksi) REFERENCES Transaksi_tbl(id_transaksi) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Log_aktivitas_tbl (
 id_log_aktivitas BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_user BIGINT UNSIGNED NULL,
 aktivitas VARCHAR(120) NOT NULL,
 keterangan TEXT NULL,
 alamat_ip VARCHAR(45) NULL,
 waktu_aktivitas DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_aktivitas_time (waktu_aktivitas),
 CONSTRAINT fk_aktivitas_user FOREIGN KEY (id_user) REFERENCES User_tbl(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Chat_cs_tbl (
 id_chat BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_user BIGINT UNSIGNED NOT NULL,
 id_petugas BIGINT UNSIGNED NULL,
 id_gerbang BIGINT UNSIGNED NULL,
 subjek_chat VARCHAR(150) NOT NULL,
 status_chat ENUM('menunggu','diproses','selesai') NOT NULL DEFAULT 'menunggu',
 prioritas_chat ENUM('rendah','normal','tinggi') NOT NULL DEFAULT 'normal',
 tanggal_chat DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 waktu_update DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 waktu_selesai DATETIME NULL,
 INDEX idx_chat_petugas_status (id_petugas,status_chat),
 CONSTRAINT fk_chat_user FOREIGN KEY (id_user) REFERENCES User_tbl(id_user) ON DELETE RESTRICT,
 CONSTRAINT fk_chat_petugas FOREIGN KEY (id_petugas) REFERENCES User_tbl(id_user) ON DELETE SET NULL,
 CONSTRAINT fk_chat_gerbang FOREIGN KEY (id_gerbang) REFERENCES Gerbang_tbl(id_gerbang) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Pesan_cs_tbl (
 id_pesan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_chat BIGINT UNSIGNED NOT NULL,
 id_pengirim BIGINT UNSIGNED NOT NULL,
 isi_pesan TEXT NOT NULL,
 waktu_pesan DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 waktu_dibaca DATETIME NULL,
 INDEX idx_pesan_chat_time (id_chat,waktu_pesan),
 CONSTRAINT fk_pesan_chat FOREIGN KEY (id_chat) REFERENCES Chat_cs_tbl(id_chat) ON DELETE RESTRICT,
 CONSTRAINT fk_pesan_pengirim FOREIGN KEY (id_pengirim) REFERENCES User_tbl(id_user) ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS Penilaian_cs_tbl (
 id_penilaian BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 id_chat BIGINT UNSIGNED NOT NULL UNIQUE,
 rating TINYINT UNSIGNED NOT NULL,
 ulasan TEXT NULL,
 tanggal_penilaian DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_penilaian_chat FOREIGN KEY (id_chat) REFERENCES Chat_cs_tbl(id_chat) ON DELETE RESTRICT,
 CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB;

-- Seed dasar sesuai dashboard: dua lantai, empat slot, dua gerbang, enam sensor.
INSERT IGNORE INTO Lantai_tbl(id_lantai,nama_lantai,keterangan) VALUES (1,'Lantai 1','Area parkir lantai 1'),(2,'Lantai 2','Area parkir lantai 2');
INSERT IGNORE INTO Slot_tbl(id_slot,id_lantai,nomor_slot) VALUES (1,1,'A1'),(2,1,'A2'),(3,2,'B1'),(4,2,'B2');
INSERT IGNORE INTO Perangkat_tbl(id_perangkat,kode_perangkat,nama_perangkat,lokasi_perangkat) VALUES (1,'ESP32-SP-001','ESP32-WROOM Main Controller','Panel kontrol parkir');
INSERT IGNORE INTO Gerbang_tbl(id_gerbang,id_perangkat,nama_gerbang,jenis_gerbang,lokasi_gerbang) VALUES (1,1,'Gerbang Masuk','masuk','Pintu masuk'),(2,1,'Gerbang Keluar','keluar','Pintu keluar');
INSERT IGNORE INTO Sensor_tbl(id_sensor,id_perangkat,id_slot,kode_sensor,nama_sensor) VALUES
 (1,1,1,'US-SLOT-A1','Ultrasonik Slot A1'),(2,1,2,'US-SLOT-A2','Ultrasonik Slot A2'),
 (3,1,3,'US-SLOT-B1','Ultrasonik Slot B1'),(4,1,4,'US-SLOT-B2','Ultrasonik Slot B2');
INSERT IGNORE INTO Sensor_tbl(id_sensor,id_perangkat,id_gerbang,kode_sensor,nama_sensor) VALUES
 (5,1,1,'US-GATE-IN','Ultrasonik Gerbang Masuk'),(6,1,2,'US-GATE-OUT','Ultrasonik Gerbang Keluar');
INSERT IGNORE INTO Tarif_tbl(id_tarif,nama_tarif,jenis_kendaraan,tarif_awal,durasi_awal_menit,tarif_per_interval,interval_menit,tarif_maksimal) VALUES
 (1,'Tarif standar','semua',2000,60,2000,60,20000);
INSERT IGNORE INTO Metode_pembayaran_tbl(id_metode,nama_metode) VALUES (1,'Tunai'),(2,'QRIS');
INSERT IGNORE INTO Denda_tbl(id_denda,nama_denda,batas_waktu_menit,jumlah_denda,status_denda) VALUES (1,'Denda pelanggaran',NULL,0,'nonaktif');

-- Buat akun admin/petugas dari PHP password_hash(); jangan menyimpan password plaintext.
-- Contoh setelah membuat hash: INSERT INTO User_tbl(nama_user,email_user,password_user,role_user) VALUES ('Admin','admin@smartparking.local','$2y$...','admin');
-- Daftarkan kartu: INSERT INTO Kartu_tbl(id_user,nomor_kartu,status_kartu) VALUES (1,'UID_RFID','aktif');
