# Panduan Deploy SmartParking IoT Hybrid

Paket ini siap di-deploy ke **Server Lokal (Ubuntu WSL2 / Linux)** maupun **Firebase Hosting**.

## 1. Deploy Otomatis ke Server Lokal (Ubuntu WSL2 / Nginx)
```bash
unzip SmartParking_IoT_Hybrid_Deploy.zip
cd smartparking
sudo chmod +x deploy_smartparking.sh
sudo ./deploy_smartparking.sh
```
Setelah selesai, buka browser ke `http://<IP-SERVER-ANDA>/`.

## 2. Deploy ke Firebase Hosting
1. Buka file `.firebaserc` dan ganti `ganti-dengan-project-id-firebase-anda` dengan Project ID Firebase Anda.
2. Jalankan perintah berikut di dalam folder `smartparking`:
```bash
npm install -g firebase-tools
firebase login
firebase deploy
```
Firebase Hosting otomatis menyajikan folder `dashboard/` sebagai web publik.
