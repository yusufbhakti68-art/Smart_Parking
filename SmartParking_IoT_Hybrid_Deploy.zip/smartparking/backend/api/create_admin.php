<?php
declare(strict_types=1);
// Run from CLI only: php create_admin.php "Nama" "admin@example.local" "password-kuat"
if (PHP_SAPI !== 'cli') { http_response_code(404); exit; }
if ($argc !== 4 || strlen($argv[3]) < 12) { fwrite(STDERR,"Usage: php create_admin.php NAME EMAIL PASSWORD(min 12 chars)\n"); exit(2); }
require __DIR__ . '/../config/database.php';
$hash=password_hash($argv[3],PASSWORD_DEFAULT);
$stmt=$pdo->prepare("INSERT INTO User_tbl(nama_user,email_user,password_user,role_user) VALUES(?,?,?,'admin')");
$stmt->execute([$argv[1],$argv[2],$hash]);
echo "Admin created with id ".$pdo->lastInsertId()."\n";
