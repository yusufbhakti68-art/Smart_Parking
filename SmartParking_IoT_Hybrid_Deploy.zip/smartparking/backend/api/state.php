<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
try {
 require __DIR__ . '/../config/database.php';
 $slots=$pdo->query("SELECT s.id_slot,s.nomor_slot,l.nama_lantai,s.status_operasional,
   (SELECT ls.status_deteksi FROM Log_sensor_tbl ls JOIN Sensor_tbl se ON se.id_sensor=ls.id_sensor WHERE se.id_slot=s.id_slot ORDER BY ls.waktu_pembacaan DESC,ls.id_log_sensor DESC LIMIT 1) AS status_sensor,
   EXISTS(SELECT 1 FROM Transaksi_tbl t WHERE t.id_slot=s.id_slot AND t.status_transaksi IN ('berlangsung','menunggu_pembayaran')) AS ada_transaksi
   FROM Slot_tbl s JOIN Lantai_tbl l ON l.id_lantai=s.id_lantai ORDER BY s.id_slot")->fetchAll();
 $device=$pdo->query("SELECT kode_perangkat,status_perangkat,last_seen FROM Perangkat_tbl ORDER BY id_perangkat LIMIT 1")->fetch();
 echo json_encode(['ok'=>true,'slots'=>$slots,'device'=>$device,'time'=>date(DATE_ATOM)],JSON_UNESCAPED_UNICODE);
} catch(Throwable $e) { http_response_code(503); echo json_encode(['ok'=>false,'error'=>'State service unavailable']); }
