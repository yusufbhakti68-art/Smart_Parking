<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
try { require __DIR__ . '/../config/database.php'; $pdo->query('SELECT 1'); echo json_encode(['ok'=>true,'service'=>'SmartParking API','database'=>'connected','time'=>date(DATE_ATOM)]); }
catch (Throwable $e) { http_response_code(503); echo json_encode(['ok'=>false,'error'=>'Database unavailable']); }
