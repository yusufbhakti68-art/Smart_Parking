<?php
declare(strict_types=1);
// Prefer environment variables in production. Never commit real passwords.
return [
  'db_host' => getenv('DB_HOST') ?: '127.0.0.1',
  'db_name' => getenv('DB_NAME') ?: 'smartparking',
  'db_user' => getenv('DB_USER') ?: 'smartparking_app',
  'db_pass' => getenv('DB_PASS') ?: 'CHANGE_DB_PASSWORD',
];
