#!/usr/bin/env python3
"""MQTT -> MariaDB bridge for SmartParking Island (prototype/LAN deployment)."""
import json, os, sys, time, math
from datetime import datetime
import pymysql
import paho.mqtt.client as mqtt

DB_HOST=os.getenv('DB_HOST','127.0.0.1'); DB_NAME=os.getenv('DB_NAME','smartparking')
DB_USER=os.getenv('DB_USER','smartparking_app'); DB_PASS=os.getenv('DB_PASS','CHANGE_DB_PASSWORD')
MQTT_HOST=os.getenv('MQTT_HOST','127.0.0.1'); MQTT_PORT=int(os.getenv('MQTT_PORT','1883'))
MQTT_USER=os.getenv('MQTT_USER','smartparking'); MQTT_PASS=os.getenv('MQTT_PASS','CHANGE_MQTT_PASSWORD')
DEVICE_ID=int(os.getenv('DEVICE_ID','1'))
SENSOR_CACHE={}  # sensor_id -> (status, last_persist_monotonic)
TOPIC_RFID='smartparking/rfid/scan'; TOPIC_PAYMENT='smartparking/payment/confirm'


def db():
    return pymysql.connect(host=DB_HOST,user=DB_USER,password=DB_PASS,database=DB_NAME,
      charset='utf8mb4',autocommit=False,cursorclass=pymysql.cursors.DictCursor,connect_timeout=5)

def publish(topic, payload, retain=False):
    if client.is_connected(): client.publish(topic,json.dumps(payload,ensure_ascii=False),qos=1,retain=retain)

def on_connect(c, userdata, flags, reason_code, properties):
    if reason_code == 0:
        c.subscribe([('smartparking/esp32/status',1),('smartparking/sensor/+',0),('smartparking/sensor/+/+',0),(TOPIC_RFID,1),(TOPIC_PAYMENT,1)])
        print('MQTT connected; subscribed to sensors, RFID and payment confirmation',flush=True)
    else: print('MQTT connection rejected:',reason_code,flush=True)

def log_activity(cur, text, detail=None):
    cur.execute('INSERT INTO Log_aktivitas_tbl(aktivitas,keterangan) VALUES(%s,%s)',(text,detail))

def handle_device_status(data):
    status='online' if str(data.get('status','')).lower()=='online' else 'offline'
    con=db()
    try:
      with con.cursor() as cur:
        cur.execute('UPDATE Perangkat_tbl SET status_perangkat=%s,last_seen=NOW() WHERE id_perangkat=%s',(status,DEVICE_ID))
      con.commit()
    except Exception:
      con.rollback(); raise
    finally: con.close()

def handle_sensor(topic, data):
    # topics: smartparking/sensor/slot/A1 or smartparking/sensor/gate/masuk
    parts=topic.split('/')
    if len(parts)!=4: return
    location=parts[3]
    con=db()
    try:
      with con.cursor() as cur:
        cur.execute("UPDATE Perangkat_tbl SET status_perangkat='online',last_seen=NOW() WHERE id_perangkat=%s",(DEVICE_ID,))
        if parts[2]=='slot':
          slot_code=parts[3]
          cur.execute('SELECT id_slot FROM Slot_tbl WHERE nomor_slot=%s',(slot_code,)); slot=cur.fetchone()
        elif parts[2]=='gate':
          gate_type=parts[3]
          cur.execute('SELECT g.id_gerbang,s.id_sensor FROM Gerbang_tbl g LEFT JOIN Sensor_tbl s ON s.id_gerbang=g.id_gerbang WHERE g.jenis_gerbang=%s',(gate_type,)); row=cur.fetchone()
          slot=None
        else: return
        sensor_id=(row.get('id_sensor') if row else None) if parts[2]=='gate' else None
        # Resolve sensor ID for slot path.
        if parts[2]=='slot' and slot:
          cur.execute('SELECT id_sensor FROM Sensor_tbl WHERE id_slot=%s',(slot['id_slot'],)); s=cur.fetchone(); sensor_id=s['id_sensor'] if s else None
        if sensor_id:
          occupied=bool(data.get('occupied',False)); valid=bool(data.get('valid',True))
          status='terisi' if occupied else 'kosong'
          if not valid: status='tidak_diketahui'
          distance=data.get('distance_cm')
          now=time.monotonic(); previous=SENSOR_CACHE.get(sensor_id)
          if previous is None or previous[0]!=status or now-previous[1]>=60:
            cur.execute('INSERT INTO Log_sensor_tbl(id_sensor,jarak_cm,status_deteksi) VALUES(%s,%s,%s)',(sensor_id,distance,status))
            SENSOR_CACHE[sensor_id]=(status,now)
      con.commit()
    except Exception:
      con.rollback(); raise
    finally: con.close()

def handle_rfid(data):
    uid=str(data.get('uid','')).strip().upper()
    if not uid: return
    # Two physical RFID readers publish reader='masuk' and reader='keluar' respectively.
    con=db(); response={}
    try:
      with con.cursor() as cur:
        cur.execute('SELECT id_kartu,id_user,status_kartu FROM Kartu_tbl WHERE UPPER(nomor_kartu)=%s',(uid,)); card=cur.fetchone()
        reader=str(data.get('reader','masuk')).lower()
        gate_type='keluar' if reader in ('keluar','exit') else 'masuk'
        cur.execute("SELECT * FROM Transaksi_tbl WHERE id_kartu=%s AND status_transaksi IN ('berlangsung','menunggu_pembayaran') ORDER BY id_transaksi DESC LIMIT 1",(card['id_kartu'],)) if card else None
        active=cur.fetchone() if card else None
        cur.execute('SELECT id_gerbang FROM Gerbang_tbl WHERE jenis_gerbang=%s',(gate_type,)); gate=cur.fetchone()
        if not gate: raise RuntimeError('Gerbang '+gate_type+' belum terdaftar')
        if not card or card['status_kartu']!='aktif':
          cur.execute("INSERT INTO Log_rfid_tbl(id_kartu,id_gerbang,id_perangkat,uid_terbaca,hasil_validasi,alasan) VALUES(NULL,%s,%s,%s,'ditolak','Kartu tidak dikenal atau tidak aktif')",(gate['id_gerbang'],DEVICE_ID,uid))
          con.commit(); publish('smartparking/notification',{'type':'error','message':'Kartu RFID ditolak'}); return
        cur.execute("INSERT INTO Log_rfid_tbl(id_kartu,id_gerbang,id_perangkat,uid_terbaca,hasil_validasi) VALUES(%s,%s,%s,%s,'diterima')",(card['id_kartu'],gate['id_gerbang'],DEVICE_ID,uid))
        # Determine state from active transaction. Entry/exit gate reader must be explicitly identified.
        if active is None:
          if gate_type=='keluar':
            publish('smartparking/notification',{'type':'error','message':'Tidak ada transaksi aktif untuk kartu ini'}); con.commit(); return
          cur.execute("SELECT s.id_slot,s.nomor_slot FROM Slot_tbl s WHERE s.status_operasional='aktif' AND NOT EXISTS (SELECT 1 FROM Transaksi_tbl t WHERE t.id_slot=s.id_slot AND t.status_transaksi IN ('berlangsung','menunggu_pembayaran')) AND EXISTS (SELECT 1 FROM Sensor_tbl se JOIN Log_sensor_tbl ls ON ls.id_sensor=se.id_sensor WHERE se.id_slot=s.id_slot AND ls.id_log_sensor=(SELECT MAX(ls2.id_log_sensor) FROM Log_sensor_tbl ls2 WHERE ls2.id_sensor=se.id_sensor) AND ls.status_deteksi='kosong') ORDER BY s.id_slot LIMIT 1 FOR UPDATE")
          slot=cur.fetchone()
          if not slot:
            publish('smartparking/notification',{'type':'error','message':'Parkir penuh'}); con.commit(); return
          cur.execute("SELECT id_tarif,tarif_awal,durasi_awal_menit,tarif_per_interval,interval_menit,tarif_maksimal FROM Tarif_tbl WHERE status_tarif='aktif' AND (jenis_kendaraan='semua' OR jenis_kendaraan='motor') ORDER BY berlaku_mulai DESC LIMIT 1")
          tariff=cur.fetchone()
          if not tariff: raise RuntimeError('Tarif aktif belum tersedia')
          cur.execute("INSERT INTO Transaksi_tbl(id_kartu,id_user,id_slot,id_tarif,id_gerbang_masuk,waktu_masuk,tarif_awal_snapshot,durasi_awal_snapshot,tarif_interval_snapshot,interval_menit_snapshot,tarif_maksimal_snapshot) VALUES(%s,%s,%s,%s,%s,NOW(),%s,%s,%s,%s,%s)",(card['id_kartu'],card['id_user'],slot['id_slot'],tariff['id_tarif'],gate['id_gerbang'],tariff['tarif_awal'],tariff['durasi_awal_menit'],tariff['tarif_per_interval'],tariff['interval_menit'],tariff['tarif_maksimal']))
          txid=cur.lastrowid; log_activity(cur,'Kendaraan masuk',f'Transaksi {txid}, slot {slot["nomor_slot"]}')
          cur.execute("INSERT INTO Log_gerbang_tbl(id_gerbang,id_perangkat,id_transaksi,perintah,hasil,keterangan) VALUES(%s,%s,%s,'buka','dikirim','Perintah buka gerbang masuk')",(gate['id_gerbang'],DEVICE_ID,txid))
          con.commit(); publish('smartparking/gate/entry/cmd',{'action':'open','transaction_id':txid}); publish('smartparking/lcd/cmd',{'line1':'Silakan Masuk','line2':'Slot '+slot['nomor_slot']}); publish('smartparking/notification',{'type':'success','message':'Berhasil masuk. Slot '+slot['nomor_slot']}); return
        else:
          if active['status_transaksi']=='menunggu_pembayaran':
            publish('smartparking/notification',{'type':'info','message':f'Transaksi {active["id_transaksi"]} menunggu pembayaran'}); con.commit(); return
          if gate_type!='keluar':
            publish('smartparking/notification',{'type':'error','message':'Kartu memiliki transaksi aktif; gunakan reader gerbang keluar'}); con.commit(); return
          mins=max(1,math.ceil((datetime.now()-active['waktu_masuk']).total_seconds()/60))
          if mins<=active['durasi_awal_snapshot']: total=active['tarif_awal_snapshot']
          else: total=active['tarif_awal_snapshot']+math.ceil((mins-active['durasi_awal_snapshot'])/active['interval_menit_snapshot'])*active['tarif_interval_snapshot']
          total=min(float(total),float(active['tarif_maksimal_snapshot']))
          cur.execute("UPDATE Transaksi_tbl SET waktu_keluar=NOW(),total_durasi_menit=%s,total_tarif=%s,status_transaksi='menunggu_pembayaran',id_gerbang_keluar=%s WHERE id_transaksi=%s",(mins,total,gate['id_gerbang'],active['id_transaksi']))
          cur.execute("INSERT INTO Pembayaran_tbl(id_transaksi,id_metode,jumlah_bayar,status_pembayaran) VALUES(%s,1,%s,'menunggu')",(active['id_transaksi'],total))
          log_activity(cur,'Kendaraan keluar - menunggu pembayaran',f'Transaksi {active["id_transaksi"]}; total Rp {total:,.0f}')
          con.commit(); publish('smartparking/lcd/cmd',{'line1':'Total parkir','line2':'Rp '+str(int(total))}); publish('smartparking/notification',{'type':'info','message':f'Tagihan transaksi {active["id_transaksi"]}: Rp {total:,.0f}. Petugas konfirmasi pembayaran.'})
    except Exception:
      con.rollback(); raise
    finally: con.close()

def handle_payment(data):
    txid=int(data.get('id_transaksi',0)); method=int(data.get('id_metode',1));
    if txid<=0: return
    con=db()
    try:
      with con.cursor() as cur:
        cur.execute("SELECT id_transaksi,id_gerbang_keluar,status_transaksi FROM Transaksi_tbl WHERE id_transaksi=%s FOR UPDATE",(txid,)); tx=cur.fetchone()
        if not tx or tx['status_transaksi']!='menunggu_pembayaran': raise RuntimeError('Transaksi tidak menunggu pembayaran')
        cur.execute("UPDATE Pembayaran_tbl SET id_metode=%s,status_pembayaran='berhasil',waktu_bayar=NOW(),kode_referensi=%s WHERE id_transaksi=%s AND status_pembayaran='menunggu' ORDER BY id_pembayaran DESC LIMIT 1",(method,data.get('reference','PETUGAS'),txid))
        if cur.rowcount!=1: raise RuntimeError('Pembayaran menunggu tidak ditemukan')
        cur.execute("UPDATE Transaksi_tbl SET status_transaksi='selesai' WHERE id_transaksi=%s",(txid,))
        cur.execute("INSERT INTO Log_gerbang_tbl(id_gerbang,id_perangkat,id_transaksi,perintah,hasil,keterangan) VALUES(%s,%s,%s,'buka','dikirim','Pembayaran dikonfirmasi')",(tx['id_gerbang_keluar'],DEVICE_ID,txid))
        log_activity(cur,'Pembayaran dikonfirmasi',f'Transaksi {txid}; metode {method}')
      con.commit()
      publish('smartparking/gate/exit/cmd',{'action':'open','transaction_id':txid}); publish('smartparking/notification',{'type':'success','message':'Pembayaran berhasil. Gerbang keluar dibuka.'})
    except Exception:
      con.rollback(); raise
    finally: con.close()

def on_message(c, userdata, msg):
    try:
      data=json.loads(msg.payload.decode('utf-8'))
      if msg.topic=='smartparking/esp32/status': handle_device_status(data)
      elif msg.topic==TOPIC_RFID: handle_rfid(data)
      elif msg.topic==TOPIC_PAYMENT: handle_payment(data)
      else: handle_sensor(msg.topic,data)
    except Exception as exc:
      print('ERROR processing',msg.topic,repr(exc),file=sys.stderr,flush=True)
      publish('smartparking/notification',{'type':'error','message':'Kesalahan pemrosesan pesan perangkat; periksa log server'})

client=mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,client_id='smartparking-bridge')
client.username_pw_set(MQTT_USER,MQTT_PASS)
client.on_connect=on_connect; client.on_message=on_message
client.connect(MQTT_HOST,MQTT_PORT,60)
client.loop_forever()
