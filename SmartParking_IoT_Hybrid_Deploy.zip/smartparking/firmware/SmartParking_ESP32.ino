/*
  SmartParking Island - ESP32-WROOM starter firmware
  Hardware assumed: 2x RC522 (one per gate), 6x HC-SR04, 2x servo, LCD 16x2 I2C.
  RC522 type is a provisional assumption because the actual RFID module is not yet identified.
*/
#include <WiFi.h>
#include <PubSubClient.h>
#include <SPI.h>
#include <MFRC522.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

const char* WIFI_SSID = "GANTI_NAMA_WIFI";
const char* WIFI_PASSWORD = "GANTI_PASSWORD_WIFI";
const char* MQTT_HOST = "192.168.1.10"; // IP LAN server; do not use localhost
const uint16_t MQTT_PORT = 1883;
const char* MQTT_USER = "smartparking-device";
const char* MQTT_PASS = "GANTI_PASSWORD_MQTT";
const char* DEVICE_CODE = "ESP32-SP-001";

// Two RC522 readers share SPI (SCK 18, MISO 19, MOSI 23) and RST 27; separate SS pins.
// GPIO15 is a strapping pin; keep the RC522 SS line pulled HIGH at reset. Verify your board.
#define RFID_ENTRY_SS 5
#define RFID_EXIT_SS 15
#define RFID_RST 27
// Both modules share the physical RST wire. The exit reader uses the library software reset
// (0xFF) so its initialization does not pulse/reset the already initialized entry reader.
MFRC522 rfidEntry(RFID_ENTRY_SS, RFID_RST);
MFRC522 rfidExit(RFID_EXIT_SS, 0xFF);

// LCD I2C; if blank, test address 0x3F instead of 0x27.
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Servo pins. Use a separate regulated 5V supply and common GND.
const int SERVO_ENTRY_PIN = 25;
const int SERVO_EXIT_PIN = 26;
const int SERVO_CLOSED = 0;
const int SERVO_OPEN = 90;
Servo servoEntry, servoExit;

// 6 sensors: A1, A2, B1, B2, entrance, exit.
// GPIO2 is a boot-strapping pin: keep the TRIG line LOW during ESP32 reset.
const int TRIG_PINS[6] = {13, 14, 16, 17, 4, 2};
const int ECHO_PINS[6] = {34, 35, 32, 33, 36, 39}; // ECHO MUST be level-shifted to <=3.3V
const char* SENSOR_TOPICS[6] = {
  "smartparking/sensor/slot/A1", "smartparking/sensor/slot/A2",
  "smartparking/sensor/slot/B1", "smartparking/sensor/slot/B2",
  "smartparking/sensor/gate/masuk", "smartparking/sensor/gate/keluar"
};
const char* SENSOR_NAMES[6] = {"A1","A2","B1","B2","GATE_IN","GATE_OUT"};
const char* TOPIC_RFID = "smartparking/rfid/scan";
const char* TOPIC_STATUS = "smartparking/esp32/status";
const char* TOPIC_ENTRY_CMD = "smartparking/gate/entry/cmd";
const char* TOPIC_EXIT_CMD = "smartparking/gate/exit/cmd";
const char* TOPIC_LCD_CMD = "smartparking/lcd/cmd";

WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);
unsigned long lastSensorPublish = 0;
unsigned long lastStatusPublish = 0;
unsigned long lastCardRead = 0;
const unsigned long SENSOR_INTERVAL_MS = 2500;
const float OCCUPIED_THRESHOLD_CM = 15.0f; // calibrate for mounting height

float readDistanceCm(int index) {
  digitalWrite(TRIG_PINS[index], LOW); delayMicroseconds(3);
  digitalWrite(TRIG_PINS[index], HIGH); delayMicroseconds(10);
  digitalWrite(TRIG_PINS[index], LOW);
  unsigned long duration = pulseIn(ECHO_PINS[index], HIGH, 28000UL);
  if (duration == 0) return -1.0f;
  return (float)duration * 0.0343f / 2.0f;
}

void publishSensor(int index) {
  float cm = readDistanceCm(index);
  bool valid = cm > 0.0f;
  bool occupied = valid && cm < OCCUPIED_THRESHOLD_CM;
  char payload[180];
  snprintf(payload, sizeof(payload),
    "{\"sensor\":\"%s\",\"distance_cm\":%.2f,\"occupied\":%s,\"valid\":%s}",
    SENSOR_NAMES[index], cm, occupied ? "true" : "false", valid ? "true" : "false");
  mqtt.publish(SENSOR_TOPICS[index], payload, false);
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String message; message.reserve(length + 1);
  for (unsigned int i = 0; i < length; i++) message += (char)payload[i];
  String topicName(topic);
  bool openCommand = message.indexOf("\"open\"") >= 0 || message.indexOf("open") >= 0;
  if (topicName == TOPIC_ENTRY_CMD) {
    servoEntry.write(openCommand ? SERVO_OPEN : SERVO_CLOSED);
    lcd.clear(); lcd.setCursor(0,0); lcd.print(openCommand ? "Silakan Masuk" : "Gerbang Masuk");
    lcd.setCursor(0,1); lcd.print(openCommand ? "Palang Terbuka" : "Palang Ditutup");
    if (openCommand) { delay(2500); servoEntry.write(SERVO_CLOSED); }
  } else if (topicName == TOPIC_EXIT_CMD) {
    servoExit.write(openCommand ? SERVO_OPEN : SERVO_CLOSED);
    lcd.clear(); lcd.setCursor(0,0); lcd.print(openCommand ? "Terima Kasih" : "Gerbang Keluar");
    lcd.setCursor(0,1); lcd.print(openCommand ? "Palang Terbuka" : "Palang Ditutup");
    if (openCommand) { delay(2500); servoExit.write(SERVO_CLOSED); }
  } else if (topicName == TOPIC_LCD_CMD) {
    // Backend JSON format: {"line1":"...","line2":"..."}; simple fallback prints first line.
    int p1=message.indexOf("\"line1\""); int p2=message.indexOf("\"line2\"");
    lcd.clear(); lcd.setCursor(0,0);
    if (p1>=0) { int a=message.indexOf(':',p1)+1; while(a<message.length() && (message[a]==' '||message[a]=='\"')) a++; int b=message.indexOf('"',a); lcd.print(message.substring(a,b<0?message.length():b)); }
    else lcd.print(message.substring(0,16));
    if (p2>=0) { int a=message.indexOf(':',p2)+1; while(a<message.length() && (message[a]==' '||message[a]=='\"')) a++; int b=message.indexOf('"',a); lcd.setCursor(0,1); lcd.print(message.substring(a,b<0?message.length():b)); }
  }
}

void connectWiFi() {
  WiFi.mode(WIFI_STA); WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  lcd.clear(); lcd.print("WiFi connecting");
  while (WiFi.status() != WL_CONNECTED) { delay(500); }
  lcd.clear(); lcd.print("WiFi connected"); lcd.setCursor(0,1); lcd.print(WiFi.localIP());
}

void connectMQTT() {
  while (!mqtt.connected()) {
    String clientId = String(DEVICE_CODE) + "-" + String((uint32_t)ESP.getEfuseMac(), HEX);
    if (mqtt.connect(clientId.c_str(), MQTT_USER, MQTT_PASS, TOPIC_STATUS, 1, true, "{\"status\":\"offline\"}")) {
      mqtt.subscribe(TOPIC_ENTRY_CMD); mqtt.subscribe(TOPIC_EXIT_CMD); mqtt.subscribe(TOPIC_LCD_CMD);
      mqtt.publish(TOPIC_STATUS, "{\"status\":\"online\",\"device\":\"ESP32-WROOM\"}", true);
      lcd.clear(); lcd.print("MQTT connected");
    } else { lcd.clear(); lcd.print("MQTT retry..."); delay(3000); }
  }
}

void readOneRFID(MFRC522 &reader, const char* direction) {
  if (!reader.PICC_IsNewCardPresent() || !reader.PICC_ReadCardSerial()) return;
  String uid;
  for (byte i=0; i<reader.uid.size; i++) { if (reader.uid.uidByte[i] < 0x10) uid += "0"; uid += String(reader.uid.uidByte[i], HEX); }
  uid.toUpperCase();
  String payload = String("{\"uid\":\"") + uid + "\",\"reader\":\"" + direction + "\"}";
  mqtt.publish(TOPIC_RFID, payload.c_str(), false);
  Serial.print("RFID "); Serial.print(direction); Serial.print(" UID="); Serial.println(uid);
  lcd.clear(); lcd.print(direction[0]=='m' ? "RFID GERBANG IN" : "RFID GERBANG OUT"); lcd.setCursor(0,1); lcd.print(uid.substring(0,16));
  reader.PICC_HaltA(); reader.PCD_StopCrypto1();
}

void readRFID() {
  if (millis() - lastCardRead < 900) return;
  readOneRFID(rfidEntry, "masuk");
  readOneRFID(rfidExit, "keluar");
  lastCardRead = millis();
}

void setup() {
  Serial.begin(115200);
  for (int i=0; i<6; i++) { pinMode(TRIG_PINS[i], OUTPUT); digitalWrite(TRIG_PINS[i], LOW); pinMode(ECHO_PINS[i], INPUT); }
  Wire.begin(21,22); lcd.init(); lcd.backlight(); lcd.print("SmartParking");
  pinMode(RFID_ENTRY_SS,OUTPUT); digitalWrite(RFID_ENTRY_SS,HIGH);
  pinMode(RFID_EXIT_SS,OUTPUT); digitalWrite(RFID_EXIT_SS,HIGH);
  SPI.begin(18,19,23,RFID_ENTRY_SS); rfidEntry.PCD_Init(); rfidExit.PCD_Init();
  servoEntry.setPeriodHertz(50); servoExit.setPeriodHertz(50);
  servoEntry.attach(SERVO_ENTRY_PIN,500,2400); servoExit.attach(SERVO_EXIT_PIN,500,2400);
  servoEntry.write(SERVO_CLOSED); servoExit.write(SERVO_CLOSED);
  connectWiFi(); mqtt.setServer(MQTT_HOST,MQTT_PORT); mqtt.setCallback(mqttCallback); mqtt.setBufferSize(512);
}

void loop() {
  if (WiFi.status()!=WL_CONNECTED) connectWiFi();
  if (!mqtt.connected()) connectMQTT();
  mqtt.loop();
  readRFID();
  if (millis()-lastSensorPublish >= SENSOR_INTERVAL_MS) {
    lastSensorPublish=millis();
    for (int i=0;i<6;i++) { publishSensor(i); mqtt.loop(); delay(60); }
  }
  if (millis()-lastStatusPublish >= 15000) {
    lastStatusPublish=millis();
    mqtt.publish(TOPIC_STATUS,"{\"status\":\"online\",\"device\":\"ESP32-WROOM\"}",true);
  }
}
