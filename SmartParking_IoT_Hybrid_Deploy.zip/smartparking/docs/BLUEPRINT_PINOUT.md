# Blueprint Wiring SmartParking Island — ESP32-WROOM

## Asumsi perangkat
- Board ESP32-WROOM DevKit (3.3V logic).
- 2 modul RFID RC522 sementara diasumsikan: satu di gerbang masuk dan satu di gerbang keluar. Tipe RFID asli belum diketahui; cek label modul sebelum merakit.
- 6 sensor HC-SR04: 4 slot + 2 gerbang.
- 2 servo palang.
- LCD 16x2 dengan backpack I2C.

## Tabel pinout

| Fungsi | ESP32 GPIO | Catatan |
|---|---:|---|
| RC522 SCK (keduanya) | 18 | SPI clock bersama |
| RC522 MISO (keduanya) | 19 | SPI data ke ESP32 |
| RC522 MOSI (keduanya) | 23 | SPI data dari ESP32 |
| RC522 SS gerbang masuk | 5 | Chip select reader masuk |
| RC522 SS gerbang keluar | 15 | GPIO15 adalah strapping pin; pertahankan SS HIGH saat reset dan uji board |
| RC522 RST (keduanya) | 27 | Reset fisik bersama; reader keluar memakai soft reset library |
| LCD SDA | 21 | I2C |
| LCD SCL | 22 | I2C |
| Servo gerbang masuk | 25 | Sinyal PWM; supply servo eksternal |
| Servo gerbang keluar | 26 | Sinyal PWM; supply servo eksternal |
| HC-SR04 A1 TRIG | 13 | Output |
| HC-SR04 A1 ECHO | 34 | Input-only, wajib pembagi tegangan |
| HC-SR04 A2 TRIG | 14 | Output |
| HC-SR04 A2 ECHO | 35 | Input-only, wajib pembagi tegangan |
| HC-SR04 B1 TRIG | 16 | Output |
| HC-SR04 B1 ECHO | 32 | Input |
| HC-SR04 B2 TRIG | 17 | Output |
| HC-SR04 B2 ECHO | 33 | Input |
| HC-SR04 gerbang masuk TRIG | 4 | Output |
| HC-SR04 gerbang masuk ECHO | 36 | Input-only, wajib pembagi tegangan |
| HC-SR04 gerbang keluar TRIG | 2 | GPIO2 strapping; pastikan LOW saat reset |
| HC-SR04 gerbang keluar ECHO | 39 | Input-only, wajib pembagi tegangan |

## Peta sederhana sensor

```text
LANTAI 1                    LANTAI 2
[HC-SR04 A1] [HC-SR04 A2]  [HC-SR04 B1] [HC-SR04 B2]
       \          |              |          /
        \         |              |         /
         +--------- ESP32-WROOM -----------+
                    |       |
            [LCD 16x2 I2C]  [RFID masuk/keluar]
                    |
        [Servo masuk]     [Servo keluar]
             |                 |
       [US gerbang in]   [US gerbang out]
```

## Pembagi tegangan ECHO HC-SR04

Setiap ECHO sensor menghasilkan sekitar 5V, sedangkan GPIO ESP32 hanya aman pada level 3.3V. Buat pembagi tegangan untuk **setiap** ECHO:

```text
HC-SR04 ECHO ----[1 kΩ]----+---- ESP32 ECHO GPIO
                           |
                         [2 kΩ]
                           |
                          GND
```

Dengan 1 kΩ di sisi atas dan 2 kΩ ke GND, tegangan keluaran sekitar 3.3V. Semua GND harus tersambung bersama.

## Catu daya
- ESP32: USB/5V board yang stabil.
- Servo: supply 5V eksternal dengan arus sesuai stall current kedua servo (umumnya sediakan margin besar; jangan mengambil daya servo dari pin 3V3 ESP32).
- GND supply servo, GND ESP32, dan GND sensor disatukan.
- HC-SR04: supply 5V; ECHO tetap harus melalui pembagi tegangan.
- RC522: supply 3.3V, bukan 5V. Pastikan level SPI 3.3V.
- LCD I2C: cek modul backpack. Jika pull-up SDA/SCL ke 5V, gunakan level shifter I2C atau pastikan pull-up ke 3.3V agar GPIO ESP32 tidak menerima 5V.

## Peringatan sebelum menyalakan
1. GPIO2 dan GPIO15 adalah pin strapping pada ESP32. Periksa rangkaian dan pastikan kondisi pin saat boot sesuai. Jika board gagal boot, pindahkan sinyal tersebut menggunakan ekspander/ubah pemetaan firmware.
2. Jangan menyambungkan ECHO 5V langsung ke ESP32.
3. Servo dapat menimbulkan lonjakan arus dan reset; gunakan catu daya terpisah.
4. Pastikan tipe RFID benar-benar RC522. Jika PN532 atau tipe lain, wiring dan library firmware harus diganti.
5. Firmware ini mendukung dua RC522 RC522 berbagi SPI. Jika modul RFID aktual hanya satu, sistem tidak dapat membaca kartu secara independen di dua gerbang sampai reader kedua ditambahkan.
6. Kalibrasi `OCCUPIED_THRESHOLD_CM` dan posisi sensor sebelum dipakai. Hindari dua HC-SR04 memancarkan ultrasonik bersamaan; firmware membaca sensor berurutan.

## MQTT topics
- `smartparking/esp32/status`
- `smartparking/sensor/slot/A1`, `/A2`, `/B1`, `/B2`
- `smartparking/sensor/gate/masuk`, `/keluar`
- `smartparking/rfid/scan` payload `{ "uid":"...", "reader":"masuk|keluar" }`
- `smartparking/gate/entry/cmd`, `smartparking/gate/exit/cmd`
- `smartparking/lcd/cmd`
- `smartparking/payment/confirm` (backend/operator only)
