#!/bin/bash
set -e

echo "=================================================================="
echo "  SMARTPARKING IoT HYBRID — AUTO-DEPLOY (Ubuntu WSL2 / Linux)"
echo "=================================================================="

TARGET_DIR="/var/www/smartparking"
CURRENT_DIR="$(realpath .)"

# 1. Backup instalasi lama jika sudah ada
BACKUP_DIR="/root/backup_smartparking_$(date +%Y%m%d_%H%M%S)"
if [ -d "$TARGET_DIR" ]; then
    mkdir -p "$BACKUP_DIR"
    cp -r "$TARGET_DIR" "$BACKUP_DIR/files"
    mysqldump -u root smartparking > "$BACKUP_DIR/smartparking_backup.sql" 2>/dev/null || true
    echo "[BACKUP] Backup aman tersimpan di $BACKUP_DIR"
fi

# 2. Salin file ke /var/www/smartparking
mkdir -p "$TARGET_DIR"
if [ "$CURRENT_DIR" != "$TARGET_DIR" ]; then
    cp -r ./* "$TARGET_DIR/"
fi
chown -R www-data:www-data "$TARGET_DIR"
chmod -R 755 "$TARGET_DIR"

# 3. Pastikan MariaDB aktif & import database jika belum ada
systemctl enable --now mariadb 2>/dev/null || service mariadb start || true
mysql -u root << 'EOF' 2>/dev/null || true
CREATE DATABASE IF NOT EXISTS smartparking CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'smartparking_app'@'localhost' IDENTIFIED BY 'smartparking123';
CREATE USER IF NOT EXISTS 'smartparking_app'@'127.0.0.1' IDENTIFIED BY 'smartparking123';
GRANT ALL PRIVILEGES ON smartparking.* TO 'smartparking_app'@'localhost';
GRANT ALL PRIVILEGES ON smartparking.* TO 'smartparking_app'@'127.0.0.1';
FLUSH PRIVILEGES;
EOF

DB_EXISTS=$(mysql -u smartparking_app -psmartparking123 -N -e "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='smartparking' AND TABLE_NAME='Slot_tbl';" 2>/dev/null || echo "0")
if [ "$DB_EXISTS" = "0" ]; then
    echo "[DB] Mengimpor skema database/smartparking.sql..."
    mysql -u root < "$TARGET_DIR/database/smartparking.sql"
fi

# 4. Pastikan Python venv & service worker MQTT siap
if [ ! -x "$TARGET_DIR/backend/mqtt/venv/bin/python" ]; then
    echo "[MQTT WORKER] Menyiapkan Python virtual environment..."
    python3 -m venv "$TARGET_DIR/backend/mqtt/venv"
    "$TARGET_DIR/backend/mqtt/venv/bin/pip" install --quiet -r "$TARGET_DIR/backend/mqtt/requirements.txt"
fi

cat << 'EOF' > /etc/systemd/system/smartparking-mqtt.service
[Unit]
Description=SmartParking IoT Hybrid MQTT to MariaDB Worker
After=network.target mosquitto.service mariadb.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/smartparking/backend/mqtt
Environment="MQTT_HOST=127.0.0.1"
Environment="DB_HOST=127.0.0.1"
Environment="DB_NAME=smartparking"
Environment="DB_USER=smartparking_app"
Environment="DB_PASS=smartparking123"
Environment="DEVICE_ID=1"
ExecStart=/var/www/smartparking/backend/mqtt/venv/bin/python /var/www/smartparking/backend/mqtt/worker.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload 2>/dev/null || true
systemctl enable --now smartparking-mqtt.service 2>/dev/null || true
systemctl restart smartparking-mqtt.service 2>/dev/null || true

# 5. Konfigurasi Nginx VirtualHost Port 80
PHP_SOCK=$(find /run/php/ -name "php*-fpm.sock" 2>/dev/null | head -n 1)
if [ -z "$PHP_SOCK" ]; then
    echo "[WARN] Socket PHP-FPM tidak ditemukan di /run/php/. Pastikan php-fpm aktif."
    PHP_SOCK="/run/php/php8.2-fpm.sock"
fi

cat << EOF > /etc/nginx/sites-available/smartparking.conf
server {
    listen 80;
    listen [::]:80;
    server_name _;

    root /var/www/smartparking/dashboard;
    index index.html;
    client_max_body_size 5m;

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    location /api/ {
        alias /var/www/smartparking/backend/api/;
        try_files \$uri =404;
    }

    location ~ ^/api/(.+\.php)$ {
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME /var/www/smartparking/backend/api/\$1;
        fastcgi_param SCRIPT_NAME \$fastcgi_script_name;
        fastcgi_pass unix:$PHP_SOCK;
    }

    location ~* /(\.env|\.git|README|database|firmware|mosquitto|docs)/ {
        deny all;
    }
}
EOF

ln -sf /etc/nginx/sites-available/smartparking.conf /etc/nginx/sites-enabled/smartparking.conf
nginx -t && (systemctl reload nginx 2>/dev/null || service nginx reload)

SERVER_IP=$(hostname -I | awk '{print $1}')
echo "=================================================================="
echo "  SMARTPARKING IoT HYBRID SIAP DIGUNAKAN!"
echo "  Akses Website : http://${SERVER_IP:-172.25.234.127}/"
echo "  Demo User     : user@demo.com / 123"
echo "  Demo Admin    : admin@demo.com / 123"
echo "=================================================================="
