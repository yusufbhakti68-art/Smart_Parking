# Hasil Audit Paket SmartParking IoT

Tanggal audit: 13 November 2026  
Paket sumber: `SmartParking_IoT_Lengkap (2).zip`

## 1. Ringkasan

- Database berisi **tepat 21 tabel**. Jumlah ini sesuai permintaan dan dipertahankan.
- Pemeriksaan struktur menemukan 32 deklarasi foreign key; seluruh target tabel foreign key tersedia di dalam skema.
- Struktur relasional secara umum sudah baik dan mendekati 3NF: entitas pengguna, kartu, kendaraan, slot, perangkat, sensor, tarif, transaksi, pembayaran, denda, log, dan customer service dipisahkan sesuai tanggung jawabnya.
- Tidak ditambahkan tabel baru hanya untuk mengejar jumlah. Snapshot tarif pada transaksi dan snapshot jumlah denda merupakan denormalisasi yang disengaja untuk menjaga histori transaksi ketika tarif/aturan berubah.
- Pemeriksaan sintaks lokal: Python worker lulus `py_compile`; seluruh PHP API/config lulus `php -l`; `integration.js` dan tiga blok JavaScript inline pada dashboard lulus `node --check`.

## 2. Daftar 21 tabel

1. `User_tbl`
2. `Kartu_tbl`
3. `Kendaraan_tbl`
4. `Lantai_tbl`
5. `Slot_tbl`
6. `Perangkat_tbl`
7. `Gerbang_tbl`
8. `Sensor_tbl`
9. `Tarif_tbl`
10. `Metode_pembayaran_tbl`
11. `Denda_tbl`
12. `Transaksi_tbl`
13. `Pembayaran_tbl`
14. `Transaksi_denda_tbl`
15. `Log_sensor_tbl`
16. `Log_rfid_tbl`
17. `Log_gerbang_tbl`
18. `Log_aktivitas_tbl`
19. `Chat_cs_tbl`
20. `Pesan_cs_tbl`
21. `Penilaian_cs_tbl`

## 3. Catatan normalisasi dan integritas

- Pemisahan `User_tbl`, `Kartu_tbl`, dan `Kendaraan_tbl` menghindari pengulangan data profil pada setiap transaksi.
- `Slot_tbl` bergantung pada `Lantai_tbl`; sensor terpisah dari slot/gerbang dan riwayat pembacaan disimpan di `Log_sensor_tbl`.
- Tarif, metode pembayaran, dan aturan denda dipisahkan menjadi tabel referensi.
- `Transaksi_denda_tbl` menjadi tabel penghubung transaksi dengan aturan denda.
- Snapshot tarif di `Transaksi_tbl` dan nilai denda snapshot di `Transaksi_denda_tbl` sebaiknya dipertahankan. Ini bukan duplikasi yang harus dihapus karena nilainya merekam harga saat transaksi terjadi.
- Kolom `id_user` pada transaksi dapat dipandang sebagai snapshot pemilik saat transaksi; pertahankan bila kebutuhan audit mengharuskan pemilik saat itu tetap tercatat meskipun relasi kartu berubah.

## 4. Batasan dan pekerjaan wajib sebelum produksi

Pemeriksaan sintaks bukan bukti sistem sudah berjalan end-to-end. Hal-hal berikut masih memerlukan server, kredensial, dan perangkat fisik:

1. **Import MariaDB belum dapat diuji di lingkungan audit.** Jalankan import pada MariaDB 10.6+ dan periksa semua tabel, constraint, seed, serta query API.
2. **Firmware ESP32 belum dikompilasi atau diuji di perangkat.** Pastikan jenis RFID benar-benar RC522, dua reader bekerja pada SPI bersama, level ECHO HC-SR04 diturunkan ke maksimum 3,3 V, dan servo memakai catu 5 V terpisah dengan GND bersama.
3. **Booking masih simulasi JavaScript lokal.** Belum ada tabel/API booking; reservasi tidak tersimpan permanen dan tidak boleh dianggap sebagai booking sungguhan.
4. **Login dan chat CS pada dashboard masih simulasi.** Endpoint autentikasi, otorisasi role, sesi aman, dan API chat belum diimplementasikan. Jangan gunakan untuk akun nyata.
5. **QRIS belum terhubung ke payment gateway.** Konfirmasi pembayaran melalui MQTT hanya boleh dilakukan setelah pembayaran benar-benar diverifikasi oleh sistem pembayaran tepercaya.
6. **Kendaraan belum dipilih/dihubungkan ke transaksi oleh worker.** `id_kendaraan` masih nullable dan tarif worker saat ini menggunakan kategori motor/semua. Tarif mobil belum dapat dijamin benar sampai alur pemilihan kendaraan diimplementasikan.
7. **Kredensial dashboard MQTT berada di JavaScript browser.** Akun dashboard harus tetap read-only dengan ACL minimum; gunakan TLS/WSS, password unik, pembatasan jaringan, dan jangan berikan hak publish ke dashboard.
8. **Keselamatan gerbang wajib diuji.** Tambahkan sensor keselamatan/limit switch dan mekanisme fail-safe sebelum palang dipakai pada kendaraan sungguhan. Jangan hanya mengandalkan timer servo.

## 5. Checklist pengujian setelah instalasi

- [ ] Import `database/smartparking.sql` ke MariaDB 10.6+ tanpa error.
- [ ] Pastikan terdapat 21 tabel dan seluruh foreign key aktif.
- [ ] Uji `GET /api/health.php` dan `GET /api/state.php`.
- [ ] Uji koneksi MQTT device, backend, dan dashboard sesuai ACL.
- [ ] Pastikan topik sensor slot A1, A2, B1, B2 memperbarui status database dan dashboard.
- [ ] Pastikan sensor gerbang masuk/keluar tercatat.
- [ ] Uji kartu RFID aktif, nonaktif, tidak dikenal, masuk, dan keluar.
- [ ] Uji transaksi penuh, perhitungan tarif, pembayaran, dan pembukaan palang.
- [ ] Uji koneksi terputus, restart ESP32, restart broker, dan restart worker.
- [ ] Uji kondisi darurat: objek menghalangi palang, sensor gagal, dan listrik terputus.

## 6. Kesimpulan

Skema SQL **sudah berjumlah 21 tabel** dan tidak memerlukan penambahan tabel untuk memenuhi target jumlah atau normalisasi dasar. Pemeriksaan sintaks sumber lulus. Namun paket ini tetap merupakan starter/prototipe integrasi IoT: fitur booking, login/CS, QRIS, pemilihan kendaraan, serta pengujian server dan perangkat harus diselesaikan sebelum dinyatakan siap produksi.
