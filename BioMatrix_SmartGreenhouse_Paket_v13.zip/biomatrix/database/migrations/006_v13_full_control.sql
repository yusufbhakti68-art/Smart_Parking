-- Migration 006: v13 Normalized 3NF Tables
-- (pengaturan_background_pengelola, blokir_perangkat, pengaturan_tampilan_sistem, info_kontak_pengelola)
USE biomatrix;

-- 1. Background untuk setiap halaman di Menu Pengelola (3NF)
CREATE TABLE IF NOT EXISTS pengaturan_background_pengelola (
    kode_halaman VARCHAR(30) PRIMARY KEY,
    nama_halaman VARCHAR(60) NOT NULL,
    url_gambar VARCHAR(500) NULL,
    bg_size VARCHAR(20) NOT NULL DEFAULT 'cover',
    bg_blur TINYINT UNSIGNED NOT NULL DEFAULT 0,
    bg_darkness TINYINT UNSIGNED NOT NULL DEFAULT 70,
    updated_by BIGINT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_pbp_user FOREIGN KEY (updated_by) REFERENCES users(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO pengaturan_background_pengelola (kode_halaman, nama_halaman, url_gambar, bg_size, bg_blur, bg_darkness) VALUES
('login', 'Halaman Login Pengelola', 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?q=80&w=2000&auto=format&fit=crop', 'cover', 0, 20),
('dashboard', 'Dashboard Utama', 'https://i.ibb.co.com/tMDKPwPb/Natural-Ventilation-2-11zon-1024x685.jpg', 'cover', 0, 55),
('sensor', 'Halaman Sensor', 'https://i.ibb.co.com/TB5Vhwvy/images-3.jpg', 'cover', 0, 70),
('tanah', 'Halaman Tanah', 'https://i.ibb.co.com/qFyxt2XY/images-2.jpg', 'cover', 0, 70),
('dht11', 'Halaman DHT11', 'https://images.unsplash.com/photo-1585320806297-9794b3e4eeae?auto=format&fit=crop&q=80&w=1600', 'cover', 0, 70),
('kipas', 'Halaman Kipas', 'https://i.ibb.co.com/p6mjTsTf/Image-For-Article-1633-16697334671071295.webp', 'cover', 0, 70),
('pompa', 'Halaman Pompa', 'https://i.ibb.co.com/mVHjLwXS/Pivot-With-Drops.jpg', 'cover', 0, 70),
('grafik', 'Halaman Grafik', 'https://i.ibb.co.com/WZG2SVx/Adobe-Stock-320255673.avif', 'cover', 0, 70),
('riwayat', 'Halaman Riwayat Data', 'https://i.ibb.co.com/Q39PwPsp/1617441916952.jpg', 'cover', 0, 70),
('pengaturan', 'Halaman Pengaturan', 'https://i.ibb.co.com/Q39PwPsp/1617441916952.jpg', 'cover', 0, 70);

-- 2. Pemblokiran Perangkat / IP Address (3NF)
CREATE TABLE IF NOT EXISTS blokir_perangkat (
    id_blokir BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL UNIQUE,
    nama_perangkat VARCHAR(120) NULL,
    alasan VARCHAR(255) NOT NULL DEFAULT 'Akses diblokir oleh Administrator',
    aktif BOOLEAN NOT NULL DEFAULT TRUE,
    diblokir_oleh BIGINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_bp_user FOREIGN KEY (diblokir_oleh) REFERENCES users(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 3. Pengaturan Tampilan Maintenance & Blokir IP (3NF, dapat diubah di Admin)
CREATE TABLE IF NOT EXISTS pengaturan_tampilan_sistem (
    kode_tampilan ENUM('maintenance', 'blocked') PRIMARY KEY,
    aktif BOOLEAN NOT NULL DEFAULT FALSE,
    judul VARCHAR(160) NOT NULL,
    pesan TEXT NOT NULL,
    teks_pita VARCHAR(160) NOT NULL,
    email_kontak VARCHAR(120) NOT NULL DEFAULT 'yusuf@biomatrix.id',
    target_menu VARCHAR(255) NOT NULL DEFAULT 'semua',
    updated_by BIGINT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_pts_user FOREIGN KEY (updated_by) REFERENCES users(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO pengaturan_tampilan_sistem (kode_tampilan, aktif, judul, pesan, teks_pita, email_kontak, target_menu) VALUES
('maintenance', FALSE, 'SISTEM SEDANG DALAM PERAWATAN (MAINTENANCE)', 'Tim BioMatrix sedang melakukan pemeliharaan server, kalibrasi sensor ESP32, dan peningkatan performa sistem. Silakan kembali beberapa saat lagi.', 'UNDER MAINTENANCE • DILARANG MELINTAS • BIOMATRIX SMART GREENHOUSE • ', 'yusuf@biomatrix.id', 'semua'),
('blocked', TRUE, 'AKSES PERANGKAT / IP ANDA DIBLOKIR', 'Alamat IP perangkat Anda telah diblokir oleh Administrator BioMatrix karena alasan keamanan. Jika Anda merasa ini sebuah kesalahan, silakan hubungi email pengelola di bawah ini.', 'ACCESS DENIED • IP DIBLOKIR • BIOMATRIX SECURITY SYSTEM • ', 'yusuf@biomatrix.id', 'login');

-- 4. Informasi Kontak Pengelola yang Dinamis (3NF)
CREATE TABLE IF NOT EXISTS info_kontak_pengelola (
    id_info TINYINT UNSIGNED PRIMARY KEY,
    nama_pengelola VARCHAR(100) NOT NULL,
    whatsapp VARCHAR(40) NOT NULL,
    email VARCHAR(120) NOT NULL,
    alamat VARCHAR(255) NULL,
    jam_operasional VARCHAR(100) NULL,
    updated_by BIGINT UNSIGNED NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_ikp_user FOREIGN KEY (updated_by) REFERENCES users(id_user) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT IGNORE INTO info_kontak_pengelola (id_info, nama_pengelola, whatsapp, email, alamat, jam_operasional) VALUES
(1, 'Yusuf Bhakti', '0827 1234 5678', 'yusuf@biomatrix.id', 'Lab SIJA Smart Greenhouse, Malang', 'Senin - Sabtu, 08:00 - 17:00 WIB');

-- 5. Tambahkan section Tentang Kami, Cara Kerja, dan Galeri & FAQ ke konten_website agar SEMUA background website utama bisa dikelola di Admin
INSERT IGNORE INTO konten_website (kunci_bagian, judul, subjudul, deskripsi, url_gambar, bg_size, bg_blur, bg_darkness, tampil, status_publikasi, is_custom, urutan) VALUES
('tentang_kami', 'Menghadirkan Teknologi untuk Pertanian yang Lebih Terarah.', 'Mengenal BioMatrix sebagai solusi integrasi teknologi digital dan lingkungan pertanian modern.', 'BioMatrix lahir dari semangat menggabungkan rekayasa perangkat keras IoT dengan kebutuhan budidaya modern agar petani dan pelajar dapat memantau iklim mikro tanaman secara presisi berbasis data.', '', 'cover', 0, 0, TRUE, 'published', FALSE, 2),
('cara_kerja', 'CARA KERJA BIOMATRIX IOT', 'Satu Jalur Kendali Terpadu dari Sensor hingga Database', 'Setiap pembacaan sensor dan perintah aktuator melewati validasi server terpusat agar kondisi lapangan selalu sinkron dengan dashboard.', '', 'cover', 0, 0, TRUE, 'published', FALSE, 4),
('galeri_faq', 'GALERI PROYEK & PERTANYAAN UMUM', 'DOKUMENTASI LAPANGAN & FAQ', 'Visualisasi greenhouse, ventilasi alami, serta jawaban cepat seputar instalasi paket dan operasional harian BioMatrix.', '', 'cover', 0, 0, TRUE, 'published', FALSE, 7);

UPDATE konten_website SET urutan = 1 WHERE kunci_bagian = 'hero';
UPDATE konten_website SET urutan = 2 WHERE kunci_bagian = 'tentang_kami';
UPDATE konten_website SET urutan = 3 WHERE kunci_bagian = 'inovasi';
UPDATE konten_website SET urutan = 4 WHERE kunci_bagian = 'cara_kerja';
UPDATE konten_website SET urutan = 5 WHERE kunci_bagian = 'paket';
UPDATE konten_website SET urutan = 6 WHERE kunci_bagian = 'monitoring';
UPDATE konten_website SET urutan = 7 WHERE kunci_bagian = 'galeri_faq';
UPDATE konten_website SET urutan = 8 WHERE kunci_bagian = 'kontak';
UPDATE konten_website SET urutan = 99 WHERE kunci_bagian = 'footer';

UPDATE pengaturan_sistem SET nilai='13.0.0' WHERE kunci='site_version';
