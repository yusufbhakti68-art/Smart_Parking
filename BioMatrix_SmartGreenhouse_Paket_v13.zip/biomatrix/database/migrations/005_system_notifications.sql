-- Migration 005: System Notifications & Global System Settings
USE biomatrix;

CREATE TABLE IF NOT EXISTS notifikasi (
    id_notifikasi BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    judul VARCHAR(120) NOT NULL,
    pesan TEXT NOT NULL,
    tingkat ENUM('info','peringatan','bahaya','sukses') NOT NULL DEFAULT 'info',
    dibaca BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pengaturan_sistem (
    kunci VARCHAR(60) PRIMARY KEY,
    nilai TEXT NULL,
    keterangan VARCHAR(200) NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO pengaturan_sistem (kunci, nilai, keterangan) VALUES
('site_name', 'BioMatrix Smart Greenhouse', 'Nama platform utama'),
('site_version', '12.0.0', 'Versi sistem aktif'),
('mqtt_host', '127.0.0.1', 'Alamat host broker MQTT sisi server'),
('mqtt_port', '1883', 'Port TCP broker MQTT'),
('timezone', 'Asia/Jakarta', 'Zona waktu operasional sistem'),
('maintenance_mode', '0', 'Status mode perawatan website (0=Off, 1=On)');

INSERT IGNORE INTO notifikasi (id_notifikasi, judul, pesan, tingkat) VALUES
(1, 'Upgrade v11 Berhasil', 'Platform BioMatrix v11 Full Control aktif dengan autentikasi session dan migrasi database aman.', 'sukses'),
(2, 'Jadwal Irigasi Aktif', 'Jadwal penyiraman rutin 2 jam sekali (durasi 2 menit) tersinkronisasi di database.', 'info');

UPDATE pengaturan_sistem SET nilai='12.0.0' WHERE kunci='site_version';
