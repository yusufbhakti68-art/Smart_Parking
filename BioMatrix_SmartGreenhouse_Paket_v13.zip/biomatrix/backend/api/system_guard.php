<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        bm_verify_csrf();
        $user = bm_require_roles(['admin']);
        $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $action = trim((string)($in['action'] ?? ''));

        if ($action === 'save_screen') {
            $kode = ($in['kode_tampilan'] ?? '') === 'blocked' ? 'blocked' : 'maintenance';
            $aktif = !empty($in['aktif']) ? 1 : 0;
            $judul = trim((string)($in['judul'] ?? ''));
            $pesan = trim((string)($in['pesan'] ?? ''));
            $pita  = trim((string)($in['teks_pita'] ?? ''));
            $email = trim((string)($in['email_kontak'] ?? 'yusuf@biomatrix.id'));
            $target = trim((string)($in['target_menu'] ?? 'semua'));

            $pdo->prepare("UPDATE pengaturan_tampilan_sistem SET aktif=?, judul=?, pesan=?, teks_pita=?, email_kontak=?, target_menu=?, updated_by=? WHERE kode_tampilan=?")
                ->execute([$aktif, $judul, $pesan, $pita, $email, $target, $user['id_user'], $kode]);
            if ($kode === 'maintenance') {
                $pdo->prepare("UPDATE pengaturan_sistem SET nilai=? WHERE kunci='maintenance_mode'")->execute([(string)$aktif]);
            }
            bm_log_activity($pdo, $user['id_user'], 'SYSTEM_SCREEN', "Ubah tampilan {$kode} (aktif={$aktif}, target={$target})");
            echo json_encode(['ok' => true, 'message' => "Pengaturan tampilan '{$kode}' berhasil disimpan!"]);
            exit;
        }

        if ($action === 'block_ip') {
            $ip = trim((string)($in['ip_address'] ?? ''));
            $dev = trim((string)($in['nama_perangkat'] ?? 'Perangkat Tidak Dikenal'));
            $alasan = trim((string)($in['alasan'] ?? 'Akses diblokir oleh Administrator'));
            if ($ip === '') {
                http_response_code(400);
                echo json_encode(['ok' => false, 'error' => 'Alamat IP wajib diisi']);
                exit;
            }
            $pdo->prepare("INSERT INTO blokir_perangkat (ip_address, nama_perangkat, alasan, aktif, diblokir_oleh) VALUES (?, ?, ?, 1, ?)
                           ON DUPLICATE KEY UPDATE nama_perangkat=VALUES(nama_perangkat), alasan=VALUES(alasan), aktif=1, diblokir_oleh=VALUES(diblokir_oleh)")
                ->execute([$ip, $dev, $alasan, $user['id_user']]);
            bm_log_activity($pdo, $user['id_user'], 'BLOCK_IP', "Memblokir IP {$ip} ({$alasan})");
            echo json_encode(['ok' => true, 'message' => "IP {$ip} berhasil diblokir!"]);
            exit;
        }

        if ($action === 'unblock_ip') {
            $id = (int)($in['id_blokir'] ?? 0);
            $pdo->prepare("DELETE FROM blokir_perangkat WHERE id_blokir=?")->execute([$id]);
            bm_log_activity($pdo, $user['id_user'], 'UNBLOCK_IP', "Membuka blokir IP #{$id}");
            echo json_encode(['ok' => true, 'message' => 'Blokir IP berhasil dibuka!']);
            exit;
        }

        if ($action === 'save_pengelola_bg') {
            $kode = trim((string)($in['kode_halaman'] ?? ''));
            $url  = trim((string)($in['url_gambar'] ?? ''));
            $size = in_array($in['bg_size'] ?? '', ['cover', 'contain', 'auto'], true) ? $in['bg_size'] : 'cover';
            $blur = max(0, min(20, (int)($in['bg_blur'] ?? 0)));
            $dark = max(0, min(90, (int)($in['bg_darkness'] ?? 70)));
            $pdo->prepare("UPDATE pengaturan_background_pengelola SET url_gambar=?, bg_size=?, bg_blur=?, bg_darkness=?, updated_by=? WHERE kode_halaman=?")
                ->execute([$url, $size, $blur, $dark, $user['id_user'], $kode]);
            bm_log_activity($pdo, $user['id_user'], 'BG_PENGELOLA', "Ubah background menu pengelola '{$kode}'");
            echo json_encode(['ok' => true, 'message' => "Background halaman pengelola '{$kode}' diperbarui!"]);
            exit;
        }

        if ($action === 'save_contact_info') {
            $nama = trim((string)($in['nama_pengelola'] ?? 'Yusuf Bhakti'));
            $wa   = trim((string)($in['whatsapp'] ?? ''));
            $email = trim((string)($in['email'] ?? ''));
            $alamat = trim((string)($in['alamat'] ?? ''));
            $jam  = trim((string)($in['jam_operasional'] ?? ''));
            $pdo->prepare("UPDATE info_kontak_pengelola SET nama_pengelola=?, whatsapp=?, email=?, alamat=?, jam_operasional=?, updated_by=? WHERE id_info=1")
                ->execute([$nama, $wa, $email, $alamat, $jam, $user['id_user']]);
            bm_log_activity($pdo, $user['id_user'], 'UPDATE_CONTACT_INFO', "Memperbarui kontak pengelola ({$nama}, {$email})");
            echo json_encode(['ok' => true, 'message' => 'Informasi Kontak Pengelola berhasil diperbarui!']);
            exit;
        }

        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Aksi tidak dikenal']);
        exit;
    }

    // GET: Public guard status + pengelola backgrounds + contact info
    $clientIp = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    $blkStmt = $pdo->prepare("SELECT * FROM blokir_perangkat WHERE ip_address=? AND aktif=1 LIMIT 1");
    $blkStmt->execute([$clientIp]);
    $blkRow = $blkStmt->fetch();

    $screens = [];
    foreach ($pdo->query("SELECT * FROM pengaturan_tampilan_sistem")->fetchAll() as $s) {
        $screens[$s['kode_tampilan']] = $s;
    }

    $contactInfo = $pdo->query("SELECT * FROM info_kontak_pengelola WHERE id_info=1 LIMIT 1")->fetch();
    $pengelolaBgs = $pdo->query("SELECT * FROM pengaturan_background_pengelola ORDER BY FIELD(kode_halaman,'login','dashboard','sensor','tanah','dht11','kipas','pompa','grafik','riwayat','pengaturan')")->fetchAll();

    $curUser = bm_current_user();
    $blockedList = [];
    if ($curUser && ($curUser['role'] ?? '') === 'admin') {
        $blockedList = $pdo->query("SELECT id_blokir, ip_address, nama_perangkat, alasan, aktif, DATE_FORMAT(created_at,'%d-%m-%Y %H:%i') AS waktu FROM blokir_perangkat ORDER BY id_blokir DESC")->fetchAll();
    }

    echo json_encode([
        'ok' => true,
        'client_ip' => $clientIp,
        'is_blocked' => (bool)$blkRow,
        'block_detail' => $blkRow ?: null,
        'maintenance' => $screens['maintenance'] ?? null,
        'blocked_screen' => $screens['blocked'] ?? null,
        'contact_info' => $contactInfo ?: null,
        'pengelola_backgrounds' => $pengelolaBgs,
        'blocked_list' => $blockedList,
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
