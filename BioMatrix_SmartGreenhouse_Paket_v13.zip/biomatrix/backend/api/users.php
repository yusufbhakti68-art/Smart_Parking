<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../middleware/permission.php';
require_once __DIR__ . '/../middleware/csrf.php';

try {
    require __DIR__ . '/../config/database.php';
    $user = bm_require_roles(['admin']);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        bm_verify_csrf();
        $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $action = $in['action'] ?? 'create';

                if ($action === 'change_password') {
            $id = (int)($in['id_user'] ?? 0);
            $newPass = (string)($in['new_password'] ?? '');
            if ($id <= 0 || strlen($newPass) < 4) {
                http_response_code(400);
                echo json_encode(['ok' => false, 'error' => 'Password baru minimal 4 karakter']);
                exit;
            }
            $hash = password_hash($newPass, PASSWORD_BCRYPT);
            $pdo->prepare("UPDATE users SET password_hash = ? WHERE id_user = ?")->execute([$hash, $id]);
            bm_log_activity($pdo, $user['id_user'], 'CHANGE_PASSWORD', "Mengubah password akun ID #{$id}");
            echo json_encode(['ok' => true, 'message' => 'Password akun berhasil diubah!']);
            exit;
        }

        if ($action === 'toggle_status') {
            $id = (int)($in['id_user'] ?? 0);
            if ($id === $user['id_user']) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Tidak dapat menonaktifkan akun sendiri']); exit; }
            $st = ($in['status_akun'] ?? 'aktif') === 'aktif' ? 'aktif' : 'nonaktif';
            $pdo->prepare("UPDATE users SET status_akun=? WHERE id_user=?")->execute([$st, $id]);
            bm_log_activity($pdo, $user['id_user'], 'USER_STATUS', "Ubah status akun #{$id} menjadi {$st}");
            echo json_encode(['ok' => true, 'message' => "Status akun diubah menjadi {$st}"]);
            exit;
        }

        $username = trim((string)($in['username'] ?? ''));
        $nama = trim((string)($in['nama_lengkap'] ?? 'Pengelola'));
        $pass = (string)($in['password'] ?? '');
        $role = in_array($in['role'] ?? '', ['admin','editor','read'], true) ? $in['role'] : 'editor';

        if ($username === '' || strlen($pass) < 4) {
            http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Username wajib diisi dan password minimal 4 karakter']); exit;
        }
        $hash = password_hash($pass, PASSWORD_BCRYPT);
        $pdo->prepare("INSERT INTO users (username, nama_lengkap, password_hash, role, status_akun) VALUES (?, ?, ?, ?, 'aktif')")
            ->execute([$username, $nama, $hash, $role]);
        bm_log_activity($pdo, $user['id_user'], 'ADD_USER', "Menambah akun {$username} ({$role})");
        echo json_encode(['ok' => true, 'message' => "Akun '{$username}' berhasil ditambahkan"]);
        exit;
    }

    $users = $pdo->query("SELECT id_user, username, nama_lengkap, role, status_akun, last_login, created_at FROM users ORDER BY id_user ASC")->fetchAll();
    $loginHistory = $pdo->query("SELECT id_login, username, ip_address, device_info, DATE_FORMAT(waktu_login,'%d-%m-%Y %H:%i:%s') AS waktu_format FROM riwayat_login ORDER BY id_login DESC LIMIT 40")->fetchAll();
    echo json_encode(['ok' => true, 'users' => $users, 'login_history' => $loginHistory]);
} catch (Throwable $e) {
    http_response_code(500); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
