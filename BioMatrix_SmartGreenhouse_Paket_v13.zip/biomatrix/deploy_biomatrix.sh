#!/bin/bash
set -e

echo "=================================================================="
echo "  BIOMATRIX v13 — AUTO-DEPLOY & UPGRADE (Ubuntu WSL2 / Linux)"
echo "=================================================================="

TARGET_DIR="/var/www/biomatrix"
CURRENT_DIR="$(realpath .)"

# 1. Backup instalasi & database lama jika sudah ada
BACKUP_DIR="/root/backup_biomatrix_$(date +%Y%m%d_%H%M%S)"
if [ -d "$TARGET_DIR" ]; then
    mkdir -p "$BACKUP_DIR"
    cp -r "$TARGET_DIR" "$BACKUP_DIR/files"
    mysqldump -u biomatrix -pbiomatrix123 biomatrix > "$BACKUP_DIR/biomatrix_backup.sql" 2>/dev/null || true
    echo "[BACKUP] Backup aman tersimpan di $BACKUP_DIR"
fi

# 2. Salin file ke /var/www/biomatrix HANYA jika skrip tidak dijalankan dari dalam /var/www/biomatrix
mkdir -p "$TARGET_DIR"
if [ "$CURRENT_DIR" != "$TARGET_DIR" ]; then
    cp -r ./* "$TARGET_DIR/"
fi
chown -R www-data:www-data "$TARGET_DIR"
chmod -R 755 "$TARGET_DIR"
chmod -R 775 "$TARGET_DIR/assets/uploads" 2>/dev/null || true

# 3. Pastikan layanan MariaDB aktif & user/database biomatrix tersedia
systemctl enable --now mariadb 2>/dev/null || service mariadb start || true
mysql -u root << 'EOF' 2>/dev/null || true
CREATE DATABASE IF NOT EXISTS biomatrix CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'biomatrix'@'localhost' IDENTIFIED BY 'biomatrix123';
CREATE USER IF NOT EXISTS 'biomatrix'@'127.0.0.1' IDENTIFIED BY 'biomatrix123';
CREATE USER IF NOT EXISTS 'biomatrix'@'%' IDENTIFIED BY 'biomatrix123';
GRANT ALL PRIVILEGES ON biomatrix.* TO 'biomatrix'@'localhost';
GRANT ALL PRIVILEGES ON biomatrix.* TO 'biomatrix'@'127.0.0.1';
GRANT ALL PRIVILEGES ON biomatrix.* TO 'biomatrix'@'%';
FLUSH PRIVILEGES;
EOF

# 4. Import skema dasar hanya jika tabel users belum ada (mencegah data lama terhapus)
DB_EXISTS=$(mysql -u biomatrix -pbiomatrix123 -N -e "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='biomatrix' AND TABLE_NAME='users';" 2>/dev/null || echo "0")
if [ "$DB_EXISTS" = "0" ]; then
    echo "[DB] Instalasi baru terdeteksi -> mengimpor biomatrix_v7_full.sql..."
    mysql -u biomatrix -pbiomatrix123 < "$TARGET_DIR/database/biomatrix_v7_full.sql"
fi

# 5. Jalankan seluruh migrasi database secara aman (backward-compatible)
for f in "$TARGET_DIR"/database/migrations/*.sql; do
    echo "[MIGRATION] Menjalankan $(basename "$f")..."
    mysql -u biomatrix -pbiomatrix123 biomatrix < "$f"
done

# 6. Sinkronkan hash password bcrypt asli PHP (admin/admin, pengelola/pengelola, viewer/viewer)
php "$TARGET_DIR/database/seed_passwords.php"

# 7. Pastikan Python venv & service worker MQTT (biomatrix-mqtt.service) siap
if [ ! -x "$TARGET_DIR/backend/mqtt/venv/bin/python" ]; then
    echo "[MQTT WORKER] Menyiapkan Python virtual environment..."
    python3 -m venv "$TARGET_DIR/backend/mqtt/venv"
    "$TARGET_DIR/backend/mqtt/venv/bin/pip" install --quiet paho-mqtt pymysql cryptography
fi

cat << 'EOF' > /etc/systemd/system/biomatrix-mqtt.service
[Unit]
Description=BioMatrix Smart Greenhouse v13 MQTT Worker, Scheduler & Automation
After=network.target mosquitto.service mariadb.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/biomatrix/backend/mqtt
Environment="DB_HOST=127.0.0.1"
Environment="DB_NAME=biomatrix"
Environment="DB_USER=biomatrix"
Environment="DB_PASS=biomatrix123"
Environment="MQTT_HOST=127.0.0.1"
Environment="MQTT_PORT=1883"
ExecStart=/var/www/biomatrix/backend/mqtt/venv/bin/python /var/www/biomatrix/backend/mqtt/worker.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload 2>/dev/null || true
systemctl enable --now biomatrix-mqtt.service 2>/dev/null || true
systemctl restart biomatrix-mqtt.service 2>/dev/null || true

# 8. Konfigurasi Nginx VirtualHost Port 8080 (/admin, /api/, /mqtt)
PHP_SOCK=$(find /run/php/ -name "php*-fpm.sock" 2>/dev/null | head -n 1)
if [ -z "$PHP_SOCK" ]; then
    echo "[ERROR] Socket PHP-FPM tidak ditemukan di /run/php/. Pastikan php-fpm berjalan!"
    exit 1
fi

cat << EOF > /etc/nginx/sites-available/biomatrix.conf
server {
    listen 8080;
    server_name _;

    root /var/www/biomatrix;
    index index.html index.php;

    location = /admin {
        return 301 /admin/;
    }

    location /admin/ {
        try_files \$uri \$uri/ /admin/index.html;
    }

    location ^~ /api/ {
        rewrite ^/api/(.*)$ /backend/api/\$1 last;
    }

    location /mqtt {
        proxy_pass http://127.0.0.1:9001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host \$host;
    }

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:$PHP_SOCK;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }
}
EOF

ln -sf /etc/nginx/sites-available/biomatrix.conf /etc/nginx/sites-enabled/biomatrix.conf
nginx -t && (systemctl reload nginx 2>/dev/null || service nginx reload)

SERVER_IP=$(hostname -I | awk '{print $1}')
echo "=================================================================="
echo "  BIOMATRIX v13 SIAP DIGUNAKAN!"
echo "  Website Utama & Login Pengelola : http://${SERVER_IP:-172.25.234.127}:8080/"
echo "  Admin Full Control (21 Menu)    : http://${SERVER_IP:-172.25.234.127}:8080/admin/"
echo "  Akun Default: admin/admin | pengelola/pengelola | viewer/viewer"
echo "=================================================================="
