// BIOMATRIX v11 — FULL CONTROL ADMIN ENGINE (PHP Session + CSRF + 21 Modules)
let csrfToken = '';
let admLiveChart = null, admHistoryChart = null;
let liveSoil = null, liveTemp = null, liveHum = null;

function showToast(msg, type = 'success') {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    el.className = `px-4 py-3 rounded-lg border text-xs font-semibold ${type === 'error' ? 'bg-[#FDECEC] border-[#F8B4B4] text-[#B91C1C]' : 'bg-[#17332A] border-[#234E3F] text-white'}`;
    el.textContent = msg;
    c.appendChild(el);
    setTimeout(() => el.remove(), 3200);
}

async function apiGet(url) {
    const res = await fetch(url, { cache: 'no-store' });
    return await res.json();
}

async function apiPost(url, payload) {
    const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
        body: JSON.stringify(payload)
    });
    return await res.json();
}

async function handleAdminLogin(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    try {
        const d = await apiPost('/api/auth/login.php', { username, password });
        if (d.ok && d.user) {
            if (d.user.role !== 'admin') {
                showToast('Akun ini bukan Admin. Silakan masuk melalui Login Dashboard Pengelola.', 'error');
                await fetch('/api/auth/logout.php', { method: 'POST' });
                return;
            }
            csrfToken = d.csrf_token || '';
            openAdmin(d.user);
            return;
        }
        showToast(d.error || 'Username atau kata sandi salah!', 'error');
    } catch (err) {
        showToast('Gagal terhubung ke server API PHP.', 'error');
    }
}

function openAdmin(user) {
    document.getElementById('adminLoginScreen').classList.add('hidden');
    document.getElementById('adminApp').classList.remove('hidden');
    document.getElementById('topbar-username').textContent = user.nama_lengkap || user.username || 'Admin';
    loadDashboard();
    initAdminMqtt();
}

async function logoutAdmin() {
    try { await fetch('/api/auth/logout.php', { method: 'POST' }); } catch (e) {}
    location.reload();
}

function switchTab(tab) {
    document.querySelectorAll('.page-content').forEach(el => el.classList.add('hidden'));
    document.getElementById(`page-${tab}`)?.classList.remove('hidden');
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('is-active'));
    document.querySelector(`.nav-btn[data-tab="${tab}"]`)?.classList.add('is-active');

    if (tab === 'dashboard') loadDashboard();
    if (tab === 'devices') loadDevices();
    if (tab === 'sensors') loadSensors();
    if (tab === 'actuators') loadActuators();
    if (tab === 'schedules') loadSchedules();
    if (tab === 'automation') loadRules();
    if (['analytics','history_sensor','history_actuator'].includes(tab)) loadHistory();
    if (['cms','navigation'].includes(tab)) loadCms();
    if (tab === 'media') loadMedia();
    if (tab === 'packages') loadPackages();
    if (tab === 'messages') loadMessages();
    if (['akun','security'].includes(tab)) loadUsers();
    if (tab === 'permissions') loadPermissions();
    if (tab === 'settings') loadSysSettings();
    if (tab === 'activity') loadActivity();
    if (['pengelola_bg', 'contact_info', 'maintenance', 'security'].includes(tab)) loadSystemGuardAdmin();
}

async function loadDashboard() {
    const d = await apiGet('/api/dashboard.php');
    if (!d.ok) return;
    document.getElementById('kpi-dev').textContent = `${d.kpi.devices_online}/${d.kpi.devices_total}`;
    document.getElementById('kpi-sen').textContent = d.kpi.sensors_active;
    document.getElementById('kpi-akt').textContent = d.kpi.actuators_on;
    document.getElementById('kpi-jad').textContent = d.kpi.schedules_active;

    const nb = document.getElementById('notif-badge');
    if (nb) {
        nb.textContent = d.kpi.unread_notifications;
        nb.classList.toggle('hidden', d.kpi.unread_notifications <= 0);
    }

    document.getElementById('dash-notifs').innerHTML = (d.notifications || []).map(n => `
        <div class="p-3 rounded-lg bg-[#F3F7F5] border border-[#D6E2DC] flex justify-between items-start gap-2">
            <div><div class="font-bold text-[#111827]">${n.judul}</div><div class="text-[#4B5563] mt-0.5">${n.pesan}</div></div>
            <span class="text-[10px] text-[#6B7280] shrink-0">${n.waktu}</span>
        </div>
    `).join('') || '<div class="text-[#6B7280]">Tidak ada notifikasi.</div>';

    document.getElementById('dash-activity').innerHTML = (d.recent_activity || []).map(a => `
        <div class="p-2.5 rounded-lg bg-[#F3F7F5] border border-[#E5EFEA]">
            <div class="flex justify-between"><span class="font-bold text-[#15803D]">${a.jenis_aktivitas}</span><span class="text-[10px] text-[#6B7280]">${a.waktu}</span></div>
            <div class="text-[#4B5563] mt-0.5">${a.deskripsi}</div>
        </div>
    `).join('') || '<div class="text-[#6B7280]">Belum ada aktivitas.</div>';
}

async function markNotificationsRead() {
    const d = await apiPost('/api/notifications.php', {});
    if (d.ok) { showToast(d.message); loadDashboard(); }
}

async function loadDevices() {
    const d = await apiGet('/api/devices.php');
    if (!d.ok) return;
    document.getElementById('devices-tbody').innerHTML = d.devices.map(dev => `
        <tr>
            <td class="p-3 font-bold text-[#17332A]">${dev.kode_perangkat}</td>
            <td class="p-3">${dev.nama_perangkat}</td>
            <td class="p-3 font-mono">${dev.versi_firmware || '-'}</td>
            <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] font-bold ${dev.status_koneksi==='online'?'bg-[#E5EFEA] text-[#15803D]':'bg-[#E5E7EB] text-[#4B5563]'}">${dev.status_koneksi}</span></td>
            <td class="p-3">${dev.id_perangkat > 1 ? `<button onclick="deleteDevice(${dev.id_perangkat})" class="text-[#B91C1C] font-bold">Hapus</button>` : '<span class="text-[#6B7280]">Utama</span>'}</td>
        </tr>
    `).join('');
}

async function addDevice(e) {
    e.preventDefault();
    const d = await apiPost('/api/devices.php', { kode_perangkat: document.getElementById('dev-kode').value, nama_perangkat: document.getElementById('dev-nama').value, versi_firmware: document.getElementById('dev-fw').value });
    if (d.ok) { showToast(d.message); e.target.reset(); loadDevices(); } else showToast(d.error || 'Gagal', 'error');
}

async function deleteDevice(id) {
    if (!confirm('Hapus perangkat ini?')) return;
    const d = await apiPost('/api/devices.php', { action: 'delete', id_perangkat: id });
    if (d.ok) { showToast(d.message); loadDevices(); }
}

async function loadSensors() {
    const d = await apiGet('/api/sensors.php');
    if (!d.ok) return;
    document.getElementById('sensors-grid').innerHTML = d.sensors.map(s => `
        <div class="bm-card p-5 space-y-3">
            <div class="flex justify-between items-center">
                <div><div class="font-bold text-sm text-[#111827]">${s.nama_sensor}</div><div class="text-[11px] text-[#6B7280]">${s.kode_instalasi} (${s.satuan})</div></div>
                <label class="bm-switch"><input type="checkbox" id="sen-st-${s.id_sensor_perangkat}" ${s.status_sensor==='Aktif'?'checked':''}><span class="bm-slider"></span></label>
            </div>
            <div class="grid grid-cols-3 gap-2">
                <div><label class="text-[10px] text-[#6B7280]">Min</label><input type="number" id="sen-min-${s.id_sensor_perangkat}" value="${s.nilai_min ?? 0}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
                <div><label class="text-[10px] text-[#6B7280]">Max</label><input type="number" id="sen-max-${s.id_sensor_perangkat}" value="${s.nilai_max ?? 100}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
                <div><label class="text-[10px] text-[#6B7280]">Offset</label><input type="number" step="0.1" id="sen-off-${s.id_sensor_perangkat}" value="${s.offset_kalibrasi ?? 0}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"></div>
            </div>
            <button onclick="saveSensor(${s.id_sensor_perangkat})" class="w-full py-2 rounded-lg bg-[#17332A] text-white text-xs font-bold">Simpan Sensor</button>
        </div>
    `).join('');
}

async function saveSensor(id) {
    const d = await apiPost('/api/sensors.php', {
        id_sensor_perangkat: id,
        status_sensor: document.getElementById(`sen-st-${id}`).checked ? 'Aktif' : 'Nonaktif',
        nilai_min: parseFloat(document.getElementById(`sen-min-${id}`).value || 0),
        nilai_max: parseFloat(document.getElementById(`sen-max-${id}`).value || 100),
        offset_kalibrasi: parseFloat(document.getElementById(`sen-off-${id}`).value || 0)
    });
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal', 'error');
}

async function loadActuators() {
    const d = await apiGet('/api/actuators.php');
    if (!d.ok) return;
    document.getElementById('actuators-grid').innerHTML = d.actuators.map(a => `
        <div class="bm-card p-5 space-y-4">
            <div class="flex justify-between items-center">
                <div><div class="font-bold text-base text-[#111827]">${a.nama_aktuator}</div><div class="text-xs text-[#6B7280]">Mode: <strong>${a.mode_kontrol}</strong> • Konfirmasi: ${a.status_konfirmasi || 'ok'}</div></div>
                <span class="px-3 py-1 rounded-md text-xs font-bold ${a.status_aktuator==='ON'?'bg-[#17332A] text-white':'bg-[#E5E7EB] text-[#4B5563]'}">${a.status_aktuator}</span>
            </div>
            <div class="grid grid-cols-3 gap-2">
                <button onclick="cmdActuator('${a.kode_aktuator}','ON')" class="py-2 rounded-lg bg-[#17332A] text-white text-xs font-bold">ON</button>
                <button onclick="cmdActuator('${a.kode_aktuator}','OFF')" class="py-2 rounded-lg bg-[#E5E7EB] text-[#111827] text-xs font-bold">OFF</button>
                <button onclick="cmdActuator('${a.kode_aktuator}','AUTO')" class="py-2 rounded-lg bg-[#E6F2F6] text-[#1D6F8A] text-xs font-bold">AUTO</button>
            </div>
        </div>
    `).join('');
}

async function cmdActuator(kode, status) {
    const d = await apiPost('/api/actuators.php', { aktuator: kode, status });
    if (d.ok) { showToast(`Perintah ${kode} -> ${status} dikirim via MQTT server`); loadActuators(); } else showToast(d.error || 'Gagal', 'error');
}

async function loadSchedules() {
    const d = await apiGet('/api/schedules.php');
    if (!d.ok) return;
    document.getElementById('schedules-tbody').innerHTML = d.schedules.map(s => `
        <tr>
            <td class="p-3 font-bold text-[#111827]">${s.nama_jadwal}</td>
            <td class="p-3">${s.nama_aktuator}</td>
            <td class="p-3 font-mono">${String(s.waktu_mulai).slice(0,5)}</td>
            <td class="p-3">${s.durasi_menit} mnt (${s.mode_pengulangan})</td>
            <td class="p-3"><input type="checkbox" ${Number(s.aktif)===1?'checked':''} onchange="toggleSchedule(${s.id_jadwal},this.checked)"></td>
            <td class="p-3"><button onclick="deleteSchedule(${s.id_jadwal})" class="text-[#B91C1C] font-bold">Hapus</button></td>
        </tr>
    `).join('');
}

async function addSchedule(e) {
    e.preventDefault();
    const d = await apiPost('/api/schedules.php', { nama_jadwal: document.getElementById('sch-nama').value, id_aktuator: document.getElementById('sch-akt').value, waktu_mulai: document.getElementById('sch-mulai').value + ':00', durasi_menit: document.getElementById('sch-durasi').value, mode_pengulangan: document.getElementById('sch-mode').value });
    if (d.ok) { showToast(d.message); e.target.reset(); loadSchedules(); }
}
async function toggleSchedule(id, aktif) { const d = await apiPost('/api/schedules.php', { action: 'toggle', id_jadwal: id, aktif: aktif?1:0 }); if (d.ok) showToast(d.message); }
async function deleteSchedule(id) { if (!confirm('Hapus jadwal ini?')) return; const d = await apiPost('/api/schedules.php', { action: 'delete', id_jadwal: id }); if (d.ok) { showToast(d.message); loadSchedules(); } }

async function loadRules() {
    const d = await apiGet('/api/rules.php');
    if (!d.ok) return;
    document.getElementById('rules-tbody').innerHTML = d.rules.map(r => `
        <tr>
            <td class="p-3 font-bold">${r.nama_aturan}</td>
            <td class="p-3">${r.nama_sensor} ${r.operator_kondisi} ${r.nilai_ambang}${r.satuan}</td>
            <td class="p-3 font-bold text-[#15803D]">${r.nama_aktuator} → ${r.status_tujuan}</td>
            <td class="p-3"><input type="checkbox" ${Number(r.aktif)===1?'checked':''} onchange="toggleRule(${r.id_aturan},this.checked)"></td>
            <td class="p-3"><button onclick="deleteRule(${r.id_aturan})" class="text-[#B91C1C] font-bold">Hapus</button></td>
        </tr>
    `).join('');
}

async function addRule(e) {
    e.preventDefault();
    const d = await apiPost('/api/rules.php', { nama_aturan: document.getElementById('rl-nama').value, id_sensor_perangkat: document.getElementById('rl-sensor').value, operator_kondisi: document.getElementById('rl-op').value, nilai_ambang: document.getElementById('rl-ambang').value, id_aktuator: document.getElementById('rl-akt').value, status_tujuan: document.getElementById('rl-tujuan').value });
    if (d.ok) { showToast(d.message); e.target.reset(); loadRules(); }
}
async function toggleRule(id, aktif) { const d = await apiPost('/api/rules.php', { action: 'toggle', id_aturan: id, aktif: aktif?1:0 }); if (d.ok) showToast(d.message); }
async function deleteRule(id) { if (!confirm('Hapus aturan ini?')) return; const d = await apiPost('/api/rules.php', { action: 'delete', id_aturan: id }); if (d.ok) { showToast(d.message); loadRules(); } }

async function loadHistory() {
    const d = await apiGet('/api/history.php?limit=40');
    if (!d.ok) return;
    document.getElementById('hist-sensor-tbody').innerHTML = d.sensor_history.map((r,i) => `<tr><td class="p-3">${i+1}</td><td class="p-3 font-mono">${r.waktu_format}</td><td class="p-3 font-bold">${r.suhu ?? '--'}</td><td class="p-3 font-bold">${r.kelembapan_udara ?? '--'}</td><td class="p-3 font-bold">${r.kelembapan_tanah ?? '--'}</td></tr>`).join('');
    document.getElementById('hist-act-tbody').innerHTML = d.actuator_history.map(r => `<tr><td class="p-3 font-mono">${r.waktu_format}</td><td class="p-3 font-bold">${r.nama_aktuator}</td><td class="p-3">${r.status_sebelumnya} → <strong>${r.status_baru}</strong></td><td class="p-3">${r.sumber_perintah}</td><td class="p-3">${r.username || 'Sistem'}</td></tr>`).join('');

    if (admHistoryChart && d.sensor_history.length > 0) {
        const rev = [...d.sensor_history].reverse();
        admHistoryChart.data.labels = rev.map(r => r.waktu_format.slice(11));
        admHistoryChart.data.datasets[0].data = rev.map(r => parseFloat(r.kelembapan_tanah || 0));
        admHistoryChart.data.datasets[1].data = rev.map(r => parseFloat(r.suhu || 0));
        admHistoryChart.data.datasets[2].data = rev.map(r => parseFloat(r.kelembapan_udara || 0));
        admHistoryChart.update('none');
    }
}

async function loadCms() {
    const d = await apiGet('/api/cms.php?mode=admin');
    if (!d.ok) return;
    document.getElementById('cms-editor-list').innerHTML = (d.konten_list || []).map(k => `
        <div class="bm-card p-5 space-y-3">
            <div class="flex justify-between items-center border-b border-[#E5EFEA] pb-2">
                <span class="font-bold text-sm text-[#17332A] uppercase">${k.kunci_bagian}</span>
                <div class="flex items-center gap-3 text-xs">
                    <select id="cms-pub-${k.kunci_bagian}" class="px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-[11px] font-bold">
                        <option value="published" ${k.status_publikasi!=='draft'?'selected':''}>Published</option>
                        <option value="draft" ${k.status_publikasi==='draft'?'selected':''}>Draft</option>
                    </select>
                    <label class="flex items-center gap-1"><input type="checkbox" id="cms-tampil-${k.kunci_bagian}" ${Number(k.tampil)===1?'checked':''}> Tampil</label>
                    ${Number(k.is_custom)===1 ? `<button onclick="deleteCustomPage('${k.kunci_bagian}')" class="text-[#B91C1C] font-bold">Hapus</button>` : ''}
                </div>
            </div>
            <div class="grid grid-cols-2 gap-2">
                <input type="text" id="cms-judul-${k.kunci_bagian}" value="${(k.judul||'').replace(/"/g,'&quot;')}" placeholder="Judul" class="px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                <input type="text" id="cms-sub-${k.kunci_bagian}" value="${(k.subjudul||'').replace(/"/g,'&quot;')}" placeholder="Subjudul" class="px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
            </div>
            <textarea rows="2" id="cms-desc-${k.kunci_bagian}" class="w-full px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">${k.deskripsi||''}</textarea>
            <input type="text" id="cms-img-${k.kunci_bagian}" value="${(k.url_gambar||'').replace(/"/g,'&quot;')}" placeholder="URL Gambar Background" class="w-full px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
            <div class="grid grid-cols-3 gap-2">
                <select id="cms-size-${k.kunci_bagian}" class="px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs"><option value="cover" ${k.bg_size==='cover'?'selected':''}>Cover</option><option value="contain" ${k.bg_size==='contain'?'selected':''}>Contain</option><option value="auto" ${k.bg_size==='auto'?'selected':''}>Auto</option></select>
                <input type="number" min="0" max="20" id="cms-blur-${k.kunci_bagian}" value="${k.bg_blur??0}" title="Blur px" class="px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                <input type="number" min="0" max="90" id="cms-dark-${k.kunci_bagian}" value="${k.bg_darkness??55}" title="Gelap %" class="px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
            </div>
            <button onclick="saveCmsSection('${k.kunci_bagian}')" class="px-4 py-2 rounded-lg bg-[#17332A] text-white text-xs font-bold">Simpan Perubahan</button>
        </div>
    `).join('');

    document.getElementById('menu-toggle-list').innerHTML = (d.menus || []).map(m => `
        <div class="bm-card p-4 flex items-center justify-between">
            <span class="font-bold text-sm text-[#111827]">${m.nama_menu}</span>
            <label class="bm-switch"><input type="checkbox" ${Number(m.tampil)===1?'checked':''} onchange="toggleMenu('${m.kode_menu}',this.checked)"><span class="bm-slider"></span></label>
        </div>
    `).join('');
}

async function saveCmsSection(kunci) {
    const d = await apiPost('/api/cms.php', {
        action: 'update_section', kunci_bagian: kunci,
        judul: document.getElementById(`cms-judul-${kunci}`).value,
        subjudul: document.getElementById(`cms-sub-${kunci}`).value,
        deskripsi: document.getElementById(`cms-desc-${kunci}`).value,
        url_gambar: document.getElementById(`cms-img-${kunci}`).value,
        bg_size: document.getElementById(`cms-size-${kunci}`).value,
        bg_blur: parseInt(document.getElementById(`cms-blur-${kunci}`).value || 0),
        bg_darkness: parseInt(document.getElementById(`cms-dark-${kunci}`).value || 55),
        tampil: document.getElementById(`cms-tampil-${kunci}`).checked ? 1 : 0,
        status_publikasi: document.getElementById(`cms-pub-${kunci}`).value
    });
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal', 'error');
}

async function addCustomPage(e) {
    e.preventDefault();
    const d = await apiPost('/api/cms.php', { action: 'add_section', judul: document.getElementById('new-pg-judul').value, subjudul: document.getElementById('new-pg-sub').value, url_gambar: document.getElementById('new-pg-img').value, bg_size: document.getElementById('new-pg-size').value, deskripsi: document.getElementById('new-pg-desc').value });
    if (d.ok) { showToast(d.message); e.target.reset(); document.getElementById('modal-add-page').classList.add('hidden'); loadCms(); }
}
async function deleteCustomPage(kunci) { if (!confirm('Hapus halaman?')) return; const d = await apiPost('/api/cms.php', { action: 'delete_section', kunci_bagian: kunci }); if (d.ok) { showToast(d.message); loadCms(); } }
async function toggleMenu(kode, tampil) { const d = await apiPost('/api/cms.php', { action: 'toggle_menu', kode_menu: kode, tampil: tampil?1:0 }); if (d.ok) showToast(d.message); }

async function loadMedia() {
    const d = await apiGet('/api/media.php');
    if (!d.ok) return;
    document.getElementById('media-grid').innerHTML = d.media.map(m => `
        <div class="bm-card overflow-hidden">
            <img src="${m.url_file}" class="w-full h-32 object-cover">
            <div class="p-3 space-y-1.5">
                <div class="font-bold text-xs truncate">${m.nama_file}</div>
                <div class="flex justify-between text-[11px]">
                    <button onclick="navigator.clipboard.writeText('${m.url_file}');showToast('URL disalin!')" class="text-[#15803D] font-bold">Salin URL</button>
                    <button onclick="deleteMedia(${m.id_media})" class="text-[#B91C1C] font-bold">Hapus</button>
                </div>
            </div>
        </div>
    `).join('');
}
async function addMedia(e) { e.preventDefault(); const d = await apiPost('/api/media.php', { nama_file: document.getElementById('med-nama').value, url_file: document.getElementById('med-url').value }); if (d.ok) { showToast(d.message); e.target.reset(); loadMedia(); } }
async function deleteMedia(id) { if (!confirm('Hapus media?')) return; const d = await apiPost('/api/media.php', { action: 'delete', id_media: id }); if (d.ok) { showToast(d.message); loadMedia(); } }

async function loadPackages() {
    const d = await apiGet('/api/packages.php');
    if (!d.ok) return;
    document.getElementById('packages-list').innerHTML = d.packages.map(p => `
        <div class="bm-card p-4 flex justify-between items-start gap-3">
            <div><div class="font-bold text-sm text-[#111827]">${p.nama_komponen} <span class="text-[10px] px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A]">${p.jumlah}</span></div><div class="text-xs text-[#4B5563] mt-1">${p.keterangan||''}</div></div>
            <button onclick="deletePackage(${p.id_komponen})" class="text-xs text-[#B91C1C] font-bold shrink-0">Hapus</button>
        </div>
    `).join('');
}
async function addPackage(e) { e.preventDefault(); const d = await apiPost('/api/packages.php', { nama_komponen: document.getElementById('pkg-nama').value, jumlah: document.getElementById('pkg-jml').value, keterangan: document.getElementById('pkg-ket').value }); if (d.ok) { showToast(d.message); e.target.reset(); loadPackages(); } }
async function deletePackage(id) { if (!confirm('Hapus komponen?')) return; const d = await apiPost('/api/packages.php', { action: 'delete', id_komponen: id }); if (d.ok) { showToast(d.message); loadPackages(); } }

async function loadMessages() {
    const d = await apiGet('/api/contact.php');
    if (!d.ok) return;
    document.getElementById('messages-tbody').innerHTML = d.messages.map(m => `
        <tr><td class="p-3 font-mono">${m.waktu}</td><td class="p-3"><strong>${m.nama_lengkap}</strong><br><span class="text-[#6B7280]">${m.email}</span></td><td class="p-3">${m.isi_pesan}</td><td class="p-3">${m.status_baca==='belum_dibaca'?`<button onclick="markMsgRead(${m.id_pesan})" class="px-2 py-1 rounded bg-[#17332A] text-white text-[10px] font-bold">Tandai Dibaca</button>`:'<span class="text-[#15803D] font-bold">Dibaca</span>'}</td></tr>
    `).join('') || '<tr><td colspan="4" class="p-4 text-center text-[#6B7280]">Belum ada pesan pengunjung.</td></tr>';
}
async function markMsgRead(id) { const d = await apiPost('/api/contact.php', { action: 'mark_read', id_pesan: id }); if (d.ok) { showToast(d.message); loadMessages(); } }

async function loadUsers() {
    const d = await apiGet('/api/users.php');
    if (!d.ok) return;
    document.getElementById('users-table-body').innerHTML = d.users.map(u => `
        <tr>
            <td class="p-3 font-bold text-[#17332A]">${u.username}</td>
            <td class="p-3">${u.nama_lengkap}</td>
            <td class="p-3"><span class="px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A] text-[10px] font-bold uppercase">${u.role}</span></td>
            <td class="p-3"><span class="px-2 py-0.5 rounded text-[10px] font-bold ${u.status_akun==='aktif'?'bg-[#E5EFEA] text-[#15803D]':'bg-[#FDECEC] text-[#B91C1C]'}">${u.status_akun||'aktif'}</span></td>
            <td class="p-3 flex items-center gap-3">
                <button onclick="changeUserPassword(${u.id_user}, '${u.username}')" class="text-xs font-bold text-[#15803D] hover:underline">Ganti Password</button>
                <button onclick="toggleUserStatus(${u.id_user},'${u.status_akun==='aktif'?'nonaktif':'aktif'}')" class="text-xs font-bold text-[#1D6F8A] hover:underline">${u.status_akun==='aktif'?'Nonaktifkan':'Aktifkan'}</button>
            </td>
        </tr>
    `).join('');
    document.getElementById('login-history-body').innerHTML = (d.login_history || []).map((r,i) => `
        <tr>
            <td class="p-3">${i+1}</td>
            <td class="p-3 font-bold text-[#17332A]">${r.username}</td>
            <td class="p-3 font-mono">${r.waktu_format}</td>
            <td class="p-3 font-mono">${r.ip_address||'-'}</td>
            <td class="p-3 font-semibold">${r.device_info||'-'}</td>
            <td class="p-3">${r.ip_address ? `<button onclick="quickBlockIp('${r.ip_address}', '${(r.device_info||'').replace(/'/g,'')}')" class="px-2.5 py-1 rounded bg-[#FDECEC] text-[#B91C1C] font-bold text-[10px] hover:bg-[#B91C1C] hover:text-white transition-colors">Blokir IP</button>` : '-'}</td>
        </tr>
    `).join('');
}
async function addUserAccount(e) { e.preventDefault(); const d = await apiPost('/api/users.php', { nama_lengkap: document.getElementById('new-user-nama').value, username: document.getElementById('new-user-username').value, password: document.getElementById('new-user-pass').value, role: document.getElementById('new-user-role').value }); if (d.ok) { showToast(d.message); e.target.reset(); loadUsers(); } else showToast(d.error||'Gagal','error'); }
async function toggleUserStatus(id, st) { const d = await apiPost('/api/users.php', { action: 'toggle_status', id_user: id, status_akun: st }); if (d.ok) { showToast(d.message); loadUsers(); } else showToast(d.error||'Gagal','error'); }

async function loadPermissions() {
    const d = await apiGet('/api/permissions.php');
    if (!d.ok) return;
    document.getElementById('permissions-list').innerHTML = d.roles.map(r => {
        const permIds = d.mappings.filter(m => m.id_role == r.id_role).map(m => m.id_permission);
        const list = d.permissions.filter(p => permIds.includes(p.id_permission)).map(p => `<li class="text-xs text-[#4B5563]">✓ ${p.nama_permission}</li>`).join('');
        return `<div class="bm-card p-5 space-y-2"><div class="font-extrabold text-sm text-[#15803D]">${r.nama_role} (${r.kode_role})</div><p class="text-[11px] text-[#6B7280]">${r.deskripsi||''}</p><ul class="space-y-1 pt-2 border-t border-[#E5EFEA]">${list}</ul></div>`;
    }).join('');
}

async function loadSysSettings() {
    const d = await apiGet('/api/settings.php');
    if (!d.ok) return;
    document.getElementById('sys-settings-list').innerHTML = (d.system || []).map(s => `
        <div class="bm-card p-4 space-y-2">
            <div class="font-bold text-xs text-[#17332A] uppercase">${s.kunci}</div>
            <div class="text-[11px] text-[#6B7280]">${s.keterangan||''}</div>
            <div class="flex gap-2">
                <input type="text" id="sys-${s.kunci}" value="${(s.nilai||'').replace(/"/g,'&quot;')}" class="flex-1 px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                <button onclick="saveSysKey('${s.kunci}')" class="px-3 py-1.5 rounded bg-[#17332A] text-white text-xs font-bold">Simpan</button>
            </div>
        </div>
    `).join('');
}
async function saveSysKey(k) { const d = await apiPost('/api/settings.php', { kunci: k, nilai: document.getElementById(`sys-${k}`).value }); if (d.ok) showToast(d.message); }

async function loadActivity() {
    const d = await apiGet('/api/activity.php');
    if (!d.ok) return;
    document.getElementById('activity-tbody').innerHTML = d.activities.map(a => `<tr><td class="p-3 font-mono">${a.waktu}</td><td class="p-3 font-bold">${a.username}</td><td class="p-3"><span class="px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A] text-[10px] font-bold">${a.jenis_aktivitas}</span></td><td class="p-3">${a.deskripsi}</td></tr>`).join('');
}

function initAdminMqtt() {
    if (typeof mqtt === 'undefined') return;
    const host = window.location.hostname || '127.0.0.1';
    const client = mqtt.connect(`ws://${host}:9001`, { reconnectPeriod: 3000, clean: true });
    client.on('connect', () => {
        document.getElementById('adm-mqtt-pill').textContent = 'MQTT Online';
        client.subscribe('biomatrix/sensor/tanah');
        client.subscribe('biomatrix/sensor/dht11');
    });
    client.on('message', (topic, msg) => {
        const val = msg.toString().trim();
        if (topic === 'biomatrix/sensor/tanah') { liveSoil = parseFloat(val); document.getElementById('mon-soil').textContent = `${liveSoil}%`; }
        if (topic === 'biomatrix/sensor/dht11') { try { const d = JSON.parse(val); liveTemp = parseFloat(d.suhu); liveHum = parseFloat(d.kelembapan); document.getElementById('mon-temp').textContent = `${liveTemp}°C`; document.getElementById('mon-hum').textContent = `${liveHum}%`; } catch(e){} }
        if (admLiveChart) {
            admLiveChart.data.labels.push(new Date().toTimeString().slice(0,8));
            admLiveChart.data.datasets[0].data.push(liveSoil ?? 0);
            admLiveChart.data.datasets[1].data.push(liveTemp ?? 0);
            admLiveChart.data.datasets[2].data.push(liveHum ?? 0);
            if (admLiveChart.data.labels.length > 15) { admLiveChart.data.labels.shift(); admLiveChart.data.datasets.forEach(ds => ds.data.shift()); }
            admLiveChart.update('none');
        }
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    setInterval(() => { const el = document.getElementById('current-datetime'); if (el) el.textContent = new Date().toLocaleString('id-ID') + ' WIB'; }, 1000);
    const cfg = { type: 'line', data: { labels: [], datasets: [{ label: 'Tanah (%)', data: [], borderColor: '#15803D', borderWidth: 2, tension: 0.3 }, { label: 'Suhu (°C)', data: [], borderColor: '#B45309', borderWidth: 2, tension: 0.3 }, { label: 'Udara (%)', data: [], borderColor: '#1D6F8A', borderWidth: 2, tension: 0.3 }] }, options: { responsive: true, maintainAspectRatio: false } };
    const c1 = document.getElementById('admLiveChart')?.getContext('2d'); if (c1) admLiveChart = new Chart(c1, JSON.parse(JSON.stringify(cfg)));
    const c2 = document.getElementById('admHistoryChart')?.getContext('2d'); if (c2) admHistoryChart = new Chart(c2, JSON.parse(JSON.stringify(cfg)));

    try {
        const me = await apiGet('/api/auth/me.php');
        if (me.ok && me.authenticated && me.user.role === 'admin') {
            csrfToken = me.csrf_token || '';
            openAdmin(me.user);
        }
    } catch (e) {}
});


// ===== v13 ADMIN FUNCTIONS: CHANGE PASSWORD, PENGELOLA BG, CONTACT INFO, MAINTENANCE & IP BLOCK =====
async function changeUserPassword(idUser, username) {
    const newPass = prompt(`Masukkan kata sandi baru untuk akun '${username}' (minimal 4 karakter):`);
    if (newPass === null) return;
    if (newPass.trim().length < 4) { showToast('Password minimal 4 karakter!', 'error'); return; }
    const d = await apiPost('/api/users.php', { action: 'change_password', id_user: idUser, new_password: newPass.trim() });
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal mengubah password', 'error');
}

async function loadSystemGuardAdmin() {
    const d = await apiGet('/api/system_guard.php');
    if (!d.ok) return;

    // 1. Render Pengelola Backgrounds (per page)
    const pbgEl = document.getElementById('pengelola-bg-list');
    if (pbgEl && Array.isArray(d.pengelola_backgrounds)) {
        pbgEl.innerHTML = d.pengelola_backgrounds.map(b => `
            <div class="bm-card p-5 space-y-3">
                <div class="flex items-center justify-between border-b border-[#E5EFEA] pb-2">
                    <span class="font-extrabold text-sm text-[#17332A]">${b.nama_halaman}</span>
                    <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A]">${b.kode_halaman}</span>
                </div>
                <div>
                    <label class="block text-[11px] font-semibold text-[#6B7280] mb-1">URL Gambar Background</label>
                    <input type="text" id="pbg-url-${b.kode_halaman}" value="${(b.url_gambar||'').replace(/"/g,'&quot;')}" class="w-full px-3 py-1.5 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                </div>
                <div class="grid grid-cols-3 gap-2">
                    <div>
                        <label class="block text-[10px] font-semibold text-[#6B7280] mb-1">Ukuran</label>
                        <select id="pbg-size-${b.kode_halaman}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                            <option value="cover" ${b.bg_size==='cover'?'selected':''}>Cover</option>
                            <option value="contain" ${b.bg_size==='contain'?'selected':''}>Contain</option>
                            <option value="auto" ${b.bg_size==='auto'?'selected':''}>Auto</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-semibold text-[#6B7280] mb-1">Blur (px)</label>
                        <input type="number" min="0" max="20" id="pbg-blur-${b.kode_halaman}" value="${b.bg_blur??0}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                    </div>
                    <div>
                        <label class="block text-[10px] font-semibold text-[#6B7280] mb-1">Gelap (%)</label>
                        <input type="number" min="0" max="90" id="pbg-dark-${b.kode_halaman}" value="${b.bg_darkness??70}" class="w-full px-2 py-1 rounded bg-[#F3F7F5] border border-[#D6E2DC] text-xs">
                    </div>
                </div>
                <button onclick="savePengelolaBg('${b.kode_halaman}')" class="px-4 py-2 rounded-lg bg-[#17332A] hover:bg-[#234E3F] text-white text-xs font-bold">Simpan Background</button>
            </div>
        `).join('');
    }

    // 2. Populate Contact Info form
    if (d.contact_info) {
        if (document.getElementById('ci-nama')) document.getElementById('ci-nama').value = d.contact_info.nama_pengelola || '';
        if (document.getElementById('ci-wa')) document.getElementById('ci-wa').value = d.contact_info.whatsapp || '';
        if (document.getElementById('ci-email')) document.getElementById('ci-email').value = d.contact_info.email || '';
        if (document.getElementById('ci-alamat')) document.getElementById('ci-alamat').value = d.contact_info.alamat || '';
        if (document.getElementById('ci-jam')) document.getElementById('ci-jam').value = d.contact_info.jam_operasional || '';
    }

    // 3. Populate Maintenance & Blocked Screen forms
    if (d.maintenance) {
        const m = d.maintenance;
        if (document.getElementById('scr-maintenance-aktif')) document.getElementById('scr-maintenance-aktif').checked = Number(m.aktif) === 1;
        if (document.getElementById('scr-maintenance-target')) document.getElementById('scr-maintenance-target').value = m.target_menu || 'semua';
        if (document.getElementById('scr-maintenance-judul')) document.getElementById('scr-maintenance-judul').value = m.judul || '';
        if (document.getElementById('scr-maintenance-pesan')) document.getElementById('scr-maintenance-pesan').value = m.pesan || '';
        if (document.getElementById('scr-maintenance-pita')) document.getElementById('scr-maintenance-pita').value = m.teks_pita || '';
        if (document.getElementById('scr-maintenance-email')) document.getElementById('scr-maintenance-email').value = m.email_kontak || '';
    }
    if (d.blocked_screen) {
        const b = d.blocked_screen;
        if (document.getElementById('scr-blocked-judul')) document.getElementById('scr-blocked-judul').value = b.judul || '';
        if (document.getElementById('scr-blocked-pesan')) document.getElementById('scr-blocked-pesan').value = b.pesan || '';
        if (document.getElementById('scr-blocked-pita')) document.getElementById('scr-blocked-pita').value = b.teks_pita || '';
        if (document.getElementById('scr-blocked-email')) document.getElementById('scr-blocked-email').value = b.email_kontak || '';
    }

    // 4. Render Blocked IP list
    const blkTb = document.getElementById('blocked-ip-tbody');
    if (blkTb) {
        blkTb.innerHTML = (d.blocked_list || []).map(r => `
            <tr>
                <td class="p-3 font-mono font-bold text-[#B91C1C]">${r.ip_address}</td>
                <td class="p-3">${r.nama_perangkat || '-'}</td>
                <td class="p-3">${r.alasan || '-'}</td>
                <td class="p-3 font-mono">${r.waktu || '-'}</td>
                <td class="p-3"><button onclick="unblockIp(${r.id_blokir})" class="px-2.5 py-1 rounded bg-[#E5EFEA] text-[#15803D] font-bold text-[10px]">Buka Blokir</button></td>
            </tr>
        `).join('') || '<tr><td colspan="5" class="p-4 text-center text-[#6B7280]">Belum ada perangkat/IP yang diblokir.</td></tr>';
    }
}

async function savePengelolaBg(kode) {
    const d = await apiPost('/api/system_guard.php', {
        action: 'save_pengelola_bg', kode_halaman: kode,
        url_gambar: document.getElementById(`pbg-url-${kode}`).value,
        bg_size: document.getElementById(`pbg-size-${kode}`).value,
        bg_blur: parseInt(document.getElementById(`pbg-blur-${kode}`).value || 0),
        bg_darkness: parseInt(document.getElementById(`pbg-dark-${kode}`).value || 70)
    });
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal', 'error');
}

async function saveContactInfo(e) {
    e.preventDefault();
    const d = await apiPost('/api/system_guard.php', {
        action: 'save_contact_info',
        nama_pengelola: document.getElementById('ci-nama').value,
        whatsapp: document.getElementById('ci-wa').value,
        email: document.getElementById('ci-email').value,
        alamat: document.getElementById('ci-alamat').value,
        jam_operasional: document.getElementById('ci-jam').value
    });
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal', 'error');
}

async function saveSystemScreen(e, kode) {
    e.preventDefault();
    const aktifEl = document.getElementById(`scr-${kode}-aktif`);
    const aktif = aktifEl.type === 'checkbox' ? (aktifEl.checked ? 1 : 0) : 1;
    const d = await apiPost('/api/system_guard.php', {
        action: 'save_screen', kode_tampilan: kode, aktif,
        target_menu: document.getElementById(`scr-${kode}-target`).value,
        judul: document.getElementById(`scr-${kode}-judul`).value,
        pesan: document.getElementById(`scr-${kode}-pesan`).value,
        teks_pita: document.getElementById(`scr-${kode}-pita`).value,
        email_kontak: document.getElementById(`scr-${kode}-email`).value
    });
    if (d.ok) showToast(d.message); else showToast(d.error || 'Gagal', 'error');
}

async function blockIpManual(e) {
    e.preventDefault();
    const d = await apiPost('/api/system_guard.php', {
        action: 'block_ip',
        ip_address: document.getElementById('blk-ip').value,
        nama_perangkat: document.getElementById('blk-dev').value,
        alasan: document.getElementById('blk-alasan').value
    });
    if (d.ok) { showToast(d.message); e.target.reset(); loadSystemGuardAdmin(); } else showToast(d.error || 'Gagal', 'error');
}

async function quickBlockIp(ip, dev) {
    if (!confirm(`Blokir perangkat dengan IP ${ip}?`)) return;
    const d = await apiPost('/api/system_guard.php', { action: 'block_ip', ip_address: ip, nama_perangkat: dev || 'Dari Riwayat Login', alasan: 'Diblokir oleh Administrator dari Riwayat Login' });
    if (d.ok) { showToast(d.message); loadSystemGuardAdmin(); } else showToast(d.error || 'Gagal', 'error');
}

async function unblockIp(id) {
    if (!confirm('Buka blokir IP ini?')) return;
    const d = await apiPost('/api/system_guard.php', { action: 'unblock_ip', id_blokir: id });
    if (d.ok) { showToast(d.message); loadSystemGuardAdmin(); }
}
