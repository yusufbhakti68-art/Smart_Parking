# BioMatrix v12 — Hasil Pemeriksaan Statis

Tanggal paket: 19 November 2026

## Pemeriksaan yang berhasil
- `node --check admin/assets/js/admin.js` — lulus.
- `node --check assets/js/public.js` — lulus.
- `php -l` untuk seluruh file PHP di `backend/` dan `database/` — lulus.
- `python -m py_compile` untuk worker MQTT, scheduler, automation, dan firmware ESP32 — lulus.
- `bash -n deploy_biomatrix.sh` — lulus.
- Pemeriksaan HTML: tidak ditemukan ID duplikat; setiap menu admin memiliki page yang sesuai.
- `nginx -t` pada konfigurasi server uji terisolasi yang memuat aturan routing, upload, maintenance, dan PHP — lulus.
- Pemeriksaan source: tidak ditemukan lagi kredensial database default v11 pada PHP config/worker/deploy; deploy tidak menjalankan seed password.

## Belum dapat diuji di lingkungan pembuatan paket
- Migration SQL belum dieksekusi terhadap database MariaDB/MySQL nyata karena klien/server database tidak tersedia di lingkungan ini.
- Login, CRUD database, upload file via PHP-FPM, MQTT broker, scheduler, dan hardware ESP32 belum menjalani integration test langsung.
- Sebelum produksi, lakukan backup, jalankan migration di staging, dan uji seluruh alur sesuai `PANDUAN_PEMASANGAN_V12.md`.

## Batasan hardware
Pendaftaran sensor/aktuator menambah konfigurasi database. Sensor baru memerlukan mapping pembacaan di worker/firmware; aktuator baru memerlukan mapping GPIO/topic yang didukung firmware ESP32. Kipas dan pompa v11 tetap dipertahankan.
