// ============================================================================
// BIOMATRIX v8 — PUBLIC LANDING + ORIGINAL LOGIN & PENGELOLA DASHBOARD ENGINE
// ============================================================================
let publicChart = null, dashChart = null, soilChart = null, dhtChart = null;
let chartSuhu = null, chartUdara = null, chartTanah2 = null, chartAktuator = null;
let globalMqtt = null;
let dbHistoryCache = [];
let liveSoil = null, liveTemp = null, liveHum = null;
let isKipasOn = false, isPompaOn = false;
let sensorActiveMap = { SOIL: true, TEMP: true, HUM: true };
let bmCsrfToken = '';

const DEFAULT_PAKET = [
    { nama_komponen: 'Mikrokontroler ESP32', jumlah: '1 Unit', keterangan: 'Otak pemrosesan IoT dengan Wi-Fi terintegrasi.', ikon: 'fa-microchip' },
    { nama_komponen: 'Sensor DHT11', jumlah: '1 Unit', keterangan: 'Memantau suhu dan kelembapan udara ruang greenhouse.', ikon: 'fa-temperature-half' },
    { nama_komponen: 'Sensor Kelembapan Tanah', jumlah: '1 Unit', keterangan: 'Mendeteksi kadar air media tanam secara akurat.', ikon: 'fa-seedling' },
    { nama_komponen: 'Pompa Air DC 12V', jumlah: '1 Unit', keterangan: 'Pompa penyiraman otomatis & terjadwal 2 jam sekali.', ikon: 'fa-faucet-drip' },
    { nama_komponen: 'Adaptor Daya 10V', jumlah: '1 Unit', keterangan: 'Catu daya stabil untuk mengoperasikan sistem kontrol.', ikon: 'fa-plug' },
    { nama_komponen: 'Box Pelindung ESP32', jumlah: '1 Unit', keterangan: 'Kotak pelindung rangkaian dari cipratan air.', ikon: 'fa-box' },
    { nama_komponen: 'Miniatur Rumah Greenhouse', jumlah: '1 Unit', keterangan: 'Prototipe miniatur rumah-rumahan greenhouse siap pakai.', ikon: 'fa-house' }
];

function showToast(message, type = 'success') {
    const c = document.getElementById('toast-container');
    if (!c) return;
    const el = document.createElement('div');
    const cls = type === 'error'
        ? 'bg-red-950 border-red-500 text-red-200'
        : 'bg-[#082b21] border-[#00e699] text-emerald-100';
    el.className = `pointer-events-auto px-4 py-3 rounded-xl border text-xs font-semibold shadow-lg ${cls}`;
    el.textContent = message;
    c.appendChild(el);
    setTimeout(() => el.remove(), 3000);
}

// ============================================================================
// 1. LOGIN & NAVIGASI KE DASHBOARD PENGELOLA (ORIGINAL)
// ============================================================================
function showPengelolaLogin() {
    document.getElementById('landingPage').style.display = 'none';
    document.getElementById('loginScreen').style.display = 'flex';
}

function closePengelolaLogin() {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('landingPage').style.display = 'block';
}

function showDashboardAfterLogin() {
    document.getElementById('landingPage').style.display = 'none';
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('dashboardApp').style.display = 'flex';
    applyPengelolaRole();
    fetchDatabaseState();
}

function isReadOnlyUser() {
    return sessionStorage.getItem('greenhouseRole') === 'read';
}

function applyPengelolaRole() {
    const role = sessionStorage.getItem('greenhouseRole') || 'editor';
    const userName = sessionStorage.getItem('greenhouseUser') || 'Pengelola';

    const welcomeEl = document.getElementById('pengelola-welcome-text');
    const profEl = document.getElementById('pengelola-profile-name');
    const badgeEl = document.getElementById('pengelola-role-badge');
    if (welcomeEl) welcomeEl.textContent = `Selamat Datang, ${userName}`;
    if (profEl) profEl.textContent = userName;
    if (badgeEl) {
        badgeEl.classList.remove('hidden');
        if (role === 'read') {
            badgeEl.textContent = 'Lihat Saja (Read-Only)';
            badgeEl.className = 'text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-600 font-semibold';
        } else {
            badgeEl.textContent = role === 'admin' ? 'Admin' : 'Editor';
            badgeEl.className = 'text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 font-semibold';
        }
    }

    const readOnly = (role === 'read');
    // Disable/enable actuator switches & manual buttons
    document.querySelectorAll('.toggle-kipas-input, .toggle-pompa-input').forEach(el => {
        el.disabled = readOnly;
        el.closest('label')?.classList.toggle('opacity-50', readOnly);
        el.closest('label')?.classList.toggle('cursor-not-allowed', readOnly);
    });
    document.querySelectorAll('#page-kipas button, #page-pompa button, #btn-save-settings').forEach(btn => {
        btn.disabled = readOnly;
        btn.classList.toggle('opacity-40', readOnly);
        btn.classList.toggle('cursor-not-allowed', readOnly);
    });
    document.querySelectorAll('#page-pengaturan input, #page-pengaturan select').forEach(el => {
        el.disabled = readOnly;
    });
}

async function handleGreenhouseLogin(event) {
    event.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;

    try {
        const res = await fetch('/api/auth/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const d = await res.json();
        if (res.ok && d.ok) {
            sessionStorage.setItem('greenhouseLoggedIn', 'true');
            sessionStorage.setItem('greenhouseUser', d.user?.nama_lengkap || username);
            sessionStorage.setItem('greenhouseRole', d.user?.role || 'editor');
            bmCsrfToken = d.csrf_token || '';
            showDashboardAfterLogin();
            return;
        }
    } catch (err) {}

    alert('Username atau kata sandi salah! Pastikan server PHP & MariaDB berjalan.');
}

function togglePassword() {
    const input = document.getElementById('loginPassword');
    const icon = document.getElementById('eyeIcon');
    if (!input || !icon) return;
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

async function logoutUser() {
    try { await fetch('/api/auth/logout.php', { method: 'POST' }); } catch (e) {}
    sessionStorage.removeItem('greenhouseLoggedIn');
    sessionStorage.removeItem('greenhouseRole');
    location.reload();
}

function switchTab(tabId) {
    document.querySelectorAll('.page-content').forEach(el => el.classList.add('hidden'));
    const activePage = document.getElementById(`page-${tabId}`);
    if (activePage) activePage.classList.remove('hidden');

    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('bg-[#0e4334]', 'text-white', 'glow-green');
        btn.classList.add('text-emerald-200/70');
    });

    const activeBtn = document.querySelector(`.nav-btn[data-tab="${tabId}"]`);
    if (activeBtn) {
        activeBtn.classList.add('bg-[#0e4334]', 'text-white', 'glow-green');
        activeBtn.classList.remove('text-emerald-200/70');
    }

    if (window.innerWidth < 1024) {
        document.getElementById('sidebar')?.classList.add('hidden');
    }
}

// ============================================================================
// 2. CMS LANDING PAGE & PAKET PERANGKAT
// ============================================================================
function renderPaket(items) {
    const container = document.getElementById('paket-komponen-list');
    if (!container) return;
    container.innerHTML = items.map(it => `
        <div class="bg-white border border-[#D6E2DC] rounded-xl p-4 flex items-start gap-3">
            <div class="w-9 h-9 rounded-lg bg-[#E5EFEA] text-[#17332A] flex items-center justify-center shrink-0">
                <i class="fa-solid ${it.ikon || 'fa-cube'}"></i>
            </div>
            <div>
                <div class="flex items-center gap-2">
                    <span class="font-bold text-sm text-[#111827]">${bmEscapeHtml(it.nama_komponen)}</span>
                    <span class="text-[10px] font-bold px-2 py-0.5 rounded bg-[#E5EFEA] text-[#17332A]">${bmEscapeHtml(it.jumlah)}</span>
                </div>
                <p class="text-xs text-[#6B7280] mt-1 leading-relaxed">${bmEscapeHtml(it.keterangan || '')}</p>
            </div>
        </div>
    `).join('');
}

function applySectionStyling(key, sec) {
    const mapSectionId = { hero: 'home', tentang:'tentang', inovasi: 'inovasi', fitur:'fitur', 'cara-kerja':'cara-kerja', paket: 'paket', manfaat:'manfaat', 'galeri-faq':'galeri-faq', monitoring: 'live-monitoring', simulasi:'simulasi', kontak: 'kontak' };
    const secEl = document.getElementById(mapSectionId[key]);
    if (secEl && sec.tampil !== undefined) secEl.style.display = Number(sec.tampil) === 1 ? '' : 'none';

    const elJ = document.getElementById(`cms-${key}-judul`);
    const elS = document.getElementById(`cms-${key}-subjudul`);
    const elD = document.getElementById(`cms-${key}-deskripsi`);
    const elI = document.getElementById(`cms-${key}-img`);
    const elOv = document.getElementById(`cms-${key}-overlay`);

    if (elJ && sec.judul) {
        const words = sec.judul.trim().split(' ');
        if (words.length > 1 && ['hero', 'inovasi', 'paket', 'kontak'].includes(key)) {
            const first = words[0];
            const rest = words.slice(1).join(' ');
            const accent = (key === 'hero' || key === 'kontak') ? 'text-[#34D399]' : 'text-[#15803D]';
            elJ.innerHTML = `${bmEscapeHtml(first)} <span class="${accent}">${bmEscapeHtml(rest)}</span>`;
        } else {
            elJ.textContent = sec.judul;
        }
    }
    if (elS && sec.subjudul) elS.textContent = sec.subjudul;
    if (elD && sec.deskripsi) elD.textContent = sec.deskripsi;
    if (elI) {
        if (sec.url_gambar) { elI.src=sec.url_gambar; elI.style.display=''; elI.style.objectFit=sec.bg_size||'cover'; elI.style.filter=`blur(${sec.bg_blur||0}px)`; }
        else { elI.style.display='none'; }
    }
    if (elOv && sec.bg_darkness !== undefined) elOv.style.opacity = (Number(sec.bg_darkness) / 100).toFixed(2);
    if (secEl && !elI) {
        if (sec.url_gambar) {
            const safeUrl=String(sec.url_gambar).replace(/[\"\\\n\r]/g,'');
            const dark=Math.max(0,Math.min(90,Number(sec.bg_darkness??35)))/100;
            secEl.style.backgroundImage=`linear-gradient(rgba(12,35,26,${dark}),rgba(12,35,26,${dark})),url("${safeUrl}")`;
            secEl.style.backgroundSize=sec.bg_size||'cover'; secEl.style.backgroundPosition='center'; secEl.style.backgroundRepeat='no-repeat';
        } else { secEl.style.backgroundImage=''; }
    }
}

function bmEscapeHtml(value){return String(value??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));}
function renderPublicCustomNav(navList){const links=(navList||[]).filter(n=>Number(n.tampil)===1&&String(n.target_section).startsWith('sec-'));const desktop=document.getElementById('public-nav-dynamic');const mobile=document.getElementById('mobile-nav-dynamic');if(desktop)desktop.innerHTML=links.map(n=>`<a href="#${bmEscapeHtml(n.target_section)}" class="hover:text-white transition-colors">${bmEscapeHtml(n.label)}</a>`).join('');if(mobile)mobile.innerHTML=links.map(n=>`<a href="#${bmEscapeHtml(n.target_section)}" class="block py-1.5 hover:text-white">${bmEscapeHtml(n.label)}</a>`).join('');}
function renderCustomPages(list) {
    const c = document.getElementById('custom-pages-container');
    if (!c) return;
    const customs = list.filter(item => Number(item.is_custom) === 1 && Number(item.tampil) === 1);
    c.innerHTML = customs.map(sec => {
        const hasImg = sec.url_gambar && sec.url_gambar.trim() !== '';
        const blurPx = Number(sec.bg_blur || 0);
        const darkOp = (Number(sec.bg_darkness || 55) / 100).toFixed(2);
        const bgSize = sec.bg_size || 'cover';
        return `
            <section id="sec-${bmEscapeHtml(sec.kunci_bagian)}" class="relative py-20 overflow-hidden border-t border-[#D6E2DC] ${hasImg ? 'bg-[#17332A] text-white' : 'bg-white text-[#111827]'}">
                ${hasImg ? `<img src="${bmEscapeHtml(sec.url_gambar)}" alt="" class="absolute inset-0 w-full h-full" style="object-fit:${bgSize};filter:blur(${blurPx}px);">
                <div class="absolute inset-0 bg-[#17332A]" style="opacity:${darkOp};"></div>` : ''}
                <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <span class="text-xs font-bold tracking-widest uppercase ${hasImg ? 'text-[#A7E3C6]' : 'text-[#234E3F]'}">${bmEscapeHtml(sec.subjudul || '')}</span>
                    <h2 class="text-3xl font-extrabold mt-2 ${hasImg ? 'text-white' : 'text-[#111827]'}">${bmEscapeHtml(sec.judul)}</h2>
                    <p class="mt-4 text-sm sm:text-base max-w-3xl leading-relaxed ${hasImg ? 'text-[#E5E7EB]' : 'text-[#6B7280]'}">${bmEscapeHtml(sec.deskripsi || '')}</p>
                </div>
            </section>
        `;
    }).join('');
}

async function loadCmsContent() {
    renderPaket(DEFAULT_PAKET);
    try {
        const res = await fetch('/api/cms.php', { cache: 'no-store' });
        if (!res.ok) return;
        const data = await res.json();
        if (!data.ok) return;
        const k = data.konten || {};
        ['hero','tentang','inovasi','fitur','cara-kerja','paket','manfaat','galeri-faq','monitoring','simulasi','kontak','footer'].forEach(key => { if (k[key]) applySectionStyling(key, k[key]); });
        if (Array.isArray(data.konten_list)) renderCustomPages(data.konten_list);
        if (Array.isArray(data.nav_public)) renderPublicCustomNav(data.nav_public);
        if (Array.isArray(data.paket) && data.paket.length > 0) renderPaket(data.paket);
        if (Array.isArray(data.sensors)) data.sensors.forEach(s => { sensorActiveMap[s.kode_sensor] = (s.status_sensor === 'Aktif'); });
        if (Array.isArray(data.menus)) data.menus.forEach(m => {
            const btn = document.querySelector(`.nav-btn[data-tab="${m.kode_menu}"]`);
            if (btn) btn.style.display = Number(m.tampil) === 1 ? '' : 'none';
        });
    } catch (e) {}
}

// ============================================================================
// 3. SINKRONISASI DATABASE & UPDATE UI DASHBOARD PENGELOLA (ORIGINAL)
// ============================================================================
function updateKipasUI(state) {
    document.querySelectorAll('.toggle-kipas-input').forEach(i => i.checked = state);
    document.querySelectorAll('.label-kipas-text').forEach(t => t.innerText = state ? 'Aktif (Menyala)' : 'Mati');
    document.querySelectorAll('.card-kipas-text').forEach(t => t.innerText = state ? 'Aktif' : 'Mati');
    document.querySelectorAll('.card-kipas-badge').forEach(b => b.innerText = state ? 'Aktif' : 'Nonaktif');
    document.querySelectorAll('.icon-kipas-box').forEach(box => {
        const icon = box.querySelector('i');
        if (icon) {
            icon.classList.toggle('animate-spin', state);
            icon.classList.toggle('text-[#00e699]', state);
            icon.classList.toggle('text-slate-400', !state);
        }
    });
    const pubBadge = document.getElementById('public-fan-badge');
    if (pubBadge) {
        pubBadge.className = state ? 'px-2.5 py-1 rounded-md text-[10px] font-bold bg-[#17332A] text-white' : 'px-2.5 py-1 rounded-md text-[10px] font-bold bg-[#E5E7EB] text-[#4B5563]';
        pubBadge.textContent = state ? 'HIDUP' : 'MATI';
    }
}

function updatePompaUI(state) {
    document.querySelectorAll('.toggle-pompa-input').forEach(i => i.checked = state);
    document.querySelectorAll('.label-pompa-text').forEach(t => t.innerText = state ? 'Aktif (Menyala)' : 'Mati');
    document.querySelectorAll('.card-pompa-text').forEach(t => t.innerText = state ? 'Aktif' : 'Mati');
    document.querySelectorAll('.card-pompa-badge').forEach(b => b.innerText = state ? 'Aktif' : 'Nonaktif');
    document.querySelectorAll('.icon-pompa-box').forEach(box => {
        const icon = box.querySelector('i');
        if (icon) {
            icon.classList.toggle('animate-bounce', state);
            icon.classList.toggle('text-blue-400', state);
            icon.classList.toggle('text-slate-400', !state);
        }
    });
    const pubBadge = document.getElementById('public-pump-badge');
    if (pubBadge) {
        pubBadge.className = state ? 'px-2.5 py-1 rounded-md text-[10px] font-bold bg-[#17332A] text-white' : 'px-2.5 py-1 rounded-md text-[10px] font-bold bg-[#E5E7EB] text-[#4B5563]';
        pubBadge.textContent = state ? 'HIDUP' : 'MATI';
    }
}

async function toggleActuator(type, state) {
    if (isReadOnlyUser()) {
        showToast('Akun Anda hanya memiliki akses Lihat Saja (Read-Only).', 'error');
        updateKipasUI(isKipasOn);
        updatePompaUI(isPompaOn);
        return;
    }
    const cmd = state ? 'ON' : 'OFF';
    try {
        const res = await fetch('/api/actuators.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': bmCsrfToken },
            body: JSON.stringify({ aktuator: type, status: cmd })
        });
        const d = await res.json();
        if (!res.ok) { showToast(d.error || 'Gagal mengirim perintah', 'error'); return; }
    } catch (e) { showToast('Server API tidak merespons', 'error'); return; }

    if (type === 'kipas') { isKipasOn = state; updateKipasUI(state); showToast(`Kipas ${state ? 'Dinyalakan' : 'Dimatikan'}`); }
    if (type === 'pompa') { isPompaOn = state; updatePompaUI(state); showToast(`Pompa ${state ? 'Dinyalakan' : 'Dimatikan'}`); }
}

async function fetchDatabaseState() {
    try {
        const res = await fetch('/api/state.php', { cache: 'no-store' });
        const d = await res.json();
        if (!d.ok) return;
        if (Array.isArray(d.menus)) {
            d.menus.forEach(m => {
                const btn = document.querySelector(`.nav-btn[data-tab="${m.kode_menu}"]`);
                if (btn) btn.style.display = Number(m.tampil) === 1 ? '' : 'none';
            });
        }
        if (Array.isArray(d.history)) {
            dbHistoryCache = d.history;
            const tb = document.getElementById('riwayat-table-body');
            if (tb) {
                tb.innerHTML = d.history.map((r, i) => `
                    <tr>
                        <td class="p-3">${i + 1}</td>
                        <td class="p-3 font-mono">${r.waktu_format}</td>
                        <td class="p-3 font-semibold text-white">${r.suhu ?? '--'}</td>
                        <td class="p-3 font-semibold text-white">${r.kelembapan_udara ?? '--'}</td>
                        <td class="p-3 font-semibold text-white">${r.kelembapan_tanah ?? '--'}</td>
                        <td class="p-3"><span class="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px]">${isKipasOn ? 'Aktif' : 'Mati'}</span></td>
                        <td class="p-3"><span class="bg-slate-800 text-slate-300 px-2 py-0.5 rounded text-[10px]">${isPompaOn ? 'Aktif' : 'Mati'}</span></td>
                    </tr>
                `).join('');
            }
        }
    } catch (e) {}
}

function exportToCSV() {
    const rows = [["No", "Waktu", "Suhu", "Kelembapan Udara", "Kelembapan Tanah"]];
    dbHistoryCache.forEach((r, i) => rows.push([i + 1, r.waktu_format, r.suhu, r.kelembapan_udara, r.kelembapan_tanah]));
    const a = document.createElement('a');
    a.href = encodeURI("data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n"));
    a.download = "riwayat_sensor_biomatrix.csv";
    a.click();
    showToast('File CSV berhasil diunduh');
}

function pushLiveCharts() {
    const label = new Date().toTimeString().slice(0, 8);
    [publicChart, dashChart].forEach(ch => {
        if (!ch) return;
        ch.data.labels.push(label);
        ch.data.datasets[0].data.push(liveSoil ?? 0);
        ch.data.datasets[1].data.push(liveTemp ?? 0);
        ch.data.datasets[2].data.push(liveHum ?? 0);
        if (ch.data.labels.length > 15) { ch.data.labels.shift(); ch.data.datasets.forEach(ds => ds.data.shift()); }
        ch.update('none');
    });
    if (soilChart && liveSoil !== null) {
        soilChart.data.labels.push(label);
        soilChart.data.datasets[0].data.push(liveSoil);
        if (soilChart.data.labels.length > 15) { soilChart.data.labels.shift(); soilChart.data.datasets[0].data.shift(); }
        soilChart.update('none');
    }
    if (dhtChart && liveTemp !== null) {
        dhtChart.data.labels.push(label);
        dhtChart.data.datasets[0].data.push(liveTemp);
        dhtChart.data.datasets[1].data.push(liveHum ?? 0);
        if (dhtChart.data.labels.length > 15) { dhtChart.data.labels.shift(); dhtChart.data.datasets[0].data.shift(); dhtChart.data.datasets[1].data.shift(); }
        dhtChart.update('none');
    }
}

function initMqtt() {
    if (typeof mqtt === 'undefined') return;
    const host = window.location.hostname || '127.0.0.1';
    const client = mqtt.connect(`ws://${host}:9001`, { reconnectPeriod: 3000, clean: true });
    globalMqtt = client;

    client.on('connect', () => {
        const pill = document.getElementById('public-mqtt-pill');
        if (pill) pill.innerHTML = '<span class="w-2 h-2 rounded-full bg-[#234E3F]"></span><span>ESP32 Terhubung</span>';
        const st = document.getElementById('hero-status'); if (st) st.textContent = 'Online';
        const psb = document.getElementById('public-sensor-badge');
        if (psb) { psb.className = 'px-2.5 py-1 rounded-md text-[10px] font-bold bg-[#17332A] text-white'; psb.textContent = 'HIDUP'; }

        client.subscribe('biomatrix/sensor/tanah');
        client.subscribe('biomatrix/sensor/dht11');
        client.subscribe('biomatrix/kipas');
        client.subscribe('biomatrix/pompa');
    });

    client.on('message', (topic, msg) => {
        const val = msg.toString().trim();
        if (topic === 'biomatrix/sensor/tanah' && sensorActiveMap.SOIL) {
            const soil = parseFloat(val);
            if (!isNaN(soil)) {
                liveSoil = soil;
                if (document.getElementById('hero-soil')) document.getElementById('hero-soil').textContent = `${soil}%`;
                if (document.getElementById('dash-soil')) document.getElementById('dash-soil').textContent = `${soil}%`;
                if (document.getElementById('dashboard-soil')) document.getElementById('dashboard-soil').innerHTML = `${soil}<span class="text-sm font-normal text-emerald-300">%</span>`;
                if (document.getElementById('dashboard-soil-progress')) document.getElementById('dashboard-soil-progress').innerText = `${soil}%`;
                if (document.getElementById('soil-progress-bar')) document.getElementById('soil-progress-bar').style.width = `${soil}%`;
                if (document.getElementById('sensor-soil')) document.getElementById('sensor-soil').innerText = `${soil}%`;
                if (document.getElementById('tanah-value')) document.getElementById('tanah-value').innerText = `${soil}%`;
                if (document.getElementById('tanah-info-value')) document.getElementById('tanah-info-value').innerText = `${soil}%`;
                updateActivityLog('Kelembapan Tanah', `${soil}%`);
                pushLiveCharts();
            }
        } else if (topic === 'biomatrix/sensor/dht11') {
            try {
                const d = JSON.parse(val);
                if (sensorActiveMap.TEMP) {
                    liveTemp = parseFloat(d.suhu);
                    if (document.getElementById('hero-temp')) document.getElementById('hero-temp').textContent = `${liveTemp}°C`;
                    if (document.getElementById('dash-temp')) document.getElementById('dash-temp').textContent = `${liveTemp}°C`;
                    if (document.getElementById('dashboard-temperature')) document.getElementById('dashboard-temperature').innerHTML = `${liveTemp}<span class="text-sm font-normal text-emerald-300">°C</span>`;
                    if (document.getElementById('temperature-progress-text')) document.getElementById('temperature-progress-text').innerText = `${liveTemp} °C`;
                    if (document.getElementById('sensor-temperature')) document.getElementById('sensor-temperature').innerText = `${liveTemp} °C`;
                    if (document.getElementById('dht-temperature')) document.getElementById('dht-temperature').innerText = `${liveTemp} °C`;
                }
                if (sensorActiveMap.HUM) {
                    liveHum = parseFloat(d.kelembapan);
                    if (document.getElementById('hero-hum')) document.getElementById('hero-hum').textContent = `${liveHum}%`;
                    if (document.getElementById('dash-hum')) document.getElementById('dash-hum').textContent = `${liveHum}%`;
                    if (document.getElementById('dashboard-humidity')) document.getElementById('dashboard-humidity').innerHTML = `${liveHum}<span class="text-sm font-normal text-emerald-300">%</span>`;
                    if (document.getElementById('humidity-progress-text')) document.getElementById('humidity-progress-text').innerText = `${liveHum}%`;
                    if (document.getElementById('humidity-progress-bar')) document.getElementById('humidity-progress-bar').style.width = `${liveHum}%`;
                    if (document.getElementById('sensor-humidity')) document.getElementById('sensor-humidity').innerText = `${liveHum}%`;
                    if (document.getElementById('dht-humidity')) document.getElementById('dht-humidity').innerText = `${liveHum}%`;
                }
                if (liveTemp !== null) updateActivityLog('DHT11 (Suhu)', `${liveTemp} °C`);
                if (liveHum !== null) updateActivityLog('DHT11 (Kelembapan)', `${liveHum}%`);
                pushLiveCharts();
            } catch (e) {}
        } else if (topic === 'biomatrix/kipas') {
            isKipasOn = val.toUpperCase() === 'ON';
            updateKipasUI(isKipasOn);
        } else if (topic === 'biomatrix/pompa') {
            isPompaOn = val.toUpperCase() === 'ON';
            updatePompaUI(isPompaOn);
        }
    });
}

async function handleContactSubmit(e) {
    e.preventDefault();
    const feedback=document.getElementById('form-feedback');
    try { const res=await fetch('/api/contact.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nama:document.getElementById('contact-nama').value,email:document.getElementById('contact-email').value,pesan:document.getElementById('contact-pesan').value,website:document.getElementById('contact-website')?.value||''})});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||'Pesan belum berhasil dikirim');feedback.textContent=data.message||'Pesan berhasil dikirim ke pengelola.';feedback.classList.remove('hidden');document.getElementById('contact-form').reset();}catch(err){feedback.textContent=err.message||'Pesan belum berhasil dikirim.';feedback.classList.remove('hidden');}
}

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('mobile-menu-btn')?.addEventListener('click', () => document.getElementById('mobile-menu')?.classList.toggle('hidden'));
    document.getElementById('menu-toggle')?.addEventListener('click', () => document.getElementById('sidebar')?.classList.toggle('hidden'));

    const cfg3 = {
        type: 'line',
        data: { labels: [], datasets: [
            { label: 'Kelembapan Tanah (%)', data: [], borderColor: '#10b981', tension: 0.3 },
            { label: 'Suhu (°C)', data: [], borderColor: '#f59e0b', tension: 0.3 },
            { label: 'Kelembapan Udara (%)', data: [], borderColor: '#3b82f6', tension: 0.3 }
        ]},
        options: { responsive: true, maintainAspectRatio: false }
    };
    const cPub = document.getElementById('publicChart')?.getContext('2d'); if (cPub) publicChart = new Chart(cPub, JSON.parse(JSON.stringify(cfg3)));
    const cDash = document.getElementById('dashChart')?.getContext('2d'); if (cDash) dashChart = new Chart(cDash, JSON.parse(JSON.stringify(cfg3)));
    const cTanah = document.getElementById('tanahChart')?.getContext('2d');
    if (cTanah) soilChart = new Chart(cTanah, { type: 'line', data: { labels: [], datasets: [{ label: 'Kelembapan Tanah (%)', data: [], borderColor: '#10b981', fill: true, tension: 0.3 }] }, options: { responsive: true, maintainAspectRatio: false, scales: { y: { min: 0, max: 100 } } } });
    const cDht = document.getElementById('dhtChart')?.getContext('2d');
    if (cDht) dhtChart = new Chart(cDht, { type: 'line', data: { labels: [], datasets: [{ label: 'Suhu (°C)', data: [], borderColor: '#f59e0b' }, { label: 'Kelembapan Udara (%)', data: [], borderColor: '#3b82f6' }] }, options: { responsive: true, maintainAspectRatio: false } });

    const optG = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } };
    if (document.getElementById('chartSuhu')) chartSuhu = new Chart(document.getElementById('chartSuhu'), { type: 'line', data: { labels: ['1','2','3','4'], datasets: [{ data: [27,28,28.5,28], borderColor: '#f59e0b' }] }, options: optG });
    if (document.getElementById('chartUdara')) chartUdara = new Chart(document.getElementById('chartUdara'), { type: 'line', data: { labels: ['1','2','3','4'], datasets: [{ data: [70,72,71,72], borderColor: '#3b82f6' }] }, options: optG });
    if (document.getElementById('chartTanah2')) chartTanah2 = new Chart(document.getElementById('chartTanah2'), { type: 'line', data: { labels: ['1','2','3','4'], datasets: [{ data: [62,64,63,65], borderColor: '#10b981' }] }, options: optG });
    if (document.getElementById('chartAktuator')) chartAktuator = new Chart(document.getElementById('chartAktuator'), { type: 'bar', data: { labels: ['07:00','07:10','07:20','07:30'], datasets: [{ label: 'Kipas', data: [0,1,0,0], backgroundColor: '#10b981' }, { label: 'Pompa', data: [1,0,0,0], backgroundColor: '#3b82f6' }] }, options: optG });

    setInterval(() => {
        const el = document.getElementById('current-datetime');
        if (el) el.textContent = new Date().toLocaleString('id-ID', { day: '2-digit', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }) + ' WIB';
    }, 1000);

    loadCmsContent();
    initMqtt();
    fetch('/api/auth/me.php', { cache: 'no-store' }).then(r => r.json()).then(d => {
        if (d.ok && d.authenticated) {
            bmCsrfToken = d.csrf_token || '';
            sessionStorage.setItem('greenhouseLoggedIn', 'true');
            sessionStorage.setItem('greenhouseUser', d.user?.nama_lengkap || d.user?.username);
            sessionStorage.setItem('greenhouseRole', d.user?.role || 'editor');
            showDashboardAfterLogin();
        }
    }).catch(() => {});
});


async function savePengelolaSettings() {
    if (isReadOnlyUser()) {
        showToast('Akun Lihat Saja tidak dapat mengubah pengaturan.', 'error');
        return;
    }
    const payload = {
        nama_perangkat: document.getElementById('setting-nama-perangkat')?.value || 'BioMatrix Greenhouse',
        mode_sistem: document.getElementById('setting-mode-sistem')?.value || 'Otomatis',
        suhu_maks: parseFloat(document.getElementById('setting-suhu-maks')?.value || 30),
        kelembapan_tanah_min: parseFloat(document.getElementById('setting-tanah-min')?.value || 40)
    };
    if (globalMqtt && globalMqtt.connected) {
        globalMqtt.publish('biomatrix/config', JSON.stringify(payload));
    }
    try {
        const res = await fetch('/api/settings.php', {
            method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': bmCsrfToken },
            body: JSON.stringify(payload)
        });
        const d = await res.json();
        if (d.ok) { showToast('Pengaturan berhasil disimpan & dikirim ke ESP32!', 'success'); return; }
    } catch (e) {}
    showToast('Pengaturan berhasil disimpan', 'success');
}

function updateDashboardFilter(label, btnEl) {
    document.querySelectorAll('.dash-filter-btn').forEach(b => {
        b.classList.remove('bg-[#0e4334]', 'text-white');
        b.classList.add('text-slate-400');
    });
    if (btnEl) {
        btnEl.classList.add('bg-[#0e4334]', 'text-white');
        btnEl.classList.remove('text-slate-400');
    }
    showToast(`Menampilkan grafik rentang ${label}`);
}

function updateActivityLog(device, value) {
    const nowStr = new Date().toTimeString().slice(0, 8);
    const rows = document.querySelectorAll('#page-dashboard table tbody tr');
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 4 && cells[1].innerText.trim() === device) {
            cells[0].innerText = nowStr;
            cells[2].innerText = value;
        }
    });
}


// v12: maintenance gate applies only to the public landing page; /admin is served separately.
async function bmCheckPublicMaintenance(){
  if(location.pathname.startsWith('/admin'))return;
  try{const r=await fetch('/api/site-status.php',{cache:'no-store'});const d=await r.json();if(!d.maintenance)return;
    const app=document.createElement('main');app.id='bm-maintenance-screen';app.style.cssText='position:fixed;inset:0;z-index:999999;background:linear-gradient(135deg,#03140f,#0b3527);color:#fff;display:grid;place-items:center;padding:24px;text-align:center;font-family:system-ui,sans-serif';
    const card=document.createElement('section');card.style.cssText='max-width:680px;padding:48px 28px;border:1px solid #23664b;border-radius:24px;background:rgba(255,255,255,.06);box-shadow:0 24px 80px rgba(0,0,0,.25)';
    const title=document.createElement('h1');title.textContent='BioMatrix Sedang Dalam Pemeliharaan';title.style.cssText='font-size:clamp(25px,5vw,42px);font-weight:800;margin:0 0 18px';
    const msg=document.createElement('p');msg.textContent=d.message||'Kami sedang melakukan peningkatan sistem. Silakan kembali beberapa saat lagi.';msg.style.cssText='color:#cce8d9;line-height:1.8;font-size:15px;margin:0';
    const tag=document.createElement('p');tag.textContent='BIOMATRIX SMART GREENHOUSE';tag.style.cssText='letter-spacing:.2em;font-size:10px;color:#54e0a5;margin-top:28px';card.append(title,msg,tag);app.append(card);document.body.append(app);document.body.style.overflow='hidden';
  }catch(e){/* fail open: public site remains available if status API is temporarily unavailable */}
}
document.addEventListener('DOMContentLoaded',bmCheckPublicMaintenance);
