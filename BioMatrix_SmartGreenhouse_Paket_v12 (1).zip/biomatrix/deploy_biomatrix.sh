#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WEB_ROOT="${BM_WEB_ROOT:-/var/www/biomatrix}"
ENV_FILE="${BM_ENV_FILE:-/etc/biomatrix/biomatrix.env}"
BACKUP_DIR="/root/backup_biomatrix_$(date +%Y%m%d_%H%M%S)"

if [[ $EUID -ne 0 ]]; then echo "Jalankan dengan sudo/root."; exit 1; fi
if [[ -f "$WEB_ROOT/index.html" ]]; then
  mkdir -p "$BACKUP_DIR/files"; cp -a "$WEB_ROOT/." "$BACKUP_DIR/files/"
  echo "Backup file: $BACKUP_DIR/files"
fi

if [[ ! -f "$ENV_FILE" ]]; then
  install -d -m 0750 "$(dirname "$ENV_FILE")"
  cat > "$ENV_FILE" <<'ENV'
# Isi dengan kredensial khusus server. Jangan commit file ini ke Git.
BM_DB_HOST=127.0.0.1
BM_DB_NAME=biomatrix
BM_DB_USER=biomatrix
BM_DB_PASS=GANTI_DENGAN_PASSWORD_DATABASE_KUAT
BM_MQTT_HOST=127.0.0.1
BM_MQTT_PORT=1883
# Isi jika broker MQTT memakai autentikasi; kosongkan jika tidak digunakan.
BM_MQTT_USER=
BM_MQTT_PASS=
ENV
  chmod 0640 "$ENV_FILE"
  echo "File environment dibuat: $ENV_FILE. Edit BM_DB_PASS dan jalankan deploy lagi."; exit 2
fi
set -a; source "$ENV_FILE"; set +a
: "${BM_DB_HOST:?BM_DB_HOST wajib}"; : "${BM_DB_NAME:?BM_DB_NAME wajib}"; : "${BM_DB_USER:?BM_DB_USER wajib}"; : "${BM_DB_PASS:?BM_DB_PASS wajib}"
install -d -m 0750 /etc/biomatrix
chown root:www-data /etc/biomatrix
php -r '$c=["db_host"=>getenv("BM_DB_HOST"),"db_name"=>getenv("BM_DB_NAME"),"db_user"=>getenv("BM_DB_USER"),"db_pass"=>getenv("BM_DB_PASS"),"mqtt_host"=>getenv("BM_MQTT_HOST")?:"127.0.0.1","mqtt_port"=>(int)(getenv("BM_MQTT_PORT")?:1883),"mqtt_user"=>getenv("BM_MQTT_USER")?:null,"mqtt_pass"=>getenv("BM_MQTT_PASS")?:null]; file_put_contents("/etc/biomatrix/biomatrix.php", "<?php return ".var_export($c,true).";\n");'
chown root:www-data /etc/biomatrix/biomatrix.php; chmod 0640 /etc/biomatrix/biomatrix.php
if [[ "$BM_DB_PASS" == "GANTI_DENGAN_PASSWORD_DATABASE_KUAT" ]]; then echo "Ganti BM_DB_PASS di $ENV_FILE terlebih dahulu."; exit 2; fi

install -d -m 0755 "$WEB_ROOT"
rsync -a --delete --exclude='uploads/media/*' "$ROOT/" "$WEB_ROOT/"
install -d -o www-data -g www-data -m 0750 "$WEB_ROOT/uploads/media"
install -d -o root -g www-data -m 0770 /var/lib/biomatrix
chown -R www-data:www-data "$WEB_ROOT/uploads"

# Database credentials are passed via a temporary protected client file, not command-line arguments.
MYSQL_CNF=$(mktemp); chmod 0600 "$MYSQL_CNF"
trap 'rm -f "$MYSQL_CNF"' EXIT
cat > "$MYSQL_CNF" <<EOF
[client]
host=$BM_DB_HOST
user=$BM_DB_USER
password=$BM_DB_PASS
EOF
export BM_MYSQL_CNF="$MYSQL_CNF"
mkdir -p "$BACKUP_DIR"
if mysql --defaults-extra-file="$MYSQL_CNF" -N -e "SELECT 1 FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME='${BM_DB_NAME}'" | grep -q 1; then mysqldump --defaults-extra-file="$MYSQL_CNF" --single-transaction --routines --triggers "$BM_DB_NAME" > "$BACKUP_DIR/database.sql"; echo "Backup database: $BACKUP_DIR/database.sql"; fi
TABLES=$(mysql --defaults-extra-file="$MYSQL_CNF" -N -e "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA='${BM_DB_NAME}' AND TABLE_NAME='users';" 2>/dev/null || echo 0)
if [[ "$TABLES" == "0" ]]; then echo "Database belum terinisialisasi. Impor database/biomatrix_v7_full.sql secara manual setelah memeriksa backup dan kredensial."; exit 3; fi
for f in "$WEB_ROOT"/database/migrations/*.sql; do echo "Migration $(basename "$f")"; mysql --defaults-extra-file="$MYSQL_CNF" "$BM_DB_NAME" < "$f"; done

# Share the protected environment file with the MQTT worker service.
install -d -m 0755 /etc/systemd/system/biomatrix-mqtt.service.d
cat > /etc/systemd/system/biomatrix-mqtt.service.d/10-biomatrix-env.conf <<EOF
[Service]
EnvironmentFile=$ENV_FILE
EOF
systemctl daemon-reload

# Restrict direct access to internal configuration, SQL, Python, logs, and dotfiles.
PHP_SOCK=$(find /run/php/ -name 'php*-fpm.sock' | head -n 1)
if [[ -z "$PHP_SOCK" ]]; then echo "PHP-FPM socket tidak ditemukan."; exit 4; fi
cat > /etc/nginx/sites-available/biomatrix.conf <<EOF
server {
 listen 8080;
 server_name _;
 root $WEB_ROOT;
 index index.html index.php;
 client_max_body_size 9m;
 add_header X-Content-Type-Options nosniff always;
 add_header Referrer-Policy strict-origin-when-cross-origin always;
 add_header X-Frame-Options SAMEORIGIN always;
 location ~* ^/(backend/config|database|esp32)/ { deny all; }
 location ~ /\\. { deny all; }
 location ~* \\.(sql|py|log|env|ini|sh)$ { deny all; }
 location ~* ^/uploads/media/.*\\.(php|phtml|phar)$ { deny all; }
 location /uploads/media/ { try_files \$uri =404; }
 location = /maintenance.html { try_files \$uri =404; }
 location = /admin { return 301 /admin/; }
 location /admin/ { try_files \$uri \$uri/ /admin/index.html; }
 location ^~ /api/ { rewrite ^/api/(.*)$ /backend/api/\$1 last; }
 location ~ \\.php$ { include snippets/fastcgi-php.conf; fastcgi_pass unix:$PHP_SOCK; fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name; include fastcgi_params; }
 location / { if (-f /var/lib/biomatrix/maintenance.flag) { rewrite ^ /maintenance.html last; } try_files \$uri \$uri/ /index.html; }
}
EOF
ln -sf /etc/nginx/sites-available/biomatrix.conf /etc/nginx/sites-enabled/biomatrix.conf
nginx -t
systemctl reload nginx
systemctl restart biomatrix-mqtt.service 2>/dev/null || true

echo "BioMatrix v12 files + migrations deployed. Admin: /admin/"
echo "PENTING: jangan gunakan kredensial default. Buat/rotasi password akun admin melalui panel dan pastikan TLS/HTTPS tersedia di reverse proxy."
