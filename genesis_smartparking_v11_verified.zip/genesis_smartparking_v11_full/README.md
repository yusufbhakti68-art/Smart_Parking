# Genesis of SmartParking (Genesis Infinity) — v11 Full Package

Paket lengkap siap pakai (setara struktur v10, sudah dirombak ke standar **v11**) yang modular sehingga Anda tinggal menambahkan aset kustom, slot tambahan, atau modul baru kapan saja.

## Struktur Folder
```text
genesis_smartparking_v11_full/
├── frontend/                   # UI/UX Web (Member 4 Tab + Admin 2 Tab + CS Chat + Struk Digital)
│   ├── index.html
│   └── assets/
│       ├── css/style.css
│       ├── js/app.js
│       └── img/
│           ├── genesis-card-bg.svg       # Desain kartu Navy-Gold bawaan
│           └── custom_card/              # Taruh gambar kartu kustom Anda di sini (card.png / card.jpg)
├── backend/
│   ├── api/                    # REST API PHP (Auth, State, Profile, Vehicles, RFID, Gate, Slots, Admin, Chat)
│   └── mqtt/                   # Python MQTT Worker (RFID + OLED + Ultrasonik + Heartbeat)
├── database/
│   ├── schema_v11.sql          # Skema bersih v11 (tanpa tabel saldo/deposit)
│   └── migrate_from_v10.sql    # Skrip migrasi aman jika upgrade dari database v10
├── firmware/
│   ├── esp32_gate_rfid_oled/   # Firmware ESP32 Gerbang (RC522 + OLED SSD1306 + Servo, 4-State Logic)
│   └── esp32_ultrasonic_slots/ # Firmware ESP32 Sensor Slot Ultrasonik (HC-SR04)
├── config/
│   ├── nginx_genesis.conf      # Konfigurasi Nginx (Web + PHP + WebSocket /mqtt)
│   └── mosquitto_genesis.conf  # Konfigurasi Mosquitto (TCP 1883 + WebSocket 9001)
└── scripts/                    # Paket Skrip Instalasi & Troubleshooting Otomatis (.sh)
    ├── install_v11.sh
    ├── fix_all_genesis_v11.sh
    ├── fix_windows_network.sh
    ├── fix_services.sh
    ├── fix_mosquitto.sh
    └── verify_all.sh
```

## Cara Instalasi Cepat (Ubuntu WSL2)
```bash
sudo unzip genesis_smartparking_v11_full.zip -d /var/www/
sudo mv /var/www/genesis_smartparking_v11_full /var/www/smartparking
cd /var/www/smartparking
chmod +x scripts/*.sh
sudo ./scripts/install_v11.sh
./scripts/fix_all_genesis_v11.sh
```

## Cara Menambahkan / Mengganti Isi Nanti
1. **Ganti Gambar Kartu RFID:** Cukup simpan gambar Anda dengan nama `card.png` atau `card.jpg` di folder `frontend/assets/img/custom_card/`, lalu ubah baris `CUSTOM_CARD_IMG` di bagian atas `frontend/assets/js/app.js` (atau biarkan default untuk memakai `genesis-card-bg.svg`).
2. **Tambah Slot Parkir:** Bisa langsung lewat tombol **+ Tambah Slot** di Dashboard Admin → Tab **Maket Parkir**.
3. **Ganti IP Server di ESP32:** Buka file `.ino` di folder `firmware/`, ubah `WIFI_SSID`, `WIFI_PASS`, dan `MQTT_SERVER` sesuai IP Wi-Fi laptop yang tampil di akhir eksekusi `./scripts/verify_all.sh`.

## Akun Demo Bawaan
- **Admin:** `admin` / `admin123`
- **Member (Kartu Sudah Diambil — Tampil Visual Kartu Aktif):** `budi` / `user123`
- **Member (Belum Mengajukan Kartu):** `yusuf` / `user123`
