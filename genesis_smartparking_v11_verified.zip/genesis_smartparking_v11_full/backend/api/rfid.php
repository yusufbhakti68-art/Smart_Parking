<?php
require_once __DIR__ . '/config.php';
$action = $_GET['action'] ?? '';
$body = json_input();

if ($action === 'request') {
    $uid = require_auth();
    $st = $pdo->prepare("
        INSERT INTO rfid_cards (user_id, status, requested_at)
        VALUES (?, 'menunggu_verifikasi', NOW())
        ON DUPLICATE KEY UPDATE status = 'menunggu_verifikasi', requested_at = NOW()
    ");
    $st->execute([$uid]);
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'verify') {
    $cardUid = strtoupper(trim($body['card_uid'] ?? $_GET['card_uid'] ?? ''));
    $st = $pdo->prepare("
        SELECT u.id AS user_id, u.full_name, r.status, r.card_uid
        FROM rfid_cards r
        JOIN users u ON u.id = r.user_id
        WHERE UPPER(r.card_uid) = ? AND r.status = 'sudah_diambil'
    ");
    $st->execute([$cardUid]);
    $row = $st->fetch();

    if (!$row) {
        http_response_code(404);
        echo json_encode(['valid' => false, 'message' => 'KARTU TIDAK TERDAFTAR']);
        exit;
    }

    $vSt = $pdo->prepare("SELECT id, category, plate_number FROM vehicles WHERE user_id = ?");
    $vSt->execute([$row['user_id']]);
    echo json_encode([
        'valid' => true,
        'user_id' => $row['user_id'],
        'full_name' => $row['full_name'],
        'vehicles' => $vSt->fetchAll()
    ]);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'Aksi tidak dikenali']);
