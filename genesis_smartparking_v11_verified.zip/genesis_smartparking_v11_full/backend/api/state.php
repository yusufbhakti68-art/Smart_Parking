<?php
require_once __DIR__ . '/config.php';

if (empty($_SESSION['user_id'])) {
    echo json_encode(['authenticated' => false]);
    exit;
}

$uid = $_SESSION['user_id'];
$st = $pdo->prepare("SELECT id, user_code, username, full_name, email, phone, role, is_new_user FROM users WHERE id = ?");
$st->execute([$uid]);
$user = $st->fetch();

if (!$user) {
    session_destroy();
    echo json_encode(['authenticated' => false]);
    exit;
}

$hb = $pdo->query("SELECT status FROM system_status WHERE device_key = 'esp32_gate'")->fetch();
$resp = [
    'authenticated' => true,
    'esp32_online' => (!$hb || $hb['status'] === 'online'),
    'user' => $user
];

if ($user['role'] === 'admin') {
    $slots = $pdo->query("
        SELECT *,
               (mismatch_since IS NOT NULL AND TIMESTAMPDIFF(MINUTE, mismatch_since, NOW()) >= 15) AS mismatch_alert
        FROM parking_slots
        ORDER BY slot_code ASC
    ")->fetchAll();
    $resp['slots'] = $slots;
    $resp['gate_logs'] = $pdo->query("SELECT * FROM gate_logs ORDER BY id DESC LIMIT 20")->fetchAll();
    $resp['all_rfid'] = $pdo->query("
        SELECT u.id AS user_id, u.user_code, u.full_name,
               COALESCE(r.status, 'belum_mengajukan') AS status, r.card_uid, r.pickup_schedule
        FROM users u
        LEFT JOIN rfid_cards r ON r.user_id = u.id
        WHERE u.role = 'member'
        ORDER BY u.id DESC
    ")->fetchAll();
    $resp['all_users'] = $pdo->query("
        SELECT u.id, u.user_code, u.full_name, u.username,
               GROUP_CONCAT(CONCAT(UPPER(v.category), ': ', v.plate_number) SEPARATOR ', ') AS vehicles_summary
        FROM users u
        LEFT JOIN vehicles v ON v.user_id = u.id
        WHERE u.role = 'member'
        GROUP BY u.id
        ORDER BY u.id DESC
    ")->fetchAll();
    $resp['all_messages'] = $pdo->query("SELECT * FROM cs_messages ORDER BY id ASC LIMIT 200")->fetchAll();
} else {
    $st = $pdo->prepare("SELECT * FROM rfid_cards WHERE user_id = ?");
    $st->execute([$uid]);
    $resp['rfid'] = $st->fetch() ?: ['status' => 'belum_mengajukan'];

    $st = $pdo->prepare("SELECT * FROM vehicles WHERE user_id = ? ORDER BY id DESC");
    $st->execute([$uid]);
    $resp['vehicles'] = $st->fetchAll();

    $st = $pdo->prepare("
        SELECT t.*, s.slot_code
        FROM parking_tickets t
        LEFT JOIN parking_slots s ON s.id = t.slot_id
        WHERE t.user_id = ?
        ORDER BY t.id DESC LIMIT 30
    ");
    $st->execute([$uid]);
    $resp['tickets'] = $st->fetchAll();

    $st = $pdo->prepare("SELECT sender_role, message, created_at FROM cs_messages WHERE user_id = ? ORDER BY id ASC LIMIT 50");
    $st->execute([$uid]);
    $resp['messages'] = $st->fetchAll();
}

echo json_encode($resp);
