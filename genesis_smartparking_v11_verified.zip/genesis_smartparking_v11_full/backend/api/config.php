<?php
header('Content-Type: application/json; charset=utf-8');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$DB_HOST = getenv('GENESIS_DB_HOST') ?: '127.0.0.1';
$DB_NAME = getenv('GENESIS_DB_NAME') ?: 'genesis_smartparking';
$DB_USER = getenv('GENESIS_DB_USER') ?: 'genesis_user';
$DB_PASS = getenv('GENESIS_DB_PASS') ?: 'genesis123';

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Koneksi database gagal: ' . $e->getMessage()]);
    exit;
}

function json_input() {
    $raw = file_get_contents('php://input');
    return json_decode($raw ?: '{}', true) ?: [];
}

function require_auth() {
    if (empty($_SESSION['user_id'])) {
        http_response_code(401);
        echo json_encode(['error' => 'Silakan login terlebih dahulu']);
        exit;
    }
    return $_SESSION['user_id'];
}

function require_admin($pdo) {
    $uid = require_auth();
    $st = $pdo->prepare("SELECT role FROM users WHERE id = ?");
    $st->execute([$uid]);
    $u = $st->fetch();
    if (!$u || $u['role'] !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Akses khusus Admin']);
        exit;
    }
    return $uid;
}
