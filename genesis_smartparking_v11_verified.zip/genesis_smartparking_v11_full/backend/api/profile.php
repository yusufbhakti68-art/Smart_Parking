<?php
require_once __DIR__ . '/config.php';
$uid = require_auth();
$action = $_GET['action'] ?? 'update';
$body = json_input();

if ($action === 'dismiss_welcome') {
    $pdo->prepare("UPDATE users SET is_new_user = 0 WHERE id = ?")->execute([$uid]);
    echo json_encode(['ok' => true]);
    exit;
}

$fullName = trim($body['full_name'] ?? '');
$email = trim($body['email'] ?? '');
$phone = trim($body['phone'] ?? '');

if (!$fullName) {
    http_response_code(400);
    echo json_encode(['error' => 'Nama akun tidak boleh kosong']);
    exit;
}

$st = $pdo->prepare("UPDATE users SET full_name = ?, email = ?, phone = ? WHERE id = ?");
$st->execute([$fullName, $email, $phone, $uid]);
echo json_encode(['ok' => true]);
