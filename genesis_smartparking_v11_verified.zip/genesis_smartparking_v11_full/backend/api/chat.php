<?php
require_once __DIR__ . '/config.php';
$uid = require_auth();
$body = json_input();
$msg = trim($body['message'] ?? '');

if (!$msg) {
    http_response_code(400);
    echo json_encode(['error' => 'Pesan kosong']);
    exit;
}

$st = $pdo->prepare("SELECT role FROM users WHERE id = ?");
$st->execute([$uid]);
$u = $st->fetch();

if ($u && $u['role'] === 'admin') {
    $targetUserId = intval($body['target_user_id'] ?? 0);
    if (!$targetUserId) {
        http_response_code(400);
        echo json_encode(['error' => 'Pilih member tujuan']);
        exit;
    }
    $pdo->prepare("INSERT INTO cs_messages (user_id, sender_role, message) VALUES (?, 'admin', ?)")
        ->execute([$targetUserId, $msg]);
} else {
    $pdo->prepare("INSERT INTO cs_messages (user_id, sender_role, message) VALUES (?, 'member', ?)")
        ->execute([$uid, $msg]);
}

echo json_encode(['ok' => true]);
