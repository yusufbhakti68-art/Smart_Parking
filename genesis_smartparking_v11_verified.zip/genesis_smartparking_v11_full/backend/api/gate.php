<?php
require_once __DIR__ . '/config.php';
$body = json_input();

$cardUid = strtoupper(trim($body['card_uid'] ?? ''));
$category = $body['vehicle_category'] ?? 'motor';

$st = $pdo->prepare("SELECT user_id FROM rfid_cards WHERE UPPER(card_uid) = ? AND status = 'sudah_diambil'");
$st->execute([$cardUid]);
$card = $st->fetch();

if (!$card) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'error' => 'Kartu tidak valid']);
    exit;
}

$userId = $card['user_id'];

// Cek jika user sudah punya tiket aktif -> proses KELUAR
$activeSt = $pdo->prepare("SELECT id, ticket_code, slot_id FROM parking_tickets WHERE user_id = ? AND status = 'aktif' ORDER BY id DESC LIMIT 1");
$activeSt->execute([$userId]);
$active = $activeSt->fetch();

if ($active && ($body['mode'] ?? '') === 'exit') {
    $pdo->prepare("UPDATE parking_tickets SET status = 'selesai', exit_time = NOW() WHERE id = ?")->execute([$active['id']]);
    if ($active['slot_id']) {
        $pdo->prepare("UPDATE parking_slots SET status = 'kosong', mismatch_since = NULL WHERE id = ?")->execute([$active['slot_id']]);
    }
    $pdo->prepare("INSERT INTO gate_logs (card_uid, user_id, action, message) VALUES (?, ?, 'EXIT_CONFIRMED', ?)")
        ->execute([$cardUid, $userId, 'Keluar selesai untuk tiket ' . $active['ticket_code']]);
    echo json_encode(['ok' => true, 'mode' => 'exit', 'ticket_code' => $active['ticket_code']]);
    exit;
}

$vSt = $pdo->prepare("SELECT id, plate_number FROM vehicles WHERE user_id = ? AND category = ? LIMIT 1");
$vSt->execute([$userId, $category]);
$veh = $vSt->fetch();

$sSt = $pdo->prepare("SELECT id, slot_code FROM parking_slots WHERE category = ? AND status = 'kosong' ORDER BY slot_code ASC LIMIT 1");
$sSt->execute([$category]);
$slot = $sSt->fetch();

$ticketCode = 'GNS-' . date('YmdHis') . '-' . rand(10, 99);
$pdo->prepare("
    INSERT INTO parking_tickets (ticket_code, user_id, vehicle_id, vehicle_category, plate_number, slot_id, status, entry_method)
    VALUES (?, ?, ?, ?, ?, ?, 'aktif', 'rfid')
")->execute([
    $ticketCode,
    $userId,
    $veh['id'] ?? null,
    $category,
    $veh['plate_number'] ?? '-',
    $slot['id'] ?? null
]);

if ($slot) {
    $pdo->prepare("UPDATE parking_slots SET status = 'dipesan' WHERE id = ?")->execute([$slot['id']]);
}

$pdo->prepare("
    INSERT INTO gate_logs (card_uid, user_id, action, vehicle_category, message)
    VALUES (?, ?, 'ENTRY_CONFIRMED', ?, ?)
")->execute([
    $cardUid,
    $userId,
    $category,
    'Tiket ' . $ticketCode . ' -> Slot ' . ($slot['slot_code'] ?? 'Umum')
]);

echo json_encode([
    'ok' => true,
    'ticket_code' => $ticketCode,
    'slot_code' => $slot['slot_code'] ?? 'UMUM'
]);
