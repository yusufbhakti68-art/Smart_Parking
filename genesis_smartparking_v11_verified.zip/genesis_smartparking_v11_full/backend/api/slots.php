<?php
require_once __DIR__ . '/config.php';
$body = json_input();

// Endpoint untuk Python MQTT Worker (Update Sensor Ultrasonik & Heartbeat ESP32)
if (($_GET['action'] ?? '') === 'heartbeat') {
    $status = ($body['status'] ?? 'online') === 'offline' ? 'offline' : 'online';
    $pdo->prepare("INSERT INTO system_status (device_key, status) VALUES ('esp32_gate', ?) ON DUPLICATE KEY UPDATE status = VALUES(status)")
        ->execute([$status]);
    echo json_encode(['ok' => true]);
    exit;
}

$slotCode = strtoupper(trim($body['slot_code'] ?? ''));
$distance = isset($body['distance_cm']) ? floatval($body['distance_cm']) : null;
$occupied = isset($body['occupied']) ? (bool)$body['occupied'] : ($distance !== null && $distance < 40.0);

if (!$slotCode) {
    http_response_code(400);
    echo json_encode(['error' => 'slot_code wajib diisi']);
    exit;
}

$st = $pdo->prepare("SELECT id, status, mismatch_since FROM parking_slots WHERE slot_code = ?");
$st->execute([$slotCode]);
$slot = $st->fetch();

if (!$slot) {
    http_response_code(404);
    echo json_encode(['error' => 'Slot tidak ditemukan']);
    exit;
}

$newStatus = $occupied ? 'terisi' : 'kosong';
// Deteksi jika slot terisi tanpa tiket aktif/reservasi -> mulai hitung 15 menit salah slot
$mismatchSql = "mismatch_since = NULL";
if ($occupied && $slot['status'] === 'kosong') {
    $mismatchSql = "mismatch_since = COALESCE(mismatch_since, NOW())";
}

$pdo->prepare("UPDATE parking_slots SET status = ?, distance_cm = ?, $mismatchSql WHERE id = ?")
    ->execute([$newStatus, $distance, $slot['id']]);

echo json_encode(['ok' => true, 'slot_code' => $slotCode, 'status' => $newStatus]);
