<?php
require_once __DIR__ . '/config.php';
require_admin($pdo);
$action = $_GET['action'] ?? '';
$body = json_input();

if ($action === 'add_slot') {
    $code = strtoupper(trim($body['slot_code'] ?? ''));
    $cat = ($body['category'] ?? 'motor') === 'mobil' ? 'mobil' : 'motor';
    $zone = $cat === 'mobil' ? 'Zona Mobil' : 'Zona Motor';
    if (!$code) {
        http_response_code(400);
        echo json_encode(['error' => 'Kode slot wajib diisi']);
        exit;
    }
    $pdo->prepare("INSERT INTO parking_slots (slot_code, zone, category, status) VALUES (?, ?, ?, 'kosong')")
        ->execute([$code, $zone, $cat]);
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'update_slot') {
    $slotId = intval($body['slot_id'] ?? 0);
    $status = $body['status'] ?? 'kosong';
    $pdo->prepare("UPDATE parking_slots SET status = ?, mismatch_since = NULL WHERE id = ?")
        ->execute([$status, $slotId]);
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'update_rfid') {
    $userId = intval($body['user_id'] ?? 0);
    $status = $body['status'] ?? 'menunggu_verifikasi';
    $uid = !empty($body['card_uid']) ? strtoupper(trim($body['card_uid'])) : null;
    $schedule = $body['pickup_schedule'] ?? null;
    $clean = $uid ? str_replace(':', '', $uid) : '';
    $display = $uid ? ('4364 3211 ' . substr($clean . '00000000', 0, 4) . ' ' . substr($clean . '4455', 4, 4)) : null;

    $st = $pdo->prepare("
        INSERT INTO rfid_cards (user_id, card_uid, card_number_display, status, pickup_schedule, picked_up_at)
        VALUES (?, ?, ?, ?, ?, IF(? = 'sudah_diambil', NOW(), NULL))
        ON DUPLICATE KEY UPDATE
          status = VALUES(status),
          card_uid = COALESCE(VALUES(card_uid), card_uid),
          card_number_display = COALESCE(VALUES(card_number_display), card_number_display),
          pickup_schedule = COALESCE(VALUES(pickup_schedule), pickup_schedule),
          picked_up_at = IF(VALUES(status) = 'sudah_diambil', NOW(), picked_up_at)
    ");
    $st->execute([$userId, $uid, $display, $status, $schedule, $status]);
    echo json_encode(['ok' => true]);
    exit;
}

if ($action === 'gate_cmd') {
    $cmd = strtoupper($body['command'] ?? 'OPEN');
    $pdo->prepare("INSERT INTO gate_logs (action, message) VALUES (?, ?)")
        ->execute(["MANUAL_$cmd", "Perintah manual Admin dari Dashboard"]);
    @exec("mosquitto_pub -h 127.0.0.1 -p 1883 -t 'genesis/gate/cmd' -m " . escapeshellarg($cmd));
    echo json_encode(['ok' => true]);
    exit;
}

http_response_code(400);
echo json_encode(['error' => 'Aksi admin tidak valid']);
