<?php
require_once __DIR__ . '/config.php';
$uid = require_auth();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $body = json_input();
    $cat = $body['category'] ?? '';
    $plate = strtoupper(trim($body['plate_number'] ?? ''));
    $label = trim($body['vehicle_label'] ?? '');

    if (!in_array($cat, ['motor', 'mobil']) || !$plate) {
        http_response_code(400);
        echo json_encode(['error' => 'Kategori dan nomor polisi wajib diisi']);
        exit;
    }

    $st = $pdo->prepare("INSERT INTO vehicles (user_id, category, plate_number, vehicle_label) VALUES (?, ?, ?, ?)");
    $st->execute([$uid, $cat, $plate, $label]);
    echo json_encode(['ok' => true, 'id' => $pdo->lastInsertId()]);
    exit;
}

if ($method === 'DELETE') {
    $id = intval($_GET['id'] ?? 0);
    $st = $pdo->prepare("DELETE FROM vehicles WHERE id = ? AND user_id = ?");
    $st->execute([$id, $uid]);
    echo json_encode(['ok' => true]);
    exit;
}

$st = $pdo->prepare("SELECT * FROM vehicles WHERE user_id = ? ORDER BY id DESC");
$st->execute([$uid]);
echo json_encode(['vehicles' => $st->fetchAll()]);
