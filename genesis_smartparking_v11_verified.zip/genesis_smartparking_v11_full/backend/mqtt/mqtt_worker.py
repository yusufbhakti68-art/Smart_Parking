#!/usr/bin/env python3
"""
Genesis of SmartParking v11 - Python MQTT Worker
Menangani:
  1. genesis/gate/rfid      -> Verifikasi UID -> Balas nama akun ke OLED
  2. genesis/gate/confirm   -> Catat tiket aktif -> Buka palang & tampilkan slot
  3. genesis/slot/<KODE>    -> Update jarak ultrasonik & status okupansi slot
  4. genesis/esp32/status   -> Heartbeat online/offline ESP32
"""
import json
import os
import requests
import paho.mqtt.client as mqtt

MQTT_HOST = os.getenv("MQTT_HOST", "127.0.0.1")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
API_BASE  = os.getenv("GENESIS_API", "http://127.0.0.1:80/api")

TOPIC_RFID_SCAN    = "genesis/gate/rfid"
TOPIC_RFID_CONFIRM = "genesis/gate/confirm"
TOPIC_SLOT_UPDATE  = "genesis/slot/+"
TOPIC_ESP_STATUS   = "genesis/esp32/status"
TOPIC_OLED_REPLY   = "genesis/gate/oled"
TOPIC_GATE_CMD     = "genesis/gate/cmd"

def on_connect(client, userdata, flags, rc):
    print(f"[MQTT] Terhubung ke broker {MQTT_HOST}:{MQTT_PORT} (rc={rc})")
    client.subscribe([
        (TOPIC_RFID_SCAN, 0),
        (TOPIC_RFID_CONFIRM, 0),
        (TOPIC_SLOT_UPDATE, 0),
        (TOPIC_ESP_STATUS, 0)
    ])

def on_message(client, userdata, msg):
    topic = msg.topic
    payload = msg.payload.decode("utf-8", errors="ignore").strip()
    print(f"[MQTT] {topic} -> {payload}")

    try:
        if topic == TOPIC_RFID_SCAN:
            data = json.loads(payload) if payload.startswith("{") else {"card_uid": payload}
            r = requests.post(f"{API_BASE}/rfid.php?action=verify", json=data, timeout=5)
            res = r.json()
            reply = {"status": "OK", "name": res["full_name"].upper()} if res.get("valid") else {"status": "DENIED", "message": "KARTU TIDAK VALID"}
            client.publish(TOPIC_OLED_REPLY, json.dumps(reply))

        elif topic == TOPIC_RFID_CONFIRM:
            data = json.loads(payload)
            r = requests.post(f"{API_BASE}/gate.php", json=data, timeout=5)
            res = r.json()
            if res.get("ok"):
                client.publish(TOPIC_GATE_CMD, "OPEN")
                client.publish(TOPIC_OLED_REPLY, json.dumps({
                    "status": "PARK_OK",
                    "slot": res.get("slot_code", "UMUM")
                }))

        elif topic.startswith("genesis/slot/"):
            slot_code = topic.split("/")[-1].upper()
            data = json.loads(payload) if payload.startswith("{") else {"distance_cm": float(payload)}
            data["slot_code"] = slot_code
            requests.post(f"{API_BASE}/slots.php", json=data, timeout=5)

        elif topic == TOPIC_ESP_STATUS:
            status = "offline" if payload.lower() == "offline" else "online"
            requests.post(f"{API_BASE}/slots.php?action=heartbeat", json={"status": status}, timeout=5)

    except Exception as e:
        print(f"[ERROR] Gagal memproses pesan MQTT: {e}")

if __name__ == "__main__":
    client = mqtt.Client(client_id="genesis_v11_worker")
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(MQTT_HOST, MQTT_PORT, 60)
    client.loop_forever()
