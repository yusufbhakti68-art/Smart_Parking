#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
bash "$SCRIPT_DIR/fix_services.sh"
bash "$SCRIPT_DIR/fix_windows_network.sh"
bash "$SCRIPT_DIR/verify_all.sh"
