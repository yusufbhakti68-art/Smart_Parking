#!/bin/bash
echo "=========================================="
echo "  SINKRONISASI PORTPROXY & FIREWALL WINDOWS"
echo "=========================================="

WSL_IP=$(hostname -I | awk '{print $1}')
if [ -z "$WSL_IP" ]; then
    echo "[GAGAL] IP WSL2 tidak terdeteksi."
    exit 1
fi
echo "[INFO] IP WSL2: $WSL_IP (listenaddress=0.0.0.0 adaptif ganti Wi-Fi)"

PS_SCRIPT="
netsh interface portproxy reset
netsh interface portproxy add v4tov4 listenport=80 listenaddress=0.0.0.0 connectport=80 connectaddress=$WSL_IP
netsh interface portproxy add v4tov4 listenport=8080 listenaddress=0.0.0.0 connectport=8080 connectaddress=$WSL_IP
netsh interface portproxy add v4tov4 listenport=1883 listenaddress=0.0.0.0 connectport=1883 connectaddress=$WSL_IP
netsh interface portproxy add v4tov4 listenport=9001 listenaddress=0.0.0.0 connectport=9001 connectaddress=$WSL_IP
netsh advfirewall firewall delete rule name='Genesis SmartParking WSL' 2>\$null
netsh advfirewall firewall add rule name='Genesis SmartParking WSL' dir=in action=allow protocol=TCP localport=80,8080,1883,9001
"

# Encode UTF-16LE Base64 agar tidak pernah rusak oleh tanda kutip di Windows PowerShell
ENCODED_CMD=$(printf '%s' "$PS_SCRIPT" | iconv -f UTF-8 -t UTF-16LE | base64 -w 0)
powershell.exe -NoProfile -Command "Start-Process powershell -Verb RunAs -Wait -ArgumentList '-NoProfile -EncodedCommand $ENCODED_CMD'"

if netsh.exe interface portproxy show all 2>/dev/null | grep -q "$WSL_IP"; then
    echo "[OK] Portproxy Windows (0.0.0.0 -> $WSL_IP) terpasang"
else
    echo "[GAGAL] Portproxy Windows gagal dipasang"
fi
