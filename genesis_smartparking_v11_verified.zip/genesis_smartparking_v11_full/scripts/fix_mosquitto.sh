#!/bin/bash
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
echo "=========================================="
echo "  TROUBLESHOOTING MOSQUITTO (1883 & 9001)"
echo "=========================================="

sudo cp "$APP_DIR/config/mosquitto_genesis.conf" /etc/mosquitto/conf.d/genesis.conf
sudo systemctl restart mosquitto
sleep 1

if mosquitto_pub -h 127.0.0.1 -p 1883 -t "genesis/health" -m "ok" 2>/dev/null; then
    echo "[OK] Mosquitto TCP Port 1883 aktif"
else
    echo "[GAGAL] Mosquitto TCP Port 1883 tidak merespons"
fi

if ss -tlnp | grep -q ":9001"; then
    echo "[OK] Mosquitto WebSocket Port 9001 aktif"
else
    echo "[GAGAL] Mosquitto WebSocket Port 9001 belum aktif"
fi
