#!/bin/bash
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
echo "=========================================="
echo "  TROUBLESHOOTING LAYANAN SERVER WSL2"
echo "=========================================="

PHP_SVC=$(systemctl list-unit-files | grep -oE 'php[0-9.]+-fpm\.service' | head -n 1)
sudo nginx -t && sudo systemctl restart nginx mariadb mosquitto ${PHP_SVC:-php8.3-fpm}

pkill -f "mqtt_worker.py" 2>/dev/null || true
if [ -x "$APP_DIR/backend/mqtt/venv/bin/python" ]; then
    nohup "$APP_DIR/backend/mqtt/venv/bin/python" "$APP_DIR/backend/mqtt/mqtt_worker.py" > /tmp/genesis_mqtt.log 2>&1 &
    sleep 1
fi

for svc in nginx mariadb mosquitto; do
    if systemctl is-active --quiet "$svc"; then
        echo "[OK] Layanan $svc aktif"
    else
        echo "[GAGAL] Layanan $svc mati"
    fi
done

if pgrep -f "mqtt_worker.py" > /dev/null; then
    echo "[OK] Python MQTT Worker berjalan"
else
    echo "[GAGAL] Python MQTT Worker belum berjalan"
fi
