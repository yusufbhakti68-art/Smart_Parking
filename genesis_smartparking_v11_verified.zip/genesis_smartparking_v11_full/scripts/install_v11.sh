#!/bin/bash
set -e
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "=========================================="
echo "  INSTALASI GENESIS SMARTPARKING v11 FULL"
echo "=========================================="

echo "[1/5] Memasang paket server (Nginx, MariaDB, PHP-FPM, Mosquitto, Python)..."
sudo apt-get update -qq
sudo apt-get install -y nginx mariadb-server php-fpm php-mysql mosquitto mosquitto-clients python3-venv curl

echo "[2/5] Setup Database MariaDB..."
sudo systemctl start mariadb
sudo mysql -e "CREATE DATABASE IF NOT EXISTS genesis_smartparking;"
sudo mysql -e "CREATE USER IF NOT EXISTS 'genesis_user'@'localhost' IDENTIFIED BY 'genesis123';"
sudo mysql -e "CREATE USER IF NOT EXISTS 'genesis_user'@'127.0.0.1' IDENTIFIED BY 'genesis123';"
sudo mysql -e "GRANT ALL PRIVILEGES ON genesis_smartparking.* TO 'genesis_user'@'localhost';"
sudo mysql -e "GRANT ALL PRIVILEGES ON genesis_smartparking.* TO 'genesis_user'@'127.0.0.1';"
sudo mysql -e "FLUSH PRIVILEGES;"
sudo mysql genesis_smartparking < "$APP_DIR/database/schema_v11.sql"

echo "[3/5] Konfigurasi Nginx..."
PHP_SOCK=$(ls /run/php/php*-fpm.sock | head -n 1)
sed -e "s|/var/www/smartparking|$APP_DIR|g"     -e "s|/run/php/php8.3-fpm.sock|$PHP_SOCK|g"     "$APP_DIR/config/nginx_genesis.conf" | sudo tee /etc/nginx/sites-available/genesis_smartparking > /dev/null
sudo ln -sf /etc/nginx/sites-available/genesis_smartparking /etc/nginx/sites-enabled/default
sudo nginx -t && sudo systemctl restart nginx

echo "[4/5] Setup Python Virtual Environment untuk MQTT Worker..."
python3 -m venv "$APP_DIR/backend/mqtt/venv"
"$APP_DIR/backend/mqtt/venv/bin/pip" install -q -r "$APP_DIR/backend/mqtt/requirements.txt"

echo "[5/5] Konfigurasi Mosquitto Broker..."
bash "$APP_DIR/scripts/fix_mosquitto.sh"

echo "[OK] Instalasi Genesis v11 selesai! Jalankan ./scripts/fix_all_genesis_v11.sh"
