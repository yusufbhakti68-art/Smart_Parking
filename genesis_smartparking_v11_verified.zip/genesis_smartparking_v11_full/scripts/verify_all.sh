#!/bin/bash
echo ""
echo "=========================================="
echo "   HASIL VERIFIKASI GENESIS v11 FULL"
echo "=========================================="

WSL_IP=$(hostname -I | awk '{print $1}')

for svc in nginx mariadb mosquitto; do
    if systemctl is-active --quiet "$svc"; then
        echo "[OK] Layanan $svc aktif"
    else
        echo "[GAGAL] Layanan $svc mati"
    fi
done

HTTP_WEB=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:80/)
[ "$HTTP_WEB" = "200" ] && echo "[OK] Frontend Genesis (Port 80) HTTP 200" || echo "[GAGAL] Frontend HTTP $HTTP_WEB"

HTTP_API=$(curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:80/api/state.php)
[ "$HTTP_API" = "200" ] && echo "[OK] API /api/state.php HTTP 200" || echo "[GAGAL] API HTTP $HTTP_API"

mosquitto_pub -h 127.0.0.1 -p 1883 -t "genesis/verify" -m "ok" 2>/dev/null     && echo "[OK] Mosquitto Broker (1883) siap" || echo "[GAGAL] Mosquitto gagal"

pgrep -f "mqtt_worker.py" > /dev/null     && echo "[OK] Python MQTT Worker aktif" || echo "[GAGAL] Python MQTT Worker mati"

netsh.exe interface portproxy show all 2>/dev/null | grep -q "$WSL_IP"     && echo "[OK] Portproxy Windows (0.0.0.0 -> $WSL_IP) aktif" || echo "[GAGAL] Portproxy belum mengarah ke $WSL_IP"

echo ""
echo "[INFO] Daftar IP Windows (pakai IP Wi-Fi untuk buka dari HP & ESP32):"
ipconfig.exe | grep -i "IPv4" | tr -d '\r'
echo "=========================================="
