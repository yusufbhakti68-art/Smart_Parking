# Rancangan Lengkap Genesis of SmartParking (Genesis Infinity) v11

## 1. Rebranding & Identitas
- **Nama Utama:** Genesis of SmartParking / Genesis Infinity
- **Label Ringkas (Sidebar & OLED):** `GENESIS`
- **Desain Kartu RFID (Status Sudah Diambil):** Gaya *Navy-Gold Infinity* (chip emas, ikon *contactless*, UID 4 blok, nama pemilik dinamis, dan badge `AKTIF`), mendukung penggantian gambar kustom di `frontend/assets/img/custom_card/`.

## 2. Perubahan Dashboard Pengguna (4 Menu Utama)
- **Dihapus:** Peta Maket Slot, Panel Denah Parkir, serta seluruh modul Top-Up / Isi Saldo (Cash Pengelola, Transfer Bank, QRIS, Nominal Deposit, Pengajuan Deposit, Riwayat & Struk Deposit).
- **Dipertahankan & Ditingkatkan:**
  1. **Tiket & Navigasi:** Tiket parkir aktif, slot tujuan, panduan tap OLED, dan **Struk Parkir Digital** (bisa dicetak).
  2. **Kartu RFID:** 4 status dinamis (`belum_mengajukan`, `menunggu_verifikasi`, `siap_diambil`, `sudah_diambil`) tanpa syarat saldo minimal.
  3. **Riwayat Parkir:** Tabel riwayat lengkap + tombol **Lihat Struk** untuk setiap sesi parkir.
  4. **Profil & Pengaturan:** Edit nama akun, email, No. HP, serta CRUD multi-kendaraan (*Motor* & *Mobil* + Nomor Polisi).

## 3. Perubahan Dashboard Admin (2 Menu Utama)
1. **Maket Parkir:** Monitoring slot ultrasonik *real-time*, jarak (cm), peringatan salah slot (>15 menit), tambah slot baru, dan ubah status manual.
2. **Gate & Pengelolaan:** Kontrol palang gate (`OPEN`/`CLOSE`), log aktivitas gerbang, manajemen pengajuan & status kartu RFID (set jadwal, input UID, aktivasi), daftar akun & kendaraan, serta **Kotak Masuk CS Chat per Akun**.

## 4. Logika ESP32 (RFID + OLED 4-State)
1. **IDLE:** Menunggu kartu + *debounce* 650ms agar kartu menempel lama tidak terbaca ganda.
2. **SELECT VEHICLE:** Cek UID → OLED tampil `GENESIS / SELAMAT DATANG / <NAMA> / 1x = MOTOR / 2x = MOBIL`.
3. **CONFIRM & CORRECT:** `1x = KONFIRMASI`, `2x = UBAH PILIHAN` (kembali ke step 2).
4. **TIMEOUT & PARK:** Timeout 15 detik otomatis kembali ke IDLE. Jika konfirmasi → kirim MQTT, catat tiket, buka palang.
