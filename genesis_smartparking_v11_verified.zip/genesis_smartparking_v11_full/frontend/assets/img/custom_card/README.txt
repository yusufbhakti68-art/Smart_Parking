Folder ini disediakan agar Anda tinggal menambahkan gambar kartu RFID kustom Anda nanti.
Caranya:
1. Taruh file gambar kartu di folder ini, misalnya: card.png
2. Buka frontend/assets/js/app.js lalu ubah nilai CUSTOM_CARD_BG menjadi:
   const CUSTOM_CARD_BG = 'assets/img/custom_card/card.png';
