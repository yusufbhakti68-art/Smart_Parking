const API_BASE = '/api';
// Ubah path di bawah jika ingin memakai gambar kartu kustom di assets/img/custom_card/
const CUSTOM_CARD_BG = 'assets/img/genesis-card-bg.svg';

let currentState = null;
let welcomeShown = false;

function showToast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 2800);
}

function openModal(html) {
  document.getElementById('modalCardBody').innerHTML = html;
  document.getElementById('modalBackdrop').classList.add('open');
}
function closeModal() {
  document.getElementById('modalBackdrop').classList.remove('open');
}

function showConfirmAnimation(title, subtitle) {
  openModal(`
    <div class="check-anim">&#10003;</div>
    <h2 style="margin-bottom:6px;">${title}</h2>
    <p style="color:#64748b;font-size:14px;margin-bottom:18px;">${subtitle}</p>
    <button class="btn btn-primary" onclick="closeModal()">Tutup</button>
  `);
}

function openReceiptModal(ticket) {
  openModal(`
    <h2 style="margin-bottom:4px;">Struk Parkir Digital</h2>
    <small style="color:#64748b;">Genesis of SmartParking — Genesis Infinity</small>
    <div class="receipt-box">
      ID Tiket   : <strong>${ticket.ticket_code}</strong><br>
      Kendaraan  : ${ticket.vehicle_category.toUpperCase()}<br>
      No. Polisi : ${ticket.plate_number}<br>
      Slot Parkir: ${ticket.slot_code || 'UMUM'}<br>
      Waktu Masuk: ${ticket.entry_time}<br>
      Waktu Keluar: ${ticket.exit_time || 'Masih Parkir'}<br>
      Status     : ${ticket.status.toUpperCase()}
    </div>
    <div style="display:flex;gap:10px;justify-content:center;">
      <button class="btn btn-outline" onclick="window.print()">Cetak Struk</button>
      <button class="btn btn-primary" onclick="closeModal()">Tutup</button>
    </div>
  `);
}

async function apiFetch(endpoint, options = {}) {
  const res = await fetch(`${API_BASE}/${endpoint}`, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await res.json();
  if (!res.ok || data.error) throw new Error(data.error || 'Terjadi kesalahan server');
  return data;
}

// Auth toggle
document.getElementById('showRegisterLink').onclick = (e) => {
  e.preventDefault();
  document.getElementById('loginFormWrap').classList.add('hidden');
  document.getElementById('registerFormWrap').classList.remove('hidden');
};
document.getElementById('showLoginLink').onclick = (e) => {
  e.preventDefault();
  document.getElementById('registerFormWrap').classList.add('hidden');
  document.getElementById('loginFormWrap').classList.remove('hidden');
};

document.getElementById('loginForm').onsubmit = async (e) => {
  e.preventDefault();
  try {
    await apiFetch('auth.php?action=login', {
      method: 'POST',
      body: JSON.stringify({
        username: document.getElementById('loginUsername').value.trim(),
        password: document.getElementById('loginPassword').value
      })
    });
    welcomeShown = false;
    await loadState();
  } catch (err) { showToast(err.message); }
};

document.getElementById('registerForm').onsubmit = async (e) => {
  e.preventDefault();
  try {
    await apiFetch('auth.php?action=register', {
      method: 'POST',
      body: JSON.stringify({
        full_name: document.getElementById('regFullName').value.trim(),
        username: document.getElementById('regUsername').value.trim(),
        password: document.getElementById('regPassword').value
      })
    });
    showConfirmAnimation('Akun Berhasil Dibuat!', 'Silakan masuk menggunakan username dan password baru Anda.');
    document.getElementById('showLoginLink').click();
  } catch (err) { showToast(err.message); }
};

document.getElementById('logoutBtn').onclick = async () => {
  await apiFetch('auth.php?action=logout', { method: 'POST' });
  location.reload();
};

// Tab Switchers
document.querySelectorAll('#memberTabs .tab-btn').forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll('#memberTabs .tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('#memberView .tab-pane').forEach(p => p.classList.add('hidden'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.remove('hidden');
  };
});

document.querySelectorAll('#adminTabs .tab-btn').forEach(btn => {
  btn.onclick = () => {
    document.querySelectorAll('#adminTabs .tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('#adminView .admin-pane').forEach(p => p.classList.add('hidden'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.tab).classList.remove('hidden');
  };
});

async function loadState() {
  try {
    const data = await apiFetch('state.php');
    currentState = data;
    if (!data.authenticated) {
      document.getElementById('authSection').classList.remove('hidden');
      document.getElementById('appShell').classList.add('hidden');
      return;
    }

    document.getElementById('authSection').classList.add('hidden');
    document.getElementById('appShell').classList.remove('hidden');

    const u = data.user;
    document.getElementById('topUserName').textContent = u.full_name;
    document.getElementById('topUserMeta').textContent = `${u.role === 'admin' ? 'Admin' : 'Member'} (${u.user_code})`;

    // ESP32 Online Badge
    const espBadge = document.getElementById('espStatusBadge');
    const isOnline = data.esp32_online !== false;
    espBadge.className = `esp-badge ${isOnline ? '' : 'offline'}`;
    espBadge.innerHTML = `<span class="dot"></span> ${isOnline ? 'ESP32 ONLINE' : 'ESP32 OFFLINE'}`;

    // Animasi Sambutan Pengguna Baru
    if (!welcomeShown && Number(u.is_new_user) === 1 && u.role === 'member') {
      welcomeShown = true;
      openModal(`
        <div class="check-anim">G</div>
        <h2 style="margin-bottom:8px;">Selamat Datang, ${u.full_name}!</h2>
        <p style="color:#64748b;font-size:14px;margin-bottom:18px;">
          Akun <strong>Genesis Infinity</strong> Anda sudah siap. Anda bisa langsung mendaftarkan kendaraan di menu <strong>Profil & Pengaturan</strong> dan mengajukan kartu fisik di menu <strong>Kartu RFID</strong>.
        </p>
        <button class="btn btn-primary" onclick="dismissWelcome()">Mulai Sekarang</button>
      `);
    }

    if (u.role === 'admin') {
      document.getElementById('memberView').classList.add('hidden');
      document.getElementById('adminView').classList.remove('hidden');
      document.getElementById('csFab').classList.add('hidden');
      renderAdmin(data);
    } else {
      document.getElementById('adminView').classList.add('hidden');
      document.getElementById('memberView').classList.remove('hidden');
      document.getElementById('csFab').classList.remove('hidden');
      renderMember(data);
    }
  } catch (err) {
    console.error(err);
  }
}

async function dismissWelcome() {
  closeModal();
  await apiFetch('profile.php?action=dismiss_welcome', { method: 'POST', body: JSON.stringify({}) });
}

function renderMember(data) {
  const u = data.user;
  const rfid = data.rfid || { status: 'belum_mengajukan' };

  // 1. Tiket Aktif
  const activeTicket = (data.tickets || []).find(t => t.status === 'aktif');
  const ticketBadge = document.getElementById('activeTicketBadge');
  const ticketContent = document.getElementById('activeTicketContent');
  if (activeTicket) {
    ticketBadge.className = 'badge badge-green';
    ticketBadge.textContent = 'SEDANG PARKIR';
    ticketContent.innerHTML = `
      <div class="info-box success">
        <strong>Kode Tiket:</strong> ${activeTicket.ticket_code}<br>
        <strong>Kendaraan:</strong> ${activeTicket.vehicle_category.toUpperCase()} (${activeTicket.plate_number})<br>
        <strong>Slot Tujuan:</strong> <span class="badge badge-blue">${activeTicket.slot_code || 'Menunggu Slot'}</span><br>
        <strong>Waktu Masuk:</strong> ${activeTicket.entry_time}
        <div style="margin-top:12px;">
          <button class="btn btn-outline btn-sm" onclick='openReceiptModal(${JSON.stringify(activeTicket)})'>Lihat Struk Digital</button>
        </div>
      </div>`;
  } else {
    ticketBadge.className = 'badge badge-gray';
    ticketBadge.textContent = 'Tidak Ada Tiket';
    ticketContent.innerHTML = `<p class="sub">Belum ada sesi parkir aktif. Tap kartu RFID Anda di Gerbang Utama lalu pilih kendaraan di layar OLED.</p>`;
  }

  // 2. Kartu RFID (4 Status Dinamis)
  const statusMap = {
    belum_mengajukan:    { label: 'Belum Mengajukan', cls: 'badge-gray' },
    menunggu_verifikasi: { label: 'Menunggu Verifikasi', cls: 'badge-amber' },
    siap_diambil:        { label: 'Siap Diambil', cls: 'badge-blue' },
    sudah_diambil:       { label: 'Kartu Aktif', cls: 'badge-green' }
  };
  const st = statusMap[rfid.status] || statusMap.belum_mengajukan;
  const badgeEl = document.getElementById('rfidStatusBadge');
  badgeEl.className = `badge ${st.cls}`;
  badgeEl.textContent = st.label;

  const isTaken = rfid.status === 'sudah_diambil';
  const cardNum = rfid.card_number_display || (rfid.card_uid ? `RFID-${rfid.card_uid}` : '•••• •••• •••• ••••');

  document.getElementById('rfidCardVisualWrap').innerHTML = `
    <div class="rfid-card-wrapper ${isTaken ? '' : 'locked'}" style="background-image:url('${CUSTOM_CARD_BG}');">
      <div class="rfid-top">
        <span class="rfid-brand">GENESIS</span>
        <span class="rfid-status-pill">${isTaken ? 'AKTIF' : st.label.toUpperCase()}</span>
      </div>
      <div class="rfid-number">${cardNum}</div>
      <div class="rfid-bottom">
        <div class="rfid-holder">
          <small>CARD HOLDER</small>
          <strong>${u.full_name}</strong>
        </div>
        <div class="rfid-tier">
          <strong>GENESIS</strong>
          <small>INFINITY</small>
        </div>
      </div>
    </div>`;

  document.getElementById('rfidCardCaption').textContent = isTaken
    ? `Kartu RFID aktif dengan UID ${rfid.card_uid || '-'}. Siap digunakan di Gerbang Utama.`
    : 'Visual kartu penuh akan terbuka otomatis setelah kartu fisik diambil di Pos Depan.';

  const infoPanel = document.getElementById('rfidInfoPanel');
  if (rfid.status === 'belum_mengajukan') {
    infoPanel.innerHTML = `
      <div class="info-box">
        <p style="margin-bottom:12px;">Anda belum memiliki kartu fisik RFID. Ajukan sekarang secara gratis tanpa syarat saldo minimal.</p>
        <button class="btn btn-primary" onclick="requestRfidCard()">Ajukan Kartu Fisik RFID</button>
      </div>`;
  } else if (rfid.status === 'menunggu_verifikasi') {
    infoPanel.innerHTML = `
      <div class="info-box warn">
        <strong>Status:</strong> Pengajuan kartu Anda sedang diverifikasi oleh Pengelola.<br>
        <strong>Tanggal Pengajuan:</strong> ${rfid.requested_at || '-'}<br>
        Mohon tunggu jadwal pengambilan di Pos Depan.
      </div>`;
  } else if (rfid.status === 'siap_diambil') {
    infoPanel.innerHTML = `
      <div class="info-box success">
        <strong>Kartu Siap Diambil!</strong><br>
        <strong>Jadwal Pengambilan:</strong> ${rfid.pickup_schedule || 'Hubungi Pos Depan'}<br>
        <strong>Lokasi Pengambilan:</strong> ${rfid.pickup_location || 'Pos Depan (Pos Pengelola Gerbang Utama)'}<br>
        Tunjukkan akun Anda kepada petugas untuk aktivasi kartu.
      </div>`;
  } else {
    infoPanel.innerHTML = `
      <div class="info-box success">
        <strong style="color:#166534;">Kartu Fisik RFID Terverifikasi: ${rfid.card_uid || '-'}</strong><br>
        <strong>Jadwal Pengambilan:</strong> ${rfid.pickup_schedule || '-'}<br>
        <strong>Lokasi Pengambilan:</strong> ${rfid.pickup_location || 'Pos Depan'}<br>
        <strong>Status:</strong> Kartu fisik sudah diambil dan aktif digunakan.
      </div>`;
  }

  // 3. Riwayat Parkir
  const histBody = document.getElementById('historyTableBody');
  histBody.innerHTML = (data.tickets || []).length
    ? data.tickets.map(t => `
        <tr>
          <td><strong>${t.ticket_code}</strong></td>
          <td>${t.vehicle_category.toUpperCase()}</td>
          <td>${t.plate_number}</td>
          <td>${t.slot_code || '-'}</td>
          <td>${t.entry_time}</td>
          <td>${t.exit_time || '-'}</td>
          <td><span class="badge ${t.status === 'aktif' ? 'badge-green' : 'badge-gray'}">${t.status}</span></td>
          <td><button class="btn btn-outline btn-sm" onclick='openReceiptModal(${JSON.stringify(t)})'>Struk</button></td>
        </tr>`).join('')
    : '<tr><td colspan="8" style="text-align:center;color:#64748b;">Belum ada riwayat parkir.</td></tr>';

  // 4. Profil & Kendaraan
  document.getElementById('profUserCode').value = u.user_code;
  document.getElementById('profUsername').value = u.username;
  document.getElementById('profFullName').value = u.full_name;
  document.getElementById('profEmail').value = u.email || '';
  document.getElementById('profPhone').value = u.phone || '';

  const vehBody = document.getElementById('vehicleTableBody');
  vehBody.innerHTML = (data.vehicles || []).length
    ? data.vehicles.map(v => `
        <tr>
          <td><span class="badge ${v.category === 'mobil' ? 'badge-blue' : 'badge-green'}">${v.category.toUpperCase()}</span></td>
          <td><strong>${v.plate_number}</strong></td>
          <td>${v.vehicle_label || '-'}</td>
          <td><button class="btn btn-danger btn-sm" onclick="deleteVehicle(${v.id})">Hapus</button></td>
        </tr>`).join('')
    : '<tr><td colspan="4" style="text-align:center;color:#64748b;">Belum ada kendaraan terdaftar.</td></tr>';

  // 5. CS Messages
  const csBody = document.getElementById('csBody');
  csBody.innerHTML = (data.messages || []).map(m =>
    `<div class="msg ${m.sender_role}">${m.message}</div>`
  ).join('');
  csBody.scrollTop = csBody.scrollHeight;
}

function renderAdmin(data) {
  // Maket Parkir
  const grid = document.getElementById('adminSlotGrid');
  grid.innerHTML = (data.slots || []).map(s => {
    const isAlert = Boolean(s.mismatch_alert);
    return `
      <div class="slot-tile ${s.status} ${isAlert ? 'alert' : ''}">
        <h3>${s.slot_code}</h3>
        <div style="font-size:12px;color:#64748b;margin-bottom:4px;">${s.category.toUpperCase()} • ${s.status.toUpperCase()}</div>
        <div style="font-size:11px;color:#475569;margin-bottom:8px;">Jarak: ${s.distance_cm ? s.distance_cm + ' cm' : '-'}</div>
        ${isAlert ? '<div class="badge badge-amber" style="margin-bottom:8px;">SALAH SLOT >15M</div>' : ''}
        <button class="btn btn-outline btn-sm" onclick="toggleSlot(${s.id}, '${s.status === 'kosong' ? 'terisi' : 'kosong'}')">
          Set ${s.status === 'kosong' ? 'Terisi' : 'Kosong'}
        </button>
      </div>`;
  }).join('');

  // Gate Logs
  document.getElementById('adminGateLogBody').innerHTML = (data.gate_logs || []).map(l => `
    <tr>
      <td>${l.created_at}</td>
      <td>${l.card_uid || '-'}</td>
      <td><strong>${l.action}</strong></td>
      <td>${l.message || '-'}</td>
    </tr>`).join('') || '<tr><td colspan="4">Belum ada log gerbang.</td></tr>';

  // Pengelolaan Kartu RFID
  document.getElementById('adminRfidBody').innerHTML = (data.all_rfid || []).map(r => `
    <tr>
      <td><strong>${r.full_name}</strong><br><small>${r.user_code}</small></td>
      <td>${r.card_uid || '-'}</td>
      <td><span class="badge badge-blue">${r.status}</span></td>
      <td style="display:flex;gap:6px;flex-wrap:wrap;">
        <button class="btn btn-outline btn-sm" onclick="updateRfidStatus(${r.user_id}, 'siap_diambil')">Siap Diambil</button>
        <button class="btn btn-primary btn-sm" onclick="updateRfidStatus(${r.user_id}, 'sudah_diambil')">Aktifkan</button>
      </td>
    </tr>`).join('');

  // Daftar Akun & Kendaraan
  document.getElementById('adminUsersBody').innerHTML = (data.all_users || []).map(u => `
    <tr>
      <td>${u.user_code}</td>
      <td><strong>${u.full_name}</strong></td>
      <td>${u.username}</td>
      <td>${u.vehicles_summary || 'Belum ada'}</td>
    </tr>`).join('');

  // Admin CS Chat Selector
  const sel = document.getElementById('adminChatUserSelect');
  const prevVal = sel.value;
  sel.innerHTML = (data.all_users || []).map(u =>
    `<option value="${u.id}">${u.full_name} (${u.user_code})</option>`
  ).join('');
  if (prevVal) sel.value = prevVal;
  renderAdminChatThread();
}

function renderAdminChatThread() {
  if (!currentState || !currentState.all_messages) return;
  const uid = Number(document.getElementById('adminChatUserSelect').value);
  const box = document.getElementById('adminChatBox');
  const msgs = currentState.all_messages.filter(m => Number(m.user_id) === uid);
  box.innerHTML = msgs.length
    ? msgs.map(m => `<div class="msg ${m.sender_role === 'admin' ? 'member' : 'admin'}">${m.message}</div>`).join('')
    : '<p style="color:#64748b;font-size:13px;text-align:center;">Belum ada pesan dari member ini.</p>';
  box.scrollTop = box.scrollHeight;
}

// Actions Member
async function requestRfidCard() {
  try {
    await apiFetch('rfid.php?action=request', { method: 'POST', body: JSON.stringify({}) });
    showConfirmAnimation('Pengajuan Terkirim!', 'Pengelola akan segera memverifikasi dan menentukan jadwal pengambilan kartu di Pos Depan.');
    await loadState();
  } catch (err) { showToast(err.message); }
}

document.getElementById('profileForm').onsubmit = async (e) => {
  e.preventDefault();
  try {
    await apiFetch('profile.php', {
      method: 'POST',
      body: JSON.stringify({
        full_name: document.getElementById('profFullName').value.trim(),
        email: document.getElementById('profEmail').value.trim(),
        phone: document.getElementById('profPhone').value.trim()
      })
    });
    showConfirmAnimation('Profil Diperbarui!', 'Nama akun baru langsung tersinkron ke Kartu RFID dan OLED gerbang.');
    await loadState();
  } catch (err) { showToast(err.message); }
};

document.getElementById('vehicleForm').onsubmit = async (e) => {
  e.preventDefault();
  try {
    await apiFetch('vehicles.php', {
      method: 'POST',
      body: JSON.stringify({
        category: document.getElementById('vehCategory').value,
        plate_number: document.getElementById('vehPlate').value.trim().toUpperCase(),
        vehicle_label: document.getElementById('vehLabel').value.trim()
      })
    });
    document.getElementById('vehPlate').value = '';
    document.getElementById('vehLabel').value = '';
    showToast('Kendaraan berhasil ditambahkan!');
    await loadState();
  } catch (err) { showToast(err.message); }
};

async function deleteVehicle(id) {
  if (!confirm('Hapus kendaraan ini?')) return;
  try {
    await apiFetch(`vehicles.php?id=${id}`, { method: 'DELETE' });
    showToast('Kendaraan dihapus.');
    await loadState();
  } catch (err) { showToast(err.message); }
}

// Actions Admin
async function addNewSlot() {
  const code = prompt('Kode Slot baru (contoh: M-05 atau C-05):');
  if (!code) return;
  const cat = prompt('Kategori (ketik motor atau mobil):', 'motor');
  try {
    await apiFetch('admin.php?action=add_slot', {
      method: 'POST',
      body: JSON.stringify({ slot_code: code.toUpperCase(), category: cat === 'mobil' ? 'mobil' : 'motor' })
    });
    showToast('Slot baru ditambahkan!');
    await loadState();
  } catch (err) { showToast(err.message); }
}

async function toggleSlot(slotId, nextStatus) {
  try {
    await apiFetch('admin.php?action=update_slot', {
      method: 'POST',
      body: JSON.stringify({ slot_id: slotId, status: nextStatus })
    });
    showToast('Status slot diperbarui.');
    await loadState();
  } catch (err) { showToast(err.message); }
}

async function updateRfidStatus(userId, status) {
  const uid = status === 'sudah_diambil' ? prompt('Masukkan UID Kartu RFID (contoh: F3:A4:D7:22):', 'F3:A4:D7:22') : null;
  const schedule = status === 'siap_diambil' ? prompt('Jadwal Pengambilan:', '2026-11-28 | 08:00 - 11:00 WIB') : null;
  try {
    await apiFetch('admin.php?action=update_rfid', {
      method: 'POST',
      body: JSON.stringify({ user_id: userId, status, card_uid: uid, pickup_schedule: schedule })
    });
    showToast('Status kartu RFID diperbarui!');
    await loadState();
  } catch (err) { showToast(err.message); }
}

async function adminGateCmd(cmd) {
  try {
    await apiFetch('admin.php?action=gate_cmd', {
      method: 'POST',
      body: JSON.stringify({ command: cmd })
    });
    showToast(`Perintah Gate ${cmd} dikirim!`);
    await loadState();
  } catch (err) { showToast(err.message); }
}

document.getElementById('adminChatForm').onsubmit = async (e) => {
  e.preventDefault();
  const uid = Number(document.getElementById('adminChatUserSelect').value);
  const input = document.getElementById('adminChatInput');
  try {
    await apiFetch('chat.php', {
      method: 'POST',
      body: JSON.stringify({ target_user_id: uid, message: input.value.trim() })
    });
    input.value = '';
    await loadState();
  } catch (err) { showToast(err.message); }
};

// Floating CS Chat (Member)
document.getElementById('csFab').onclick = () => document.getElementById('csPanel').classList.toggle('open');
document.getElementById('csClose').onclick = () => document.getElementById('csPanel').classList.remove('open');
document.getElementById('csForm').onsubmit = async (e) => {
  e.preventDefault();
  const input = document.getElementById('csInput');
  try {
    await apiFetch('chat.php', { method: 'POST', body: JSON.stringify({ message: input.value.trim() }) });
    input.value = '';
    await loadState();
  } catch (err) { showToast(err.message); }
};

loadState();
setInterval(loadState, 8000);
