/*
 * ============================================================
 * GENESIS OF SMARTPARKING (GENESIS INFINITY) - v11 GATE NODE
 * Hardware: ESP32 + RC522 RFID + OLED SSD1306 (128x64) + Servo
 * State Machine:
 *   0. IDLE             -> Menunggu kartu + Debounce 650ms
 *   1. SELECT_VEHICLE   -> 1x Tap = MOTOR, 2x Tap = MOBIL
 *   2. CONFIRM_VEHICLE  -> 1x Tap = KONFIRMASI, 2x Tap = UBAH
 *   3. PARK_PROCESS     -> Kirim MQTT & Buka Palang
 *   + Timeout 15 detik otomatis kembali ke IDLE
 *   + LWT (Last Will) status offline otomatis
 * ============================================================
 */

#include <WiFi.h>
#include <PubSubClient.h>
#include <SPI.h>
#include <MFRC522.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <ESP32Servo.h>
#include <ArduinoJson.h>

const char* WIFI_SSID   = "NAMA_WIFI_ANDA";
const char* WIFI_PASS   = "PASSWORD_WIFI_ANDA";
const char* MQTT_SERVER = "192.168.203.38"; // Sesuaikan IP Wi-Fi Laptop
const int   MQTT_PORT   = 1883;

#define SS_PIN    5
#define RST_PIN   4
#define SERVO_PIN 13
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

MFRC522 rfid(SS_PIN, RST_PIN);
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
Servo gateServo;
WiFiClient espClient;
PubSubClient mqtt(espClient);

enum GateState { STATE_IDLE, STATE_WAIT_AUTH, STATE_SELECT_VEHICLE, STATE_CONFIRM_VEHICLE, STATE_PARK_PROCESS };
GateState currentState = STATE_IDLE;

String activeUid = "";
String activeUserName = "";
String chosenVehicle = "";

unsigned long stateStartTime = 0;
unsigned long lastTapTime = 0;
unsigned long tapWindowStart = 0;
int tapCount = 0;

const unsigned long STATE_TIMEOUT_MS = 15000;
const unsigned long TAP_WINDOW_MS    = 1800;
const unsigned long DEBOUNCE_MS      = 650;

void showOled(String l1, String l2 = "", String l3 = "", String l4 = "") {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0, 0);  display.println(l1);
  display.drawLine(0, 10, 128, 10, SSD1306_WHITE);
  display.setCursor(0, 16); display.println(l2);
  display.setCursor(0, 32); display.println(l3);
  display.setCursor(0, 48); display.println(l4);
  display.display();
}

void resetToIdle() {
  currentState = STATE_IDLE;
  activeUid = "";
  activeUserName = "";
  chosenVehicle = "";
  tapCount = 0;
  showOled("GENESIS INFINITY", "TEMPELKAN KARTU", "RFID ANDA", "SIAP MELAYANI");
}

void openGate() {
  gateServo.write(90);
  delay(4000);
  gateServo.write(0);
}

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String msg;
  for (unsigned int i = 0; i < length; i++) msg += (char)payload[i];

  if (String(topic) == "genesis/gate/cmd" && msg == "OPEN") {
    showOled("GENESIS INFINITY", "PALANG TERBUKA", "SILAKAN MASUK", "");
    openGate();
    resetToIdle();
    return;
  }

  if (String(topic) == "genesis/gate/oled") {
    StaticJsonDocument<256> doc;
    if (deserializeJson(doc, msg) == DeserializationError::Ok) {
      String st = doc["status"] | "";
      if (st == "OK" && currentState == STATE_WAIT_AUTH) {
        activeUserName = doc["name"] | "MEMBER";
        currentState = STATE_SELECT_VEHICLE;
        stateStartTime = millis();
        tapCount = 0;
        showOled("GENESIS - SELAMAT DATANG", activeUserName, "1x = MOTOR", "2x = MOBIL");
      } else if (st == "DENIED") {
        showOled("GENESIS INFINITY", "AKSES DITOLAK", "KARTU TIDAK AKTIF", "");
        delay(2500);
        resetToIdle();
      } else if (st == "PARK_OK") {
        String slot = doc["slot"] | "UMUM";
        showOled("GENESIS INFINITY", "SILAKAN MASUK", "SLOT: " + slot, "HATI-HATI");
        openGate();
        resetToIdle();
      }
    }
  }
}

void reconnectMqtt() {
  while (!mqtt.connected()) {
    if (mqtt.connect("ESP32_Genesis_Gate_v11", NULL, NULL, "genesis/esp32/status", 1, true, "offline")) {
      mqtt.publish("genesis/esp32/status", "online", true);
      mqtt.subscribe("genesis/gate/oled");
      mqtt.subscribe("genesis/gate/cmd");
    } else {
      delay(2000);
    }
  }
}

String readRfidUid() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) return "";
  String uidStr = "";
  for (byte i = 0; i < rfid.uid.size; i++) {
    if (rfid.uid.uidByte[i] < 0x10) uidStr += "0";
    uidStr += String(rfid.uid.uidByte[i], HEX);
    if (i < rfid.uid.size - 1) uidStr += ":";
  }
  uidStr.toUpperCase();
  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
  return uidStr;
}

void setup() {
  Serial.begin(115200);
  SPI.begin();
  rfid.PCD_Init();
  gateServo.attach(SERVO_PIN);
  gateServo.write(0);

  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  showOled("GENESIS INFINITY", "MENGHUBUNGKAN", "WIFI & SERVER...", "");

  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) delay(400);

  mqtt.setServer(MQTT_SERVER, MQTT_PORT);
  mqtt.setCallback(mqttCallback);
  reconnectMqtt();
  resetToIdle();
}

void loop() {
  if (!mqtt.connected()) reconnectMqtt();
  mqtt.loop();

  if (currentState != STATE_IDLE && (millis() - stateStartTime > STATE_TIMEOUT_MS)) {
    showOled("GENESIS INFINITY", "WAKTU HABIS", "SILAKAN ULANGI", "");
    delay(1500);
    resetToIdle();
    return;
  }

  String uid = readRfidUid();
  if (uid != "" && (millis() - lastTapTime > DEBOUNCE_MS)) {
    lastTapTime = millis();
    if (currentState == STATE_IDLE) {
      activeUid = uid;
      currentState = STATE_WAIT_AUTH;
      stateStartTime = millis();
      showOled("GENESIS INFINITY", "MEMERIKSA KARTU", uid, "MOHON TUNGGU...");
      String payload = "{"card_uid":"" + activeUid + ""}";
      mqtt.publish("genesis/gate/rfid", payload.c_str());
    }
    else if (uid == activeUid && (currentState == STATE_SELECT_VEHICLE || currentState == STATE_CONFIRM_VEHICLE)) {
      if (tapCount == 0) tapWindowStart = millis();
      tapCount++;
      stateStartTime = millis();
    }
  }

  if (tapCount > 0 && (millis() - tapWindowStart >= TAP_WINDOW_MS)) {
    if (currentState == STATE_SELECT_VEHICLE) {
      chosenVehicle = (tapCount == 1) ? "motor" : "mobil";
      currentState = STATE_CONFIRM_VEHICLE;
      showOled("KONFIRMASI PILIHAN", "KENDARAAN: " + String(chosenVehicle == "motor" ? "MOTOR" : "MOBIL"), "1x = KONFIRMASI", "2x = UBAH PILIHAN");
    }
    else if (currentState == STATE_CONFIRM_VEHICLE) {
      if (tapCount == 1) {
        currentState = STATE_PARK_PROCESS;
        showOled("GENESIS INFINITY", "MEMPROSES PARKIR", "MOHON TUNGGU...", "");
        String payload = "{"card_uid":"" + activeUid + "","vehicle_category":"" + chosenVehicle + ""}";
        mqtt.publish("genesis/gate/confirm", payload.c_str());
      } else {
        currentState = STATE_SELECT_VEHICLE;
        showOled("UBAH PILIHAN", activeUserName, "1x = MOTOR", "2x = MOBIL");
      }
    }
    tapCount = 0;
  }
}
