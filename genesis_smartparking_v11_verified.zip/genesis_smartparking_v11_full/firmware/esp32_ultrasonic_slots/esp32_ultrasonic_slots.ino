/*
 * ============================================================
 * GENESIS OF SMARTPARKING v11 - NODE SENSOR SLOT ULTRASONIK
 * Hardware: ESP32 + Sensor HC-SR04 (bisa tambah pin untuk slot lain)
 * ============================================================
 */
#include <WiFi.h>
#include <PubSubClient.h>

const char* WIFI_SSID   = "NAMA_WIFI_ANDA";
const char* WIFI_PASS   = "PASSWORD_WIFI_ANDA";
const char* MQTT_SERVER = "192.168.203.38";
const int   MQTT_PORT   = 1883;

struct SlotSensor { const char* code; int trigPin; int echoPin; };
SlotSensor slots[] = {
  {"M-01", 12, 14},
  {"M-02", 27, 26},
  {"C-01", 25, 33},
  {"C-02", 32, 35}
};
const int SLOT_COUNT = sizeof(slots) / sizeof(slots[0]);

WiFiClient espClient;
PubSubClient mqtt(espClient);

float readDistanceCm(int trigPin, int echoPin) {
  digitalWrite(trigPin, LOW); delayMicroseconds(2);
  digitalWrite(trigPin, HIGH); delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  long duration = pulseIn(echoPin, HIGH, 30000);
  return duration == 0 ? 250.0 : (duration * 0.0343 / 2.0);
}

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < SLOT_COUNT; i++) {
    pinMode(slots[i].trigPin, OUTPUT);
    pinMode(slots[i].echoPin, INPUT);
  }
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  while (WiFi.status() != WL_CONNECTED) delay(400);
  mqtt.setServer(MQTT_SERVER, MQTT_PORT);
}

void loop() {
  if (!mqtt.connected()) {
    mqtt.connect("ESP32_Genesis_Slots_v11");
    delay(1000);
  }
  mqtt.loop();

  for (int i = 0; i < SLOT_COUNT; i++) {
    float dist = readDistanceCm(slots[i].trigPin, slots[i].echoPin);
    String topic = String("genesis/slot/") + slots[i].code;
    String payload = "{"distance_cm":" + String(dist, 1) + ","occupied":" + String(dist < 40.0 ? "true" : "false") + "}";
    mqtt.publish(topic.c_str(), payload.c_str());
  }
  delay(3000);
}
