-- ==========================================================
-- Migrasi Aman dari v10 ke Genesis SmartParking v11
-- Menghapus tabel finansial/top-up lama jika masih ada
-- ==========================================================
USE genesis_smartparking;

DROP TABLE IF EXISTS deposits;
DROP TABLE IF EXISTS topup_requests;
DROP TABLE IF EXISTS balance_logs;
DROP TABLE IF EXISTS wallet_transactions;
