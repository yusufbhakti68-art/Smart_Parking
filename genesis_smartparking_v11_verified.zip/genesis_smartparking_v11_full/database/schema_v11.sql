-- ==========================================================
-- Genesis of SmartParking (Genesis Infinity) v11 Full Schema
-- Bersih tanpa tabel saldo/deposit/top-up
-- ==========================================================

CREATE DATABASE IF NOT EXISTS genesis_smartparking
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE genesis_smartparking;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_code VARCHAR(20) NOT NULL UNIQUE,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) DEFAULT NULL,
  phone VARCHAR(30) DEFAULT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'member') NOT NULL DEFAULT 'member',
  is_new_user TINYINT(1) NOT NULL DEFAULT 1,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  category ENUM('motor', 'mobil') NOT NULL,
  plate_number VARCHAR(20) NOT NULL,
  vehicle_label VARCHAR(80) DEFAULT NULL,
  is_primary TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_vehicles_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS rfid_cards (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  card_uid VARCHAR(40) DEFAULT NULL UNIQUE,
  card_number_display VARCHAR(32) DEFAULT NULL,
  status ENUM('belum_mengajukan', 'menunggu_verifikasi', 'siap_diambil', 'sudah_diambil')
         NOT NULL DEFAULT 'belum_mengajukan',
  pickup_schedule VARCHAR(100) DEFAULT NULL,
  pickup_location VARCHAR(150) DEFAULT 'Pos Depan (Pos Pengelola Gerbang Utama)',
  requested_at DATETIME DEFAULT NULL,
  picked_up_at DATETIME DEFAULT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_rfid_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS parking_slots (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slot_code VARCHAR(10) NOT NULL UNIQUE,
  zone VARCHAR(30) NOT NULL DEFAULT 'Zona Utama',
  category ENUM('motor', 'mobil') NOT NULL,
  status ENUM('kosong', 'terisi', 'dipesan', 'nonaktif') NOT NULL DEFAULT 'kosong',
  distance_cm FLOAT DEFAULT NULL,
  mismatch_since DATETIME DEFAULT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS parking_tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_code VARCHAR(30) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  vehicle_id INT DEFAULT NULL,
  vehicle_category ENUM('motor', 'mobil') NOT NULL,
  plate_number VARCHAR(20) DEFAULT '-',
  slot_id INT DEFAULT NULL,
  status ENUM('aktif', 'selesai', 'dibatalkan') NOT NULL DEFAULT 'aktif',
  entry_method ENUM('rfid', 'web', 'manual_admin') NOT NULL DEFAULT 'rfid',
  entry_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  exit_time DATETIME DEFAULT NULL,
  notes VARCHAR(255) DEFAULT NULL,
  CONSTRAINT fk_ticket_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ticket_vehicle FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
  CONSTRAINT fk_ticket_slot FOREIGN KEY (slot_id) REFERENCES parking_slots(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS gate_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  gate_name VARCHAR(30) NOT NULL DEFAULT 'Gerbang Utama',
  card_uid VARCHAR(40) DEFAULT NULL,
  user_id INT DEFAULT NULL,
  action VARCHAR(50) NOT NULL,
  vehicle_category ENUM('motor', 'mobil') DEFAULT NULL,
  message VARCHAR(255) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS cs_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  sender_role ENUM('member', 'admin') NOT NULL,
  message TEXT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_chat_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS system_status (
  device_key VARCHAR(40) PRIMARY KEY,
  status VARCHAR(20) NOT NULL DEFAULT 'offline',
  last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Seed Data Demo
INSERT IGNORE INTO system_status (device_key, status) VALUES ('esp32_gate', 'online');

INSERT IGNORE INTO users (id, user_code, username, full_name, email, phone, password_hash, role, is_new_user) VALUES
(1, 'ADM-0001', 'admin', 'Pengelola Genesis', 'admin@genesis.local', '081200000001', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 0),
(2, 'USR-1001', 'budi', 'Budi Santoso', 'budi@genesis.local', '081234567890', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'member', 0),
(3, 'USR-1002', 'yusuf', 'Yusuf Bhati', 'yusuf@genesis.local', '081298765432', '$2y$10$TKh8H1.PfQx37YgCzwiKb.KjNyWgaHb9cbcoQgdIVFlYg7B77UdFm', 'member', 1);

INSERT IGNORE INTO vehicles (id, user_id, category, plate_number, vehicle_label, is_primary) VALUES
(1, 2, 'motor', 'N 4521 ABC', 'Honda Vario 160', 1),
(2, 2, 'mobil', 'N 1820 XY', 'Toyota Avanza', 0),
(3, 3, 'motor', 'N 3310 GNS', 'Yamaha NMAX', 1);

INSERT IGNORE INTO rfid_cards (id, user_id, card_uid, card_number_display, status, pickup_schedule, pickup_location, requested_at, picked_up_at) VALUES
(1, 2, 'F3:A4:D7:11', '4364 3211 2233 4455', 'sudah_diambil', '2026-11-27 | 08:00 - 11:00 WIB', 'Pos Depan (Pos Pengelola Gerbang Utama)', NOW(), NOW()),
(2, 3, NULL, NULL, 'belum_mengajukan', NULL, 'Pos Depan (Pos Pengelola Gerbang Utama)', NULL, NULL);

INSERT IGNORE INTO parking_slots (id, slot_code, zone, category, status, distance_cm) VALUES
(1, 'M-01', 'Zona Motor', 'motor', 'kosong', 142.5),
(2, 'M-02', 'Zona Motor', 'motor', 'terisi', 18.2),
(3, 'M-03', 'Zona Motor', 'motor', 'kosong', 150.0),
(4, 'M-04', 'Zona Motor', 'motor', 'kosong', 148.0),
(5, 'C-01', 'Zona Mobil', 'mobil', 'kosong', 210.0),
(6, 'C-02', 'Zona Mobil', 'mobil', 'terisi', 24.5),
(7, 'C-03', 'Zona Mobil', 'mobil', 'kosong', 205.0),
(8, 'C-04', 'Zona Mobil', 'mobil', 'kosong', 199.0);

INSERT IGNORE INTO parking_tickets (id, ticket_code, user_id, vehicle_id, vehicle_category, plate_number, slot_id, status, entry_method, entry_time, notes) VALUES
(1, 'GNS-20261127-001', 2, 1, 'motor', 'N 4521 ABC', 2, 'aktif', 'rfid', NOW(), 'Masuk via Gerbang Utama (1x Tap Motor)');

INSERT IGNORE INTO cs_messages (id, user_id, sender_role, message) VALUES
(1, 2, 'admin', 'Halo Budi! Kartu RFID Genesis Infinity Anda sudah aktif dan siap digunakan.');
