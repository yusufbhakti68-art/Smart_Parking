# Perubahan Menu Dashboard Pengguna

Versi: SmartParking IoT Hybrid v5 — pembaruan navigasi pengguna

## Menu yang ditampilkan
1. Beranda — ringkasan saldo, kendaraan, dan status RFID.
2. Cari Parkir — menuju pilihan slot dan proses check-in.
3. Tiket Parkir — menuju informasi tiket aktif dan proses checkout.
4. Kendaraan Saya — menampilkan kendaraan yang terdaftar pada akun.
5. Saldo & Top-Up — fitur top-up dan riwayat deposit yang sudah tersedia.
6. Kartu RFID — menuju status RFID dan formulir pengajuan kartu yang sudah tersedia.
7. Riwayat Parkir — riwayat transaksi parkir dan struk.
8. Profil & Pengaturan — menampilkan informasi profil akun.

## Catatan fungsi
- Menu Peta Maket Slot dan visualisasi maket pada panel pengguna tidak ditampilkan.
- Menu Cari Parkir, Tiket Parkir, dan Kartu RFID mengarahkan pengguna ke bagian fitur yang sesuai pada panel yang sudah ada.
- Pada versi ini, Kendaraan Saya dan Profil & Pengaturan masih menampilkan data akun secara baca-saja; pengeditan data belum ditambahkan.
- Menu Maket & Gate pada sisi pengelola tidak diubah.
- Pemeriksaan sintaks JavaScript inline menggunakan `node --check` berhasil.
